-- phpMyAdmin SQL Dump
-- version 2.6.4-pl3
-- http://www.phpmyadmin.net
-- 
-- Serveur: db454829920.db.1and1.com
-- Généré le : Jeudi 19 Décembre 2013 à 19:15
-- Version du serveur: 5.1.72
-- Version de PHP: 5.3.3-7+squeeze18
-- 
-- Base de données: `db454829920`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `ahm_files`
-- 

CREATE TABLE `ahm_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` text NOT NULL,
  `file` varchar(255) NOT NULL,
  `password` varchar(40) NOT NULL,
  `download_count` int(11) NOT NULL,
  `access` enum('guest','member') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `show_counter` tinyint(1) NOT NULL,
  `quota` int(11) NOT NULL,
  `link_label` varchar(255) NOT NULL,
  `icon` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Contenu de la table `ahm_files`
-- 

INSERT INTO `ahm_files` VALUES (4, 'Fichier Test2', '', 'N;', 'campus2.jpg', '', 4, 'member', 0, 0, 'fic2', 'agt_add-to-desktop.png');
INSERT INTO `ahm_files` VALUES (5, 'Fichier Test1', '', 'N;', '3 maîtrise des risques.pdf', '', 3, 'member', 0, 0, 'fic5', 'Box Download.png');
INSERT INTO `ahm_files` VALUES (6, 'Repertoire de test', '', 'N;', '1364254840wpdm_CISI.zip', '', 3, 'member', 0, 0, 'fic77', 'ark2.png');

-- --------------------------------------------------------

-- 
-- Structure de la table `messages`
-- 

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_expediteur` int(11) NOT NULL DEFAULT '0',
  `id_destinataire` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `titre` text NOT NULL,
  `message` text NOT NULL,
  `statut` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `messages`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_bp_messages_messages`
-- 

CREATE TABLE `wp_bp_messages_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `thread_id` bigint(20) NOT NULL,
  `sender_id` bigint(20) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `date_sent` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `thread_id` (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_bp_messages_messages`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_bp_messages_notices`
-- 

CREATE TABLE `wp_bp_messages_notices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `date_sent` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_bp_messages_notices`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_bp_messages_recipients`
-- 

CREATE TABLE `wp_bp_messages_recipients` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `thread_id` bigint(20) NOT NULL,
  `unread_count` int(10) NOT NULL DEFAULT '0',
  `sender_only` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `thread_id` (`thread_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `sender_only` (`sender_only`),
  KEY `unread_count` (`unread_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_bp_messages_recipients`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_bp_notifications`
-- 

CREATE TABLE `wp_bp_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `component_name` varchar(75) NOT NULL,
  `component_action` varchar(75) NOT NULL,
  `date_notified` datetime NOT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `user_id` (`user_id`),
  KEY `is_new` (`is_new`),
  KEY `component_name` (`component_name`),
  KEY `component_action` (`component_action`),
  KEY `useritem` (`user_id`,`is_new`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_bp_notifications`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_commentmeta`
-- 

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_commentmeta`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_comments`
-- 

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_comments`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_cpm_meta`
-- 

CREATE TABLE `wp_cpm_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `thread_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `opened` tinyint(1) DEFAULT NULL,
  `subscribe` tinyint(1) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_cpm_meta`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_cpm_msg`
-- 

CREATE TABLE `wp_cpm_msg` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `thread_id` bigint(20) NOT NULL,
  `sender_id` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `subject` text,
  `timestamp` bigint(20) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_cpm_msg`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_download_monitor_file_meta`
-- 

CREATE TABLE `wp_download_monitor_file_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meta_name` longtext NOT NULL,
  `meta_value` longtext NOT NULL,
  `download_id` int(12) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_download_monitor_file_meta`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_download_monitor_files`
-- 

CREATE TABLE `wp_download_monitor_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `filename` longtext NOT NULL,
  `file_description` longtext,
  `dlversion` varchar(200) NOT NULL,
  `postDate` datetime NOT NULL,
  `hits` int(12) unsigned NOT NULL,
  `user` varchar(200) NOT NULL,
  `members` int(1) DEFAULT NULL,
  `mirrors` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_download_monitor_files`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_download_monitor_formats`
-- 

CREATE TABLE `wp_download_monitor_formats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `format` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_download_monitor_formats`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_download_monitor_log`
-- 

CREATE TABLE `wp_download_monitor_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `date` datetime DEFAULT NULL,
  `ip_address` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_download_monitor_log`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_download_monitor_relationships`
-- 

CREATE TABLE `wp_download_monitor_relationships` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `taxonomy_id` int(10) unsigned NOT NULL,
  `download_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_download_monitor_relationships`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_download_monitor_stats`
-- 

CREATE TABLE `wp_download_monitor_stats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `hits` int(12) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_download_monitor_stats`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_download_monitor_taxonomies`
-- 

CREATE TABLE `wp_download_monitor_taxonomies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `parent` int(12) unsigned NOT NULL,
  `taxonomy` varchar(250) NOT NULL,
  `order` int(12) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_download_monitor_taxonomies`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_downloads`
-- 

CREATE TABLE `wp_downloads` (
  `file_id` int(10) NOT NULL AUTO_INCREMENT,
  `file` tinytext NOT NULL,
  `file_name` text NOT NULL,
  `file_des` text NOT NULL,
  `file_size` varchar(20) NOT NULL DEFAULT '',
  `file_category` int(2) NOT NULL DEFAULT '0',
  `file_date` varchar(20) NOT NULL DEFAULT '',
  `file_updated_date` varchar(20) NOT NULL DEFAULT '',
  `file_last_downloaded_date` varchar(20) NOT NULL DEFAULT '',
  `file_hits` int(10) NOT NULL DEFAULT '0',
  `file_permission` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_downloads`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_flgallery_albums`
-- 

CREATE TABLE `wp_flgallery_albums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order` bigint(20) NOT NULL DEFAULT '0',
  `author` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `preview` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order` (`order`,`author`,`created`,`modified`),
  KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Contenu de la table `wp_flgallery_albums`
-- 

INSERT INTO `wp_flgallery_albums` VALUES (1, 1, 1, 'test', '', '', '2013-04-30 11:07:00', '2013-04-30 11:09:05');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_flgallery_galleries`
-- 

CREATE TABLE `wp_flgallery_galleries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order` bigint(20) NOT NULL DEFAULT '0',
  `author` bigint(20) unsigned NOT NULL,
  `type` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `author` (`author`,`order`,`created`,`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Contenu de la table `wp_flgallery_galleries`
-- 

INSERT INTO `wp_flgallery_galleries` VALUES (1, 1, 1, 'StackPhoto', 'New Gallery', 550, 400, '2013-04-30 11:04:20', '2013-04-30 11:20:26');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_flgallery_images`
-- 

CREATE TABLE `wp_flgallery_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` bigint(20) unsigned NOT NULL,
  `gallery_id` bigint(20) unsigned NOT NULL,
  `order` bigint(20) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `target` varchar(50) NOT NULL,
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `size` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `album_id` (`album_id`,`gallery_id`,`order`,`type`,`size`),
  KEY `path` (`path`),
  KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- 
-- Contenu de la table `wp_flgallery_images`
-- 

INSERT INTO `wp_flgallery_images` VALUES (1, 1, 0, 1, 'image/jpeg', 'j7advwtg.jpg', 'dl.jpg', '', '', '', '', 280, 120, 4026);
INSERT INTO `wp_flgallery_images` VALUES (2, 1, 0, 2, 'image/png', '7wattouo.png', 'logo_ups_pres.png', '', '', '', '', 280, 82, 19196);
INSERT INTO `wp_flgallery_images` VALUES (3, 1, 0, 3, 'image/gif', 'wa9m224m.gif', 'master-ihm.gif', '', '', '', '', 127, 71, 4093);
INSERT INTO `wp_flgallery_images` VALUES (4, 1, 0, 4, 'image/png', '9hr91jho.png', 'logoM2IMbis.png', '', '', '', '', 238, 150, 27491);
INSERT INTO `wp_flgallery_images` VALUES (5, 1, 0, 5, 'image/jpeg', 'vag3g3jr.jpg', 'ups.jpg', '', '', '', '', 1210, 808, 148257);
INSERT INTO `wp_flgallery_images` VALUES (6, 1, 1, -1, 'image/jpeg', 'vag3g3jr.jpg', 'ups.jpg', '', '', '', '', 1210, 808, 148257);
INSERT INTO `wp_flgallery_images` VALUES (7, 1, 1, -2, 'image/png', '9hr91jho.png', 'logoM2IMbis.png', '', '', '', '', 238, 150, 27491);
INSERT INTO `wp_flgallery_images` VALUES (8, 1, 1, -3, 'image/gif', 'wa9m224m.gif', 'master-ihm.gif', '', '', '', '', 127, 71, 4093);
INSERT INTO `wp_flgallery_images` VALUES (9, 1, 1, -4, 'image/png', '7wattouo.png', 'logo_ups_pres.png', '', '', '', '', 280, 82, 19196);
INSERT INTO `wp_flgallery_images` VALUES (10, 1, 1, -5, 'image/jpeg', 'j7advwtg.jpg', 'dl.jpg', '', '', '', '', 280, 120, 4026);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_flgallery_settings`
-- 

CREATE TABLE `wp_flgallery_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gallery_id` bigint(20) unsigned NOT NULL,
  `gallery_type` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gallery_id` (`gallery_id`,`gallery_type`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

-- 
-- Contenu de la table `wp_flgallery_settings`
-- 

INSERT INTO `wp_flgallery_settings` VALUES (1, 1, 'PhotoFlow', 'background.transparent', 'true');
INSERT INTO `wp_flgallery_settings` VALUES (2, 1, 'PhotoFlow', 'background.color', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (3, 1, 'PhotoFlow', 'background.image', '');
INSERT INTO `wp_flgallery_settings` VALUES (4, 1, 'PhotoFlow', 'lightbox.useLightbox', 'false');
INSERT INTO `wp_flgallery_settings` VALUES (5, 1, 'PhotoFlow', 'lightbox.overrideLinks', 'false');
INSERT INTO `wp_flgallery_settings` VALUES (6, 1, 'PhotoFlow', 'preloader.stripesAlpha', '45');
INSERT INTO `wp_flgallery_settings` VALUES (7, 1, 'PhotoFlow', 'preloader.barColor', '000000');
INSERT INTO `wp_flgallery_settings` VALUES (8, 1, 'PhotoFlow', 'preloader.barAlpha', '14');
INSERT INTO `wp_flgallery_settings` VALUES (9, 1, 'PhotoFlow', 'preloader.bgColor', '000000');
INSERT INTO `wp_flgallery_settings` VALUES (10, 1, 'PhotoFlow', 'preloader.bgAlpha', '10');
INSERT INTO `wp_flgallery_settings` VALUES (11, 1, 'PhotoFlow', 'preloader.innerShadow', '20');
INSERT INTO `wp_flgallery_settings` VALUES (12, 1, 'PhotoFlow', 'preloader.dropShadow', '30');
INSERT INTO `wp_flgallery_settings` VALUES (13, 1, 'PhotoFlow', 'scrollbar.bgColor', '000000');
INSERT INTO `wp_flgallery_settings` VALUES (14, 1, 'PhotoFlow', 'scrollbar.bgAlpha', '20');
INSERT INTO `wp_flgallery_settings` VALUES (15, 1, 'PhotoFlow', 'scrollbar.handleColor', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (16, 1, 'PhotoFlow', 'scrollbar.handleAlpha', '40');
INSERT INTO `wp_flgallery_settings` VALUES (17, 1, 'PhotoFlow', 'scrollbar.arrowsColor', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (18, 1, 'PhotoFlow', 'scrollbar.arrowsAlpha', '40');
INSERT INTO `wp_flgallery_settings` VALUES (19, 1, 'PhotoFlow', 'scrollbar.innerShadow', '10');
INSERT INTO `wp_flgallery_settings` VALUES (20, 1, 'PhotoFlow', 'scrollbar.dropShadow', '0');
INSERT INTO `wp_flgallery_settings` VALUES (21, 1, 'PhotoFlow', 'caption.textColor', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (22, 1, 'PhotoFlow', 'caption.bgColor', '000000');
INSERT INTO `wp_flgallery_settings` VALUES (23, 1, 'PhotoFlow', 'caption.bgAlpha', '80');
INSERT INTO `wp_flgallery_settings` VALUES (24, 1, 'PhotoFlow', 'caption.frameColor', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (25, 1, 'PhotoFlow', 'caption.frameAlpha', '40');
INSERT INTO `wp_flgallery_settings` VALUES (26, 1, 'PhotoFlow', 'caption.shadowAlpha', '30');
INSERT INTO `wp_flgallery_settings` VALUES (27, 1, 'PhotoFlow', 'caption.multilingual', 'false');
INSERT INTO `wp_flgallery_settings` VALUES (28, 1, 'PhotoFlow', 'caption.multilingualFontSize', '12');
INSERT INTO `wp_flgallery_settings` VALUES (29, 1, 'PhotoFlow', 'background.bgColor', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (30, 1, 'PhotoFlow', 'background.bgAlpha', '100');
INSERT INTO `wp_flgallery_settings` VALUES (31, 1, 'PhotoFlow', 'background.bgImage', '');
INSERT INTO `wp_flgallery_settings` VALUES (32, 1, 'PhotoFlow', 'picasa.user', '');
INSERT INTO `wp_flgallery_settings` VALUES (33, 1, 'PhotoFlow', 'picasa.albumID', '');
INSERT INTO `wp_flgallery_settings` VALUES (34, 1, 'PhotoFlow', 'flickr.userID', '');
INSERT INTO `wp_flgallery_settings` VALUES (35, 1, 'PhotoFlow', 'flickr.photosetID', '');
INSERT INTO `wp_flgallery_settings` VALUES (36, 1, 'PhotoFlow', 'flickr.tags', '');
INSERT INTO `wp_flgallery_settings` VALUES (37, 1, 'PhotoFlow', 'startPosition', 'center');
INSERT INTO `wp_flgallery_settings` VALUES (38, 1, 'PhotoFlow', 'imageAngle', '30');
INSERT INTO `wp_flgallery_settings` VALUES (39, 1, 'PhotoFlow', 'maxImageWidth', '250');
INSERT INTO `wp_flgallery_settings` VALUES (40, 1, 'PhotoFlow', 'useScrollBar', 'true');
INSERT INTO `wp_flgallery_settings` VALUES (41, 1, 'PhotoFlow', 'slideShow', 'false');
INSERT INTO `wp_flgallery_settings` VALUES (42, 1, 'PhotoFlow', 'slideShowDelay', '2');
INSERT INTO `wp_flgallery_settings` VALUES (43, 1, 'PhotoFlow', 'flipDuration', '1');
INSERT INTO `wp_flgallery_settings` VALUES (44, 1, 'PhotoFlow', 'flipSound', '');
INSERT INTO `wp_flgallery_settings` VALUES (45, 1, 'PhotoFlow', 'useHighlight', 'true');
INSERT INTO `wp_flgallery_settings` VALUES (46, 1, 'PhotoFlow', 'reflectionAlpha', '25');
INSERT INTO `wp_flgallery_settings` VALUES (47, 1, 'PhotoFlow', 'colorScheme', 'custom');
INSERT INTO `wp_flgallery_settings` VALUES (48, 1, 'StackPhoto', 'background.transparent', 'true');
INSERT INTO `wp_flgallery_settings` VALUES (49, 1, 'StackPhoto', 'background.color', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (50, 1, 'StackPhoto', 'background.image', '');
INSERT INTO `wp_flgallery_settings` VALUES (51, 1, 'StackPhoto', 'caption.color', '000000');
INSERT INTO `wp_flgallery_settings` VALUES (52, 1, 'StackPhoto', 'caption.fontName', 'Arial');
INSERT INTO `wp_flgallery_settings` VALUES (53, 1, 'StackPhoto', 'translation.back', 'BACK');
INSERT INTO `wp_flgallery_settings` VALUES (54, 1, 'StackPhoto', 'translation.gotoLink', 'Go to Link');
INSERT INTO `wp_flgallery_settings` VALUES (55, 1, 'StackPhoto', 'bgImage.alpha', '100');
INSERT INTO `wp_flgallery_settings` VALUES (56, 1, 'StackPhoto', 'bgImage.source', '');
INSERT INTO `wp_flgallery_settings` VALUES (57, 1, 'StackPhoto', 'image.width', '300');
INSERT INTO `wp_flgallery_settings` VALUES (58, 1, 'StackPhoto', 'image.height', '200');
INSERT INTO `wp_flgallery_settings` VALUES (59, 1, 'StackPhoto', 'picasa.user', '');
INSERT INTO `wp_flgallery_settings` VALUES (60, 1, 'StackPhoto', 'picasa.albumID', '');
INSERT INTO `wp_flgallery_settings` VALUES (61, 1, 'StackPhoto', 'flickr.userID', '');
INSERT INTO `wp_flgallery_settings` VALUES (62, 1, 'StackPhoto', 'flickr.photosetID', '');
INSERT INTO `wp_flgallery_settings` VALUES (63, 1, 'StackPhoto', 'flickr.tags', '');
INSERT INTO `wp_flgallery_settings` VALUES (64, 1, 'StackPhoto', 'frameColor', 'ffffff');
INSERT INTO `wp_flgallery_settings` VALUES (65, 1, 'StackPhoto', 'imageScaleMode', 'fill');
INSERT INTO `wp_flgallery_settings` VALUES (66, 1, 'StackPhoto', 'slideshow', 'false');
INSERT INTO `wp_flgallery_settings` VALUES (67, 1, 'StackPhoto', 'visibleImages', '5');
INSERT INTO `wp_flgallery_settings` VALUES (68, 1, 'StackPhoto', 'usePhotoNumbers', 'true');
INSERT INTO `wp_flgallery_settings` VALUES (69, 1, 'StackPhoto', 'soundEffect', '');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_group`
-- 

CREATE TABLE `wp_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `membresID` int(11) NOT NULL,
  `membresEmail` varchar(50) NOT NULL,
  `nomGroupe` varchar(50) NOT NULL,
  PRIMARY KEY (`id`,`membresID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

-- 
-- Contenu de la table `wp_group`
-- 

INSERT INTO `wp_group` VALUES (1, 9, '', 'GDNLTEAM_');
INSERT INTO `wp_group` VALUES (5, 10, '', 'JAVA DEVELOPPER');
INSERT INTO `wp_group` VALUES (6, 4, '', 'MyTest');
INSERT INTO `wp_group` VALUES (7, 11, '', 'Arrangement Btn ajout');
INSERT INTO `wp_group` VALUES (8, 13, '', 'bien');
INSERT INTO `wp_group` VALUES (9, 14, '', 'VerieTest');
INSERT INTO `wp_group` VALUES (10, 15, '', 'Retest');
INSERT INTO `wp_group` VALUES (12, 17, '', 'YaQueMoiQuiPeutSuppOuModif');
INSERT INTO `wp_group` VALUES (13, 19, '', 'DernierTestBon');
INSERT INTO `wp_group` VALUES (14, 23, '', 'UPS');
INSERT INTO `wp_group` VALUES (15, 25, '', 'groupeDeAmine');
INSERT INTO `wp_group` VALUES (16, 25, '', 'groupeDeAmine');
INSERT INTO `wp_group` VALUES (17, 27, '', 'GDNLTEAM_2');
INSERT INTO `wp_group` VALUES (18, 42, '', 'ISI-Peasy');
INSERT INTO `wp_group` VALUES (21, 53, '', 'G2 M2DL');
INSERT INTO `wp_group` VALUES (22, 40, '', 'G3 SQLI');
INSERT INTO `wp_group` VALUES (23, 41, '', 'Nyan Dev Team');
INSERT INTO `wp_group` VALUES (24, 55, '', 'Toto');
INSERT INTO `wp_group` VALUES (25, 55, '', 'Toto');
INSERT INTO `wp_group` VALUES (26, 29, '', 'Toto');
INSERT INTO `wp_group` VALUES (32, 43, '', '1');
INSERT INTO `wp_group` VALUES (33, 43, '', '2');
INSERT INTO `wp_group` VALUES (34, 43, '', '3');
INSERT INTO `wp_group` VALUES (35, 36, '', 'lamray9iya');
INSERT INTO `wp_group` VALUES (37, 66, '', '0BandeDeCoders');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_groups_rs`
-- 

CREATE TABLE `wp_groups_rs` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_name` text NOT NULL,
  `group_description` text NOT NULL,
  `group_homepage` varchar(128) NOT NULL DEFAULT '',
  `group_meta_id` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `meta_id` (`group_meta_id`,`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_groups_rs`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_id_group_membres`
-- 

CREATE TABLE `wp_id_group_membres` (
  `id_membre` int(11) NOT NULL,
  `id_groupe` int(11) NOT NULL,
  PRIMARY KEY (`id_membre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `wp_id_group_membres`
-- 

INSERT INTO `wp_id_group_membres` VALUES (4, 6);
INSERT INTO `wp_id_group_membres` VALUES (9, 1);
INSERT INTO `wp_id_group_membres` VALUES (10, 5);
INSERT INTO `wp_id_group_membres` VALUES (12, 1);
INSERT INTO `wp_id_group_membres` VALUES (13, 5);
INSERT INTO `wp_id_group_membres` VALUES (14, 9);
INSERT INTO `wp_id_group_membres` VALUES (15, 10);
INSERT INTO `wp_id_group_membres` VALUES (16, 10);
INSERT INTO `wp_id_group_membres` VALUES (17, 12);
INSERT INTO `wp_id_group_membres` VALUES (19, 13);
INSERT INTO `wp_id_group_membres` VALUES (20, 10);
INSERT INTO `wp_id_group_membres` VALUES (21, 5);
INSERT INTO `wp_id_group_membres` VALUES (22, 1);
INSERT INTO `wp_id_group_membres` VALUES (23, 14);
INSERT INTO `wp_id_group_membres` VALUES (25, 15);
INSERT INTO `wp_id_group_membres` VALUES (26, 15);
INSERT INTO `wp_id_group_membres` VALUES (27, 17);
INSERT INTO `wp_id_group_membres` VALUES (29, 26);
INSERT INTO `wp_id_group_membres` VALUES (32, 37);
INSERT INTO `wp_id_group_membres` VALUES (33, 35);
INSERT INTO `wp_id_group_membres` VALUES (35, 21);
INSERT INTO `wp_id_group_membres` VALUES (36, 35);
INSERT INTO `wp_id_group_membres` VALUES (37, 5);
INSERT INTO `wp_id_group_membres` VALUES (40, 22);
INSERT INTO `wp_id_group_membres` VALUES (41, 23);
INSERT INTO `wp_id_group_membres` VALUES (42, 18);
INSERT INTO `wp_id_group_membres` VALUES (43, 32);
INSERT INTO `wp_id_group_membres` VALUES (45, 14);
INSERT INTO `wp_id_group_membres` VALUES (53, 21);
INSERT INTO `wp_id_group_membres` VALUES (55, 24);
INSERT INTO `wp_id_group_membres` VALUES (66, 32);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_id_groupe_projet`
-- 

CREATE TABLE `wp_id_groupe_projet` (
  `id_groupe` int(11) NOT NULL,
  `id_projet` int(11) NOT NULL,
  PRIMARY KEY (`id_groupe`,`id_projet`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `wp_id_groupe_projet`
-- 

INSERT INTO `wp_id_groupe_projet` VALUES (1, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 2);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 3);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 4);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 6);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 7);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 8);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 9);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 10);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 14);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 21);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 23);
INSERT INTO `wp_id_groupe_projet` VALUES (1, 84);
INSERT INTO `wp_id_groupe_projet` VALUES (3, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (3, 4);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 2);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 3);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 4);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 7);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 9);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 11);
INSERT INTO `wp_id_groupe_projet` VALUES (5, 23);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 4);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 5);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 7);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 9);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 10);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 11);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 13);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 14);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 23);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 27);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 37);
INSERT INTO `wp_id_groupe_projet` VALUES (6, 40);
INSERT INTO `wp_id_groupe_projet` VALUES (7, 12);
INSERT INTO `wp_id_groupe_projet` VALUES (7, 14);
INSERT INTO `wp_id_groupe_projet` VALUES (8, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (8, 25);
INSERT INTO `wp_id_groupe_projet` VALUES (8, 27);
INSERT INTO `wp_id_groupe_projet` VALUES (8, 29);
INSERT INTO `wp_id_groupe_projet` VALUES (9, 26);
INSERT INTO `wp_id_groupe_projet` VALUES (9, 41);
INSERT INTO `wp_id_groupe_projet` VALUES (10, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (10, 14);
INSERT INTO `wp_id_groupe_projet` VALUES (12, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (13, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (13, 12);
INSERT INTO `wp_id_groupe_projet` VALUES (13, 31);
INSERT INTO `wp_id_groupe_projet` VALUES (14, 14);
INSERT INTO `wp_id_groupe_projet` VALUES (14, 17);
INSERT INTO `wp_id_groupe_projet` VALUES (15, 14);
INSERT INTO `wp_id_groupe_projet` VALUES (17, 25);
INSERT INTO `wp_id_groupe_projet` VALUES (18, 14);
INSERT INTO `wp_id_groupe_projet` VALUES (21, 44);
INSERT INTO `wp_id_groupe_projet` VALUES (22, 27);
INSERT INTO `wp_id_groupe_projet` VALUES (24, 1);
INSERT INTO `wp_id_groupe_projet` VALUES (24, 41);
INSERT INTO `wp_id_groupe_projet` VALUES (24, 43);
INSERT INTO `wp_id_groupe_projet` VALUES (25, 42);
INSERT INTO `wp_id_groupe_projet` VALUES (35, 43);
INSERT INTO `wp_id_groupe_projet` VALUES (35, 44);
INSERT INTO `wp_id_groupe_projet` VALUES (37, 41);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_links`
-- 

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- Contenu de la table `wp_links`
-- 

INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '');
INSERT INTO `wp_links` VALUES (2, 'http://www.wordpress-fr.net/planet/', 'Blog WordPress', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://feeds2.feedburner.com/WordpressFrancophonePlanet');
INSERT INTO `wp_links` VALUES (3, 'http://www.wordpress-fr.net/support/', 'Forums d&rsquo;entraide en français', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '');
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/extend/plugins/', 'Extensions', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '');
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/themes/', 'Thèmes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '');
INSERT INTO `wp_links` VALUES (6, '<a href="http://www.wordpress-fr.net/support/">Forums d&rsquo;entraide</a>', 'Remarque', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '');
INSERT INTO `wp_links` VALUES (7, 'http://www.wordpress-fr.net/planet/', 'La planète WordPress', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_nm_convo`
-- 

CREATE TABLE `wp_nm_convo` (
  `convo_id` int(8) NOT NULL AUTO_INCREMENT,
  `started_by` int(7) NOT NULL,
  `started_with` int(7) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `convo_thread` mediumtext NOT NULL,
  `read_by` varchar(150) DEFAULT '0',
  `deleted_by` varchar(150) DEFAULT '0',
  `last_sent_by` int(7) NOT NULL,
  `sent_on` datetime NOT NULL,
  PRIMARY KEY (`convo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_nm_convo`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_options`
-- 

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3248 DEFAULT CHARSET=utf8 AUTO_INCREMENT=3248 ;

-- 
-- Contenu de la table `wp_options`
-- 

INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://www.gdnlteamtest.netsoro.net/wordpress', 'yes');
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Site UE Projet M1 Informatique', 'yes');
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes');
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes');
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'gdnlteam@gmail.com', 'yes');
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes');
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes');
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes');
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes');
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes');
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes');
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes');
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes');
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes');
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes');
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes');
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes');
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes');
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes');
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '0', 'yes');
INSERT INTO `wp_options` VALUES (21, 'default_post_edit_rows', '20', 'yes');
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes');
INSERT INTO `wp_options` VALUES (23, 'date_format', 'j F Y', 'yes');
INSERT INTO `wp_options` VALUES (24, 'time_format', 'G \\h i \\m\\i\\n', 'yes');
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'j F Y, G \\h i \\m\\i\\n', 'yes');
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_prepend', '<em>', 'yes');
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_append', '</em>', 'yes');
INSERT INTO `wp_options` VALUES (28, 'links_recently_updated_time', '120', 'yes');
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '0', 'yes');
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes');
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '', 'yes');
INSERT INTO `wp_options` VALUES (32, 'gzipcompression', '0', 'yes');
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes');
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes');
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no');
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:10:{i:0;s:31:"add-multiple-users/multiadd.php";i:1;s:30:"easing-slider/easingslider.php";i:2;s:21:"exec-php/exec-php.php";i:3;s:35:"login-with-ajax/login-with-ajax.php";i:4;s:19:"members/members.php";i:5;s:27:"simple-press/sp-control.php";i:6;s:33:"theme-my-login/theme-my-login.php";i:7;s:43:"user-access-manager/user-access-manager.php";i:8;s:27:"wp-filebase/wp-filebase.php";i:9;s:25:"wp-members/wp-members.php";}', 'yes');
INSERT INTO `wp_options` VALUES (37, 'home', 'http://www.gdnlteamtest.netsoro.net/wordpress', 'yes');
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes');
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes');
INSERT INTO `wp_options` VALUES (40, 'advanced_edit', '0', 'yes');
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes');
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '1', 'yes');
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes');
INSERT INTO `wp_options` VALUES (44, 'recently_edited', 'a:5:{i:0;s:79:"/homepages/18/d454359170/htdocs/wordpress/wp-content/themes/twentyten/style.css";i:2;s:85:"/homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/easing-slider/readme.txt";i:3;s:91:"/homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/easing-slider/easingslider.php";i:4;s:92:"/homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/add-multiple-users/multiadd.php";i:5;s:128:"/homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/nextgen-3d-flux-slider-template/nextgen-3D-flux-slider-template.php";}', 'no');
INSERT INTO `wp_options` VALUES (45, 'template', 'twentyten', 'yes');
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'twentyten', 'yes');
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes');
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no');
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '0', 'yes');
INSERT INTO `wp_options` VALUES (50, 'html_type', 'text/html', 'yes');
INSERT INTO `wp_options` VALUES (51, 'use_trackback', '0', 'yes');
INSERT INTO `wp_options` VALUES (52, 'default_role', 'subscriber', 'yes');
INSERT INTO `wp_options` VALUES (53, 'db_version', '21707', 'yes');
INSERT INTO `wp_options` VALUES (54, 'uploads_use_yearmonth_folders', '1', 'yes');
INSERT INTO `wp_options` VALUES (55, 'upload_path', '', 'yes');
INSERT INTO `wp_options` VALUES (56, 'blog_public', '0', 'yes');
INSERT INTO `wp_options` VALUES (57, 'default_link_category', '2', 'yes');
INSERT INTO `wp_options` VALUES (58, 'show_on_front', 'posts', 'yes');
INSERT INTO `wp_options` VALUES (59, 'tag_base', '', 'yes');
INSERT INTO `wp_options` VALUES (60, 'show_avatars', '1', 'yes');
INSERT INTO `wp_options` VALUES (61, 'avatar_rating', 'G', 'yes');
INSERT INTO `wp_options` VALUES (62, 'upload_url_path', '', 'yes');
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_w', '150', 'yes');
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_h', '150', 'yes');
INSERT INTO `wp_options` VALUES (65, 'thumbnail_crop', '1', 'yes');
INSERT INTO `wp_options` VALUES (66, 'medium_size_w', '300', 'yes');
INSERT INTO `wp_options` VALUES (67, 'medium_size_h', '300', 'yes');
INSERT INTO `wp_options` VALUES (68, 'avatar_default', 'mystery', 'yes');
INSERT INTO `wp_options` VALUES (69, 'enable_app', '0', 'yes');
INSERT INTO `wp_options` VALUES (70, 'enable_xmlrpc', '0', 'yes');
INSERT INTO `wp_options` VALUES (71, 'large_size_w', '1024', 'yes');
INSERT INTO `wp_options` VALUES (72, 'large_size_h', '1024', 'yes');
INSERT INTO `wp_options` VALUES (73, 'image_default_link_type', 'file', 'yes');
INSERT INTO `wp_options` VALUES (74, 'image_default_size', '', 'yes');
INSERT INTO `wp_options` VALUES (75, 'image_default_align', '', 'yes');
INSERT INTO `wp_options` VALUES (76, 'close_comments_for_old_posts', '0', 'yes');
INSERT INTO `wp_options` VALUES (77, 'close_comments_days_old', '14', 'yes');
INSERT INTO `wp_options` VALUES (78, 'thread_comments', '1', 'yes');
INSERT INTO `wp_options` VALUES (79, 'thread_comments_depth', '5', 'yes');
INSERT INTO `wp_options` VALUES (80, 'page_comments', '0', 'yes');
INSERT INTO `wp_options` VALUES (81, 'comments_per_page', '50', 'yes');
INSERT INTO `wp_options` VALUES (82, 'default_comments_page', 'newest', 'yes');
INSERT INTO `wp_options` VALUES (83, 'comment_order', 'asc', 'yes');
INSERT INTO `wp_options` VALUES (84, 'sticky_posts', 'a:0:{}', 'yes');
INSERT INTO `wp_options` VALUES (85, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (86, 'widget_text', 'a:0:{}', 'yes');
INSERT INTO `wp_options` VALUES (87, 'widget_rss', 'a:0:{}', 'yes');
INSERT INTO `wp_options` VALUES (88, 'uninstall_plugins', 'a:5:{s:43:"user-access-manager/user-access-manager.php";s:26:"userAccessManagerUninstall";s:33:"theme-my-login/theme-my-login.php";a:2:{i:0;s:20:"Theme_My_Login_Admin";i:1;s:9:"uninstall";}s:27:"wp-super-cache/wp-cache.php";s:23:"wpsupercache_deactivate";s:34:"easing-slider/easingsliderlite.php";a:2:{i:0;s:16:"EasingSliderLite";i:1;s:12:"do_uninstall";}s:30:"easing-slider/easingslider.php";s:20:"unset_easing_options";}', 'no');
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes');
INSERT INTO `wp_options` VALUES (90, 'embed_autourls', '1', 'yes');
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes');
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes');
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '0', 'yes');
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '0', 'yes');
INSERT INTO `wp_options` VALUES (95, 'default_post_format', '0', 'yes');
INSERT INTO `wp_options` VALUES (96, 'initial_db_version', '21707', 'yes');
INSERT INTO `wp_options` VALUES (97, 'wp_user_roles', 'a:8:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:78:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:25:"user_can_config_downloads";b:1;s:23:"user_can_edit_downloads";b:1;s:25:"user_can_add_new_download";b:1;s:27:"user_can_view_downloads_log";b:1;s:10:"list_roles";b:1;s:12:"create_roles";b:1;s:12:"delete_roles";b:1;s:10:"edit_roles";b:1;s:16:"restrict_content";b:1;s:16:"manage_downloads";b:1;s:18:"email_users_notify";b:1;s:17:"email_single_user";b:1;s:20:"email_multiple_users";b:1;s:17:"email_user_groups";b:1;s:8:"exec_php";b:1;s:15:"edit_others_php";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:17:{s:17:"manage_categories";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:9:"add_users";b:1;s:12:"create_users";b:1;s:16:"manage_downloads";b:1;s:25:"user_can_add_new_download";b:1;s:25:"user_can_config_downloads";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:12:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:17:"email_single_user";b:1;s:20:"email_multiple_users";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:17:"email_single_user";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"etudiant";a:2:{s:4:"name";s:8:"Etudiant";s:12:"capabilities";a:2:{s:4:"read";s:4:"true";s:13:"publish_posts";b:1;}}s:9:"encadrant";a:2:{s:4:"name";s:9:"Encadrant";s:12:"capabilities";a:1:{s:4:"read";s:4:"true";}}s:13:"responsableue";a:2:{s:4:"name";s:13:"ResponsableUE";s:12:"capabilities";a:20:{s:4:"read";s:4:"true";s:9:"add_users";b:1;s:12:"create_users";b:1;s:12:"delete_users";b:1;s:10:"edit_users";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:16:"manage_downloads";b:1;s:25:"user_can_add_new_download";b:1;s:14:"edit_dashboard";b:1;s:12:"remove_users";b:1;s:23:"user_can_edit_downloads";b:1;s:25:"user_can_config_downloads";b:1;s:14:"manage_options";b:1;s:8:"exec_php";b:1;s:15:"unfiltered_html";b:1;s:17:"unfiltered_upload";b:1;s:11:"update_core";b:1;s:20:"edit_published_pages";b:1;s:12:"upload_files";b:1;}}}', 'yes');
INSERT INTO `wp_options` VALUES (98, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (99, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (100, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (101, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (102, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (103, 'sidebars_widgets', 'a:8:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:1:{i:0;s:22:"members-widget-login-2";}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}s:13:"array_version";i:3;}', 'yes');
INSERT INTO `wp_options` VALUES (104, 'cron', 'a:10:{i:1387474273;a:1:{s:9:"wpfb_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1387475924;a:1:{s:14:"sph_stats_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1387493284;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1387493285;a:2:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1387534215;a:1:{s:14:"yoast_tracking";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1387536532;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1387536663;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1387537124;a:1:{s:26:"sph_transient_cleanup_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1387709925;a:1:{s:13:"sph_news_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:16:"sp_news_interval";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes');
INSERT INTO `wp_options` VALUES (106, '_site_transient_update_core', 'O:8:"stdClass":3:{s:7:"updates";a:2:{i:0;O:8:"stdClass":9:{s:8:"response";s:7:"upgrade";s:8:"download";s:47:"http://fr.wordpress.org/wordpress-3.8-fr_FR.zip";s:6:"locale";s:5:"fr_FR";s:8:"packages";O:8:"stdClass":4:{s:4:"full";s:47:"http://fr.wordpress.org/wordpress-3.8-fr_FR.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;}s:7:"current";s:3:"3.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":9:{s:8:"response";s:7:"upgrade";s:8:"download";s:38:"http://wordpress.org/wordpress-3.8.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":4:{s:4:"full";s:38:"http://wordpress.org/wordpress-3.8.zip";s:10:"no_content";s:49:"http://wordpress.org/wordpress-3.8-no-content.zip";s:11:"new_bundled";s:50:"http://wordpress.org/wordpress-3.8-new-bundled.zip";s:7:"partial";b:0;}s:7:"current";s:3:"3.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1387467405;s:15:"version_checked";s:5:"3.4.2";}', 'yes');
INSERT INTO `wp_options` VALUES (113, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:45:"http://www.gdnlteamtest.netsoro.net/wordpress";s:4:"link";s:121:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://www.gdnlteamtest.netsoro.net/wordpress/";s:3:"url";s:154:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://www.gdnlteamtest.netsoro.net/wordpress/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:35:"http://www.wordpress-fr.net/planet/";s:3:"url";s:55:"http://feeds2.feedburner.com/WordpressFrancophonePlanet";s:5:"title";s:14:"Blog WordPress";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:35:"http://www.wordpress-fr.net/planet/";s:3:"url";s:55:"http://feeds2.feedburner.com/WordpressFrancophonePlanet";s:5:"title";s:46:"Autres actualités de WordPress (en français)";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes');
INSERT INTO `wp_options` VALUES (133, 'can_compress_scripts', '1', 'yes');
INSERT INTO `wp_options` VALUES (145, '_site_transient_update_themes', 'O:8:"stdClass":3:{s:12:"last_checked";i:1387467405;s:7:"checked";a:2:{s:15:"northern-clouds";s:5:"1.2.3";s:9:"twentyten";s:3:"1.4";}s:8:"response";a:2:{s:15:"northern-clouds";a:3:{s:11:"new_version";s:5:"1.3.2";s:3:"url";s:43:"http://wordpress.org/themes/northern-clouds";s:7:"package";s:62:"http://wordpress.org/themes/download/northern-clouds.1.3.2.zip";}s:9:"twentyten";a:3:{s:11:"new_version";s:3:"1.6";s:3:"url";s:37:"http://wordpress.org/themes/twentyten";s:7:"package";s:54:"http://wordpress.org/themes/download/twentyten.1.6.zip";}}}', 'yes');
INSERT INTO `wp_options` VALUES (146, 'theme_mods_twentyeleven', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1363258200;s:4:"data";a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}s:9:"sidebar-4";a:0:{}s:9:"sidebar-5";a:0:{}}}}', 'yes');
INSERT INTO `wp_options` VALUES (147, 'current_theme', 'Twenty Ten', 'yes');
INSERT INTO `wp_options` VALUES (148, 'theme_mods_northern-clouds', 'a:5:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:3;}s:12:"header_image";s:20:"random-default-image";s:16:"header_textcolor";s:6:"D3D3D3";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1364203938;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:12:"sidebar-blog";a:2:{i:0;s:14:"recent-posts-2";i:1;s:10:"calendar-2";}s:12:"sidebar-page";a:0:{}}}}', 'yes');
INSERT INTO `wp_options` VALUES (149, 'theme_switched', '', 'yes');
INSERT INTO `wp_options` VALUES (151, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes');
INSERT INTO `wp_options` VALUES (158, 'category_children', 'a:0:{}', 'yes');
INSERT INTO `wp_options` VALUES (163, 'recently_activated', 'a:0:{}', 'yes');
INSERT INTO `wp_options` VALUES (169, 'wp_dlm_url', '', 'yes');
INSERT INTO `wp_options` VALUES (170, 'wp_dlm_type', 'ID', 'yes');
INSERT INTO `wp_options` VALUES (171, 'wp_dlm_default_format', '0', 'yes');
INSERT INTO `wp_options` VALUES (172, 'wp_dlm_does_not_exist', '', 'yes');
INSERT INTO `wp_options` VALUES (173, 'wp_dlm_image_url', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/plugins/download-monitor/img/download.gif', 'yes');
INSERT INTO `wp_options` VALUES (174, 'wp_dlm_log_downloads', 'no', 'yes');
INSERT INTO `wp_options` VALUES (175, 'wp_dlm_file_browser_root', 'C:\\wamp\\www\\wordpress/', 'yes');
INSERT INTO `wp_options` VALUES (176, 'wp_dlm_enable_file_browser', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (177, 'wp_dlm_auto_mirror', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (178, 'wp_dlm_global_member_only', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (179, 'wp_dlm_log_timeout', '0', 'yes');
INSERT INTO `wp_options` VALUES (180, 'wp_dlm_build', '20130120', 'yes');
INSERT INTO `wp_options` VALUES (188, 'amu_usernotify', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (189, 'amu_confirmation', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (190, 'amu_setallroles', 'notset', 'yes');
INSERT INTO `wp_options` VALUES (191, 'amu_validatestrict', 'no', 'yes');
INSERT INTO `wp_options` VALUES (192, 'amu_validatemail', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (193, 'amu_forcefill', 'no', 'yes');
INSERT INTO `wp_options` VALUES (194, 'amu_defadminemail', 'gdnlteam@gmail.com', 'yes');
INSERT INTO `wp_options` VALUES (195, 'amu_siteloginurl', 'http://www.gdnlteamtest.netsoro.net/wordpress', 'yes');
INSERT INTO `wp_options` VALUES (196, 'amu_useremailhead', 'Your New User Account Information on [sitename]', 'yes');
INSERT INTO `wp_options` VALUES (197, 'amu_useremailtext', '<h1>You have been registered as a user on [sitename]</h1>\n<p>You may now log into the site at [siteloginurl]</p>\n<p>Your username is [username] and your password is [password]</p>\n<p>Regards,<br>\n[sitename] Admin</p>\n<p>[siteurl]</p>', 'yes');
INSERT INTO `wp_options` VALUES (198, 'amu_showblankmeta', '', 'yes');
INSERT INTO `wp_options` VALUES (199, 'amu_dispnamedef', 'userlogin', 'yes');
INSERT INTO `wp_options` VALUES (200, 'amu_extrameta', '', 'yes');
INSERT INTO `wp_options` VALUES (201, 'amu_colorderpref', 'dynamic', 'yes');
INSERT INTO `wp_options` VALUES (202, 'amu_colorderpredef', '', 'yes');
INSERT INTO `wp_options` VALUES (204, 'members_db_version', '2', 'yes');
INSERT INTO `wp_options` VALUES (205, 'members_settings', 'a:8:{s:12:"role_manager";i:1;s:19:"content_permissions";i:1;s:25:"content_permissions_error";s:85:"<p class="restricted">Sorry, but you do not have permission to view this content.</p>";s:17:"login_form_widget";i:1;s:12:"users_widget";i:0;s:12:"private_blog";i:0;s:12:"private_feed";i:0;s:18:"private_feed_error";s:80:"<p class="restricted">You must be logged into the site to view this content.</p>";}', 'yes');
INSERT INTO `wp_options` VALUES (207, 'uamAdminOptions', 'a:32:{s:15:"hide_post_title";s:5:"false";s:10:"post_title";s:33:"Aucune autorisation d\\\\\\''accès !";s:12:"post_content";s:43:"Sorry you have no rights to view this post!";s:9:"hide_post";s:4:"true";s:17:"hide_post_comment";s:5:"false";s:20:"post_comment_content";s:63:"Désolé vous n\\\\\\''avez pas le droit de voir les commentaires !";s:20:"post_comments_locked";s:5:"false";s:15:"hide_page_title";s:5:"false";s:10:"page_title";s:33:"Aucune autorisation d\\\\\\''accès !";s:12:"page_content";s:64:"Désolé vous n\\\\\\''avez pas les droits pour afficher cette page!";s:9:"hide_page";s:4:"true";s:17:"hide_page_comment";s:5:"false";s:20:"page_comment_content";s:63:"Désolé vous n\\\\\\''avez pas le droit de voir les commentaires !";s:20:"page_comments_locked";s:5:"false";s:8:"redirect";s:4:"blog";s:20:"redirect_custom_page";s:1:"2";s:19:"redirect_custom_url";s:0:"";s:14:"lock_recursive";s:4:"true";s:25:"authors_has_access_to_own";s:4:"true";s:31:"authors_can_add_posts_to_groups";s:4:"true";s:9:"lock_file";s:5:"false";s:14:"file_pass_type";s:6:"random";s:15:"lock_file_types";s:3:"all";s:13:"download_type";s:5:"fopen";s:17:"locked_file_types";s:18:"zip,rar,tar,gz,bz2";s:21:"not_locked_file_types";s:16:"gif,jpg,jpeg,png";s:15:"blog_admin_hint";s:4:"true";s:20:"blog_admin_hint_text";s:0:"";s:21:"hide_empty_categories";s:4:"true";s:12:"protect_feed";s:4:"true";s:29:"show_post_content_before_more";s:5:"false";s:16:"full_access_role";s:13:"administrator";}', 'yes');
INSERT INTO `wp_options` VALUES (208, 'uam_db_version', '1.1', 'yes');
INSERT INTO `wp_options` VALUES (217, 'front_end_users_url_path', 'profile', 'yes');
INSERT INTO `wp_options` VALUES (218, 'front_end_users_display_custom_profile_settings', '0', 'yes');
INSERT INTO `wp_options` VALUES (219, 'front_end_users_options', 'a:3:{s:23:"roles_with_admin_access";a:1:{i:0;s:13:"responsableue";}s:8:"url_path";s:7:"profile";s:31:"display_custom_profile_settings";i:0;}', 'yes');
INSERT INTO `wp_options` VALUES (222, 'widget_members-widget-login', 'a:2:{i:2;a:15:{s:5:"title";s:6:"Log In";s:14:"label_username";s:8:"Username";s:14:"label_password";s:8:"Password";s:14:"label_remember";s:11:"Remember Me";s:12:"label_log_in";s:6:"Log In";s:11:"id_username";s:10:"user_login";s:11:"id_password";s:9:"user_pass";s:11:"id_remember";s:10:"rememberme";s:9:"id_submit";s:9:"wp-submit";s:14:"value_username";s:0:"";s:8:"remember";i:1;s:14:"value_remember";i:0;s:11:"show_avatar";i:1;s:14:"logged_in_text";s:28:"You are currently logged in.";s:15:"logged_out_text";s:25:"Please log into the site.";}s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (223, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (227, 'theme_my_login', 'a:8:{s:7:"page_id";i:67;s:9:"show_page";b:1;s:10:"enable_css";b:1;s:11:"email_login";b:1;s:14:"active_modules";a:1:{i:0;s:37:"custom-passwords/custom-passwords.php";}s:10:"permalinks";a:0:{}s:11:"initial_nag";i:0;s:7:"version";s:5:"6.2.3";}', 'yes');
INSERT INTO `wp_options` VALUES (228, 'widget_theme-my-login', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (244, 'wpuf_labels', '', 'yes');
INSERT INTO `wp_options` VALUES (245, 'wpuf_frontend_posting', '', 'yes');
INSERT INTO `wp_options` VALUES (246, 'wpuf_dashboard', '', 'yes');
INSERT INTO `wp_options` VALUES (247, 'wpuf_others', '', 'yes');
INSERT INTO `wp_options` VALUES (248, 'wpuf_payment', '', 'yes');
INSERT INTO `wp_options` VALUES (249, 'wpuf_support', '', 'yes');
INSERT INTO `wp_options` VALUES (260, '_transient_plugins_delete_result_1', 'O:8:"WP_Error":2:{s:6:"errors";a:1:{s:23:"could_not_remove_plugin";a:1:{i:0;s:97:"Impossible de supprimer complètement la ou les extensions download-manager/download-manager.php.";}}s:10:"error_data";a:0:{}}', 'yes');
INSERT INTO `wp_options` VALUES (266, 'wp_dlm_disable_news', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (267, 'wp_dlm_member_only', '', 'yes');
INSERT INTO `wp_options` VALUES (268, 'wp_dlm_ip_blacklist', '', 'yes');
INSERT INTO `wp_options` VALUES (539, 'delightful-downloads', 'a:9:{s:12:"members_only";i:1;s:16:"members_redirect";s:0:"";s:10:"enable_css";i:1;s:14:"cache_duration";s:1:"1";s:12:"default_text";s:8:"Download";s:13:"default_style";s:6:"button";s:13:"default_color";s:4:"blue";s:17:"upload_browse_dir";s:20:"/wp-content/uploads/";s:14:"reset_settings";i:0;}', 'yes');
INSERT INTO `wp_options` VALUES (543, 'wpdm_access_level', 'level_10', 'yes');
INSERT INTO `wp_options` VALUES (554, 'mailusers_version', '', 'yes');
INSERT INTO `wp_options` VALUES (555, 'mailusers_default_subject', '[%BLOG_NAME%] A post of interest: "%POST_TITLE%"', 'yes');
INSERT INTO `wp_options` VALUES (556, 'mailusers_default_body', '<p>Hello, </p><p>I would like to bring your attention on a new post published on the blog. Details of the post follow; I hope you will find it interesting.</p><p>Best regards, </p><p>%FROM_NAME%</p><hr><p><strong>%POST_TITLE%</strong></p><p>%POST_EXCERPT%</p><ul><li>Link to the post: <a href="%POST_URL%">%POST_URL%</a></li><li>Link to %BLOG_NAME%: <a href="%BLOG_URL%">%BLOG_URL%</a></li></ul>', 'yes');
INSERT INTO `wp_options` VALUES (557, 'mailusers_default_mail_format', 'html', 'yes');
INSERT INTO `wp_options` VALUES (558, 'mailusers_default_sort_users_by', 'none', 'yes');
INSERT INTO `wp_options` VALUES (559, 'mailusers_max_bcc_recipients', '0', 'yes');
INSERT INTO `wp_options` VALUES (560, 'mailusers_from_sender_name_override', '', 'yes');
INSERT INTO `wp_options` VALUES (561, 'mailusers_from_sender_address_override', '', 'yes');
INSERT INTO `wp_options` VALUES (562, 'mailusers_send_bounces_to_address_override', '', 'yes');
INSERT INTO `wp_options` VALUES (563, 'mailusers_user_settings_table_rows', '20', 'yes');
INSERT INTO `wp_options` VALUES (564, 'mailusers_default_notifications', 'true', 'yes');
INSERT INTO `wp_options` VALUES (565, 'mailusers_default_mass_email', 'true', 'yes');
INSERT INTO `wp_options` VALUES (566, 'mailusers_default_user_control', 'true', 'yes');
INSERT INTO `wp_options` VALUES (567, 'mailusers_shortcode_processing', 'false', 'yes');
INSERT INTO `wp_options` VALUES (568, 'mailusers_from_sender_exclude', 'true', 'yes');
INSERT INTO `wp_options` VALUES (569, 'amu_is_network', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (570, 'amu_subadminaccess', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (571, 'amu_addexistingaccess', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (572, 'amu_emailcopies', '', 'yes');
INSERT INTO `wp_options` VALUES (581, '_transient_random_seed', '24350c8a7b93f9cc364ec21b33e2bc4b', 'yes');
INSERT INTO `wp_options` VALUES (588, 'exec-php', 'a:2:{s:7:"version";s:3:"4.9";s:14:"widget_support";b:1;}', 'yes');
INSERT INTO `wp_options` VALUES (641, '_transient_timeout_feed_eebbfad72cfaf76c4edc5695ad275b05', '1364168066', 'no');
INSERT INTO `wp_options` VALUES (642, '_transient_feed_eebbfad72cfaf76c4edc5695ad275b05', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"\n  \n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:83:"\n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n    \n  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"link:http://www.gdnlteamtest.netsoro.net/wordpress/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.google.com/search?ie=utf-8&q=link:http://www.gdnlteamtest.netsoro.net/wordpress/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:20:"About 58,800 results";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"MyAzlan: INFORMATION SEEKING BEHAVIOURS OF RURAL <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://azlanyusof.blogspot.com/2013/03/information-seeking-behaviours-of-rural.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:242:"Diulas Jurnal dari laman website <em>http</em>://www.webpages.uidaho.edu/~mbolin/bakeri3.pdf. INFORMATION SEEKING BEHAVIOURS OF RURAL WOMEN. Ahmad Bakeri Abu Bakar <b>.....</b> LinkWithin. Related Posts Plugin for <em>WordPress</em>, Blogger.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:7:"MyAzlan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"AzlanYusof";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 24 Mar 2013 10:46:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"MyAzlan: PENSWASTAAN PEMBUANGAN SAMPAH (PBT)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://azlanyusof.blogspot.com/2013/03/penswastaan-pembuangan-sampah-pbt.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:241:"[3] <em>http</em>://blis2.bernama.com.eserv.uum.edu.my/mainHomeBypass.do. at 6:32 PM. No comments: Post a Comment &middot; Older Post Home. Subscribe to: Post Comments (Atom). LinkWithin. Related Posts Plugin for <em>WordPress</em>, Blogger.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:7:"MyAzlan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"AzlanYusof";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 24 Mar 2013 10:32:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Planet Eclipse";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:29:"http://www.planeteclipse.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:249:"About; Add your blog; Friends of Eclipse; <em>Links</em> <b>.....</b> The modeling symposium at EclipseCon North America 2013 takes place on Tuesday, March 26th from 5pm-6pm (see <em>http</em>://www.eclipsecon.org/2013/sessions/modelling-symposium).";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:18:"The Swordfish Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Oliver Wolf";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 24 Mar 2013 08:49:16 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"ruby on rails - Strip parameters from a GET-based url - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://stackoverflow.com/questions/15596336/strip-parameters-from-a-get-based-url";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:297:"These change the <em>link</em> from <em>http</em>://<em>www.gdnlteamtest.netsoro.net</em>:3000/orders/advanced_search to <em>http</em>://<em>www.gdnlteamtest.netsoro.net</em>:3000/orders/advanced_search?page=2&amp;sort_column=quantity&amp;order=asc . Now what I want to do is simple. I want to keep this values accessible to <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:33:"Recent Questions - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Pratik Bothra";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 24 Mar 2013 07:56:40 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"mysql - How to edit many values @ one time in PHP - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://stackoverflow.com/questions/15595006/how-to-edit-many-values-one-time-in-php";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:344:"<b>...</b> $_POST[&#39;$firstname&#39;], lastname = &#39;$lastname&#39;, rank = &#39;$rank&#39;, branch = &#39;$branch&#39;, gender = &#39;$gender&#39;, emailaddress = &#39;$emailaddress&#39; WHERE donorid= &#39;$donorid&#39;&quot;); mysqli_close($con); header( &#39;Location: <em>http</em>://<em>www.gdnlteamtest.netsoro.net</em>/moddonor.php&#39; ) ; <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:33:"Recent Questions - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Dustin Vicent";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 24 Mar 2013 03:57:53 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"Jquery UI - Setting a default Tab which use Content via Ajax - Stack <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://stackoverflow.com/questions/15594126/jquery-ui-setting-a-default-tab-which-use-content-via-ajax";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:391:"&lt;!doctype html&gt; &lt;html lang=&quot;en&quot;&gt; &lt;head&gt; &lt;meta charset=&quot;utf-8&quot; /&gt; &lt;title&gt;Test&lt;/title&gt; &lt;script src=&quot;<em>http</em>://code.jquery.com/jquery-1.9.1.js&quot;&gt;&lt;/script&gt; &lt;script src=&quot;<em>http</em>://code.jquery.com/ui/1.10.2/jquery-ui.js&quot;&gt;&lt;/script&gt; &lt;<em>link</em> rel=&quot;stylesheet&quot; <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:33:"Recent Questions - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Sid";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 24 Mar 2013 01:23:52 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"forms - php mysqli insert and update queries - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://stackoverflow.com/questions/15593423/php-mysqli-insert-and-update-queries";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:709:"DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.0 Transitional//EN&quot; &quot;<em>http</em>://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd&quot;&gt; &lt;html xmlns=&quot;<em>http</em>://www.w3.org/1999/xhtml&quot;&gt; &lt;head&gt; &lt;meta <em>http</em>-equiv=&quot;Content-Type&quot; content=&quot;text/html; <b>...</b> src = &quot; <em>http</em>://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js&quot;&gt;&lt;/script&gt; &lt;<em>link</em> href=&quot;style/stylesheet.css&quot;rel=&quot;stylesheet&quot; type=&quot;text/css&quot;/&gt; &lt;script type = &quot;text/javascript&quot;&gt; $(function(){ $(&#39;#submit&#39;).click(function(){ $(&#39;#container&#39;).append(&#39;&lt;img src <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:33:"Recent Questions - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"user2172837";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Mar 2013 23:49:33 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"cara instal joomla di <b>www.gdnlteamtest.netsoro.net</b> dengan xampp | sebuah inspirasi kecil";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://nusution.blogspot.com/2013/03/cara-instal-joomla-di-www.gdnlteamtest.netsoro.net-dengan.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:523:"Pada artikel sebelumnya sudah di bahas cara menginstal <em>wordpress</em>.Menginstal joomla hampir <b>...</b> joomla dalam bentuk folder.Kemudian copy ke htdocs pada xampp. langkah-langkahnya senagai berikut: 1.buatlah databasenya terlebih dahulu dengan cara ketik <em>http</em>://<em>www.gdnlteamtest.netsoro.net</em>/phpmyadmin/ pada address bar sobat seperti gambar berikut. 2. <b>...</b> bagi pengguna 3 AON jangan galau walaupun kuota kita habis tapi kita masih bisa nonton video.. nie ada sedikit <em>link</em> untuk nonton video...:D..";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:22:"sebuah inspirasi kecil";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"nungky";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Mar 2013 23:26:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"java - NOT a &quot;<b>www.gdnlteamtest.netsoro.net</b>&quot; socket networking example - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://stackoverflow.com/questions/15593024/not-a-www.gdnlteamtest.netsoro.net-socket-networking-example";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:276:"NOT a “<em>www.gdnlteamtest.netsoro.net</em>” socket networking example. up vote 0 down vote favorite. You might have <b>...</b> Know someone who can answer? Share a <em>link</em> to this question via email, Google+, Twitter, or Facebook. Your Answer. draft saved. draft discarded <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:33:"Recent Questions - Stack Overflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:18:"tiffanyButterfly23";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Mar 2013 22:52:01 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:47:"\n      \n      \n      \n      \n      \n      \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"cara instal worpress di <b>www.gdnlteamtest.netsoro.net</b> dengan xampp | sebuah inspirasi <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://nusution.blogspot.com/2013/03/cara-instal-worpress-di-www.gdnlteamtest.netsoro.net.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:530:"Langkah selanjutnya masuk ke <em>http</em>://<em>www.gdnlteamtest.netsoro.net</em>/<em>wordpress</em> nanti akan tampil seperti gambar berikut,kemudian klik Create a Configuration File 3.setelah itu nanti akan tampil seperti berikut kemudian klik let&#39;s go 4.kemudian akan tampil seprti berikut dan isikan database yang sudah di buat tadi. 5.Nanti akan ada tampilan <b>...</b> nonton video d youtube. bagi pengguna 3 AON jangan galau walaupun kuota kita habis tapi kita masih bisa nonton video.. nie ada sedikit <em>link</em> untuk nonton video .";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:22:"sebuah inspirasi kecil";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"nungky";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Mar 2013 22:20:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:5:"58800";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Sun, 24 Mar 2013 11:34:26 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=a0075eefae1bd507:FF=0:TM=1364124866:LM=1364124866:S=7IjjiufpdN4KkToP; expires=Tue, 24-Mar-2015 11:34:26 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=XEXeyvqd3jltIZrEgP0LvVxmjivsmVmvEd6SZ3R31yQE-kaJ-59gzZG5mKmmsiYiGzn58URYMdaU-G_Ahb_zUqgOMywBLRaCLJwiJ36105INWoaKYd3f-c-0VbkCtSln; expires=Mon, 23-Sep-2013 11:34:26 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";}s:5:"build";s:14:"20111015034325";}', 'no');
INSERT INTO `wp_options` VALUES (643, '_transient_timeout_feed_mod_eebbfad72cfaf76c4edc5695ad275b05', '1364168066', 'no');
INSERT INTO `wp_options` VALUES (644, '_transient_feed_mod_eebbfad72cfaf76c4edc5695ad275b05', '1364124866', 'no');
INSERT INTO `wp_options` VALUES (662, 'theme_mods_twentyten', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:3;}s:16:"background_color";s:6:"E6E6FA";}', 'yes');
INSERT INTO `wp_options` VALUES (718, '_site_transient_timeout_browser_7fd9ea81a2820d1be30701b7cd4a3044', '1364857063', 'yes');
INSERT INTO `wp_options` VALUES (719, '_site_transient_browser_7fd9ea81a2820d1be30701b7cd4a3044', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"25.0.1364.172";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (773, 'al_loadingtimeout', '1000', 'yes');
INSERT INTO `wp_options` VALUES (774, 'al_loginredirect', '', 'yes');
INSERT INTO `wp_options` VALUES (785, 'wpmembers_settings', 'a:12:{i:0;s:5:"2.8.1";i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;}', 'yes');
INSERT INTO `wp_options` VALUES (786, 'wpmembers_fields', 'a:9:{i:0;a:8:{i:0;i:1;i:1;s:7:"Prénom";i:2;s:10:"first_name";i:3;s:4:"text";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"y";i:7;s:0:"";}i:1;a:8:{i:0;i:2;i:1;s:14:"Nom de Famille";i:2;s:9:"last_name";i:3;s:4:"text";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"y";i:7;s:0:"";}i:2;a:8:{i:0;i:3;i:1;s:5:"Email";i:2;s:10:"user_email";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";i:7;s:0:"";}i:3;a:8:{i:0;i:4;i:1;s:13:"Site Internet";i:2;s:8:"user_url";i:3;s:4:"text";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"y";i:7;s:0:"";}i:4;a:8:{i:0;i:5;i:1;s:3:"AIM";i:2;s:3:"aim";i:3;s:4:"text";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"y";i:7;s:0:"";}i:5;a:8:{i:0;i:6;i:1;s:8:"Yahoo IM";i:2;s:3:"yim";i:3;s:4:"text";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"y";i:7;s:0:"";}i:6;a:8:{i:0;i:7;i:1;s:18:"Jabber/Google Talk";i:2;s:6:"jabber";i:3;s:4:"text";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"y";i:7;s:0:"";}i:7;a:8:{i:0;i:8;i:1;s:17:"Biographical Info";i:2;s:11:"description";i:3;s:8:"textarea";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"y";i:7;s:0:"";}i:8;a:9:{i:0;i:9;i:1;s:24:"Conditions d''Utilisation";i:2;s:3:"tos";i:3;s:8:"checkbox";i:4;s:0:"";i:5;s:0:"";i:6;s:1:"n";i:7;s:5:"agree";i:8;s:1:"n";}}', 'yes');
INSERT INTO `wp_options` VALUES (787, 'wpmembers_dialogs', 'a:9:{i:0;s:155:"Ce contenu est restreint aux membres. Si vous êtes un utilisateur enregistré, connectez vous. Les nouveaux utilisateurs peuvent s''enregistrer ci-dessous.";i:1;s:69:"Désolé, ce nom d''utilisateur est pris, veuillez en saisir un autre.";i:2;s:95:"Désolé, cette adrese email fait déjà l''objet d''un compte.<br />Veuillez en saisir une autre";i:3;s:169:"Félicitations! Votre inscription est complétée. <br /><br />Vous pouvez maintenant vous identifier en utilisant le mot de passe que nous vous avons envoyé par email.";i:4;s:41:"Vos informations ont été mises à jour.";i:5;s:67:"Les mots de passe ne concordent pas<br /><br />Veuillez réessayer.";i:6;s:136:"Le mot de passe a été correctement changé! <br /><br /> Vous allez devoir vous identifier de nouveau avec votre nouveau mot de passe.";i:7;s:74:"Le nom d''utilisateur ou le mot de passe n''existent pas dans nos registres.";i:8;s:209:"Password successfully reset!<br /><br />An email containing a new password has been sent to the email address on file for your account. You may change this random password then re-login with your new password.";}', 'yes');
INSERT INTO `wp_options` VALUES (788, 'wpmembers_tos', 'Put your TOS (Terms of Service) text here.  You can use HTML markup.', 'yes');
INSERT INTO `wp_options` VALUES (789, 'wpmembers_email_newreg', 'a:2:{s:4:"subj";s:37:"Your registration info for [blogname]";s:4:"body";s:268:"Thank you for registering for [blogname]\r\n\r\nYour registration information is below.\r\nYou may wish to retain a copy for your records.\r\n\r\nusername: [username]\r\npassword: [password]\r\n\r\nYou may login here:\r\n[reglink]\r\n\r\nYou may change your password here:\r\n[members-area]\r\n";}', 'yes');
INSERT INTO `wp_options` VALUES (790, 'wpmembers_email_newmod', 'a:2:{s:4:"subj";s:40:"Thank you for registering for [blogname]";s:4:"body";s:173:"Thank you for registering for [blogname]. \r\nYour registration has been received and is pending approval.\r\nYou will receive login instructions upon approval of your account\r\n";}', 'yes');
INSERT INTO `wp_options` VALUES (791, 'wpmembers_email_appmod', 'a:2:{s:4:"subj";s:50:"Your registration for [blogname] has been approved";s:4:"body";s:299:"Your registration for [blogname] has been approved.\r\n\r\nYour registration information is below.\r\nYou may wish to retain a copy for your records.\r\n\r\nusername: [username]\r\npassword: [password]\r\n\r\nYou may login and change your password here:\r\n[members-area]\r\n\r\nYou originally registered at:\r\n[reglink]\r\n";}', 'yes');
INSERT INTO `wp_options` VALUES (792, 'wpmembers_email_repass', 'a:2:{s:4:"subj";s:34:"Your password reset for [blogname]";s:4:"body";s:157:"Your password for [blogname] has been reset\r\n\r\nYour new password is included below. You may wish to retain a copy for your records.\r\n\r\npassword: [password]\r\n";}', 'yes');
INSERT INTO `wp_options` VALUES (793, 'wpmembers_email_notify', 'a:2:{s:4:"subj";s:36:"New user registration for [blogname]";s:4:"body";s:221:"The following user registered for [blogname] (and is pending approval)\r\n	\r\nusername: [username]\r\nemail: [email]\r\n\r\n[fields]\r\nThis user registered here:\r\n[reglink]\r\n\r\nuser IP: [user-ip]\r\n	\r\nactivate user: [activate-user]\r\n";}', 'yes');
INSERT INTO `wp_options` VALUES (794, 'wpmembers_email_footer', '----------------------------------\r\nThis is an automated message from [blogname]\r\nPlease do not reply to this address', 'yes');
INSERT INTO `wp_options` VALUES (795, 'wpmembers_style', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/plugins/wp-members/css/wp-members-2012.css', 'yes');
INSERT INTO `wp_options` VALUES (844, '_site_transient_timeout_browser_a3253abf03c9aa52230942f180418b1c', '1364906200', 'yes');
INSERT INTO `wp_options` VALUES (845, '_site_transient_browser_a3253abf03c9aa52230942f180418b1c', 'a:9:{s:8:"platform";s:5:"Linux";s:4:"name";s:13:"Mobile Safari";s:7:"version";s:6:"537.31";s:10:"update_url";s:0:"";s:7:"img_src";s:0:"";s:11:"img_src_ssl";s:0:"";s:15:"current_version";s:0:"";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (861, 'ossdl_off_cdn_url', 'http://www.gdnlteamtest.netsoro.net/wordpress', 'yes');
INSERT INTO `wp_options` VALUES (862, 'ossdl_off_include_dirs', 'wp-content,wp-includes', 'yes');
INSERT INTO `wp_options` VALUES (863, 'ossdl_off_exclude', '.php', 'yes');
INSERT INTO `wp_options` VALUES (864, 'ossdl_cname', '', 'yes');
INSERT INTO `wp_options` VALUES (870, 'fsb_settings', 'a:1:{s:5:"image";s:78:"http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/04/2.jpg";}', 'yes');
INSERT INTO `wp_options` VALUES (880, 'widget_loginwithajaxwidget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (898, 'lwa_data', 'a:4:{s:14:"login_redirect";s:46:"http://www.gdnlteamtest.netsoro.net/wordpress/";s:15:"logout_redirect";s:46:"http://www.gdnlteamtest.netsoro.net/wordpress/";s:20:"notification_subject";s:31:"Your registration at %BLOGNAME%";s:20:"notification_message";s:218:"Thanks for signing up to our blog. \r\n\r\nYou can login with the following credentials by visiting %BLOGURL%\r\n\r\nUsername : %USERNAME%\r\nPassword : %PASSWORD%\r\n\r\nWe look forward to your next visit!\r\n\r\nThe team at %BLOGNAME%";}', 'yes');
INSERT INTO `wp_options` VALUES (942, '_transient_timeout_feed_5a25458da46a336967a55e430a3eace5', '1364451956', 'no');
INSERT INTO `wp_options` VALUES (943, '_transient_feed_5a25458da46a336967a55e430a3eace5', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n\n\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:35:"\n	\n	\n	\n	\n	\n	\n	\n	\n	\n		\n		\n		\n		\n		\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"RocketGeek Interactive";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:21:"http://rocketgeek.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"Home of the WP-Members WordPress Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Mar 2013 18:13:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:5:{i:0;a:6:{s:4:"data";s:51:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"Email users when a new post is published";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://rocketgeek.com/tips-and-tricks/email-users-when-a-new-post-is-published/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:88:"http://rocketgeek.com/tips-and-tricks/email-users-when-a-new-post-is-published/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Mar 2013 15:15:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:15:"Tips and Tricks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"add_action";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"email";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:4:"wpdb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"wp_mail";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://rocketgeek.com/?p=2283";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:470:"This tip is a request from a user.  I like user requests &#8211; that makes it easier to deliver the kind of tutorials users are looking for instead of things I just come up with on my own. This particular tip will address how you can automatically send an email to all users when a...  <a href="http://rocketgeek.com/tips-and-tricks/email-users-when-a-new-post-is-published/" class="more-link" title="Read Email users when a new post is published">Read more &#187;</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:84:"http://rocketgeek.com/tips-and-tricks/email-users-when-a-new-post-is-published/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:54:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"Custom form field validation: numeric fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://rocketgeek.com/tips-and-tricks/custom-form-field-validation-numeric-fields/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:91:"http://rocketgeek.com/tips-and-tricks/custom-form-field-validation-numeric-fields/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 14:31:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:7:"Actions";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:15:"Tips and Tricks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:10:"add_action";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"is_int";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:10:"is_numeric";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:23:"wpmem_pre_register_data";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:21:"wpmem_pre_update_data";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://rocketgeek.com/?p=2262";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:513:"WP-Members has its own built-in form field validation for things like usernames, email, and required fields.  But what if you need to validate other elements, such as testing to see if an entered value is a number?  Yes, the plugin framework allows for you to extend the form field validation to whatever you need. In...  <a href="http://rocketgeek.com/tips-and-tricks/custom-form-field-validation-numeric-fields/" class="more-link" title="Read Custom form field validation: numeric fields">Read more &#187;</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:87:"http://rocketgeek.com/tips-and-tricks/custom-form-field-validation-numeric-fields/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:54:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Changing the activation link to a single click process";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://rocketgeek.com/filter-hooks/changing-the-activation-link-to-a-single-click-process/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://rocketgeek.com/filter-hooks/changing-the-activation-link-to-a-single-click-process/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 02 Mar 2013 16:51:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:7:"Filters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:15:"Tips and Tricks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"admin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:10:"admin_init";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:16:"current_user_can";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:11:"str_replace";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:18:"wpmem_notify_email";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://rocketgeek.com/?p=2161";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:538:"When moderating registration and sending admin notification emails, WP-Members has a shortcode in the email that allows you to click through to that particular user&#8217;s profile to activate them.  But what if you want the link itself to activate the user?  This tutorial will show you how to set up a process to make that...  <a href="http://rocketgeek.com/filter-hooks/changing-the-activation-link-to-a-single-click-process/" class="more-link" title="Read Changing the activation link to a single click process">Read more &#187;</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://rocketgeek.com/filter-hooks/changing-the-activation-link-to-a-single-click-process/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:48:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Blocking custom post types";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://rocketgeek.com/filter-hooks/blocking-custom-post-types/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://rocketgeek.com/filter-hooks/blocking-custom-post-types/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Feb 2013 15:56:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"Filters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:15:"Tips and Tricks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"filters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:13:"get_post_type";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"wpmem_block";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://rocketgeek.com/?p=2089";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:479:"With explosion of custom post types in WordPress 3.0, the WordPress world has changed somewhat from what it was when WP-Members was first developed.  If you have a theme or site that uses custom post types, you may find that you need to make some adjustments to accommodate what content you would like to be blocked. For...  <a href="http://rocketgeek.com/filter-hooks/blocking-custom-post-types/" class="more-link" title="Read Blocking custom post types">Read more &#187;</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://rocketgeek.com/filter-hooks/blocking-custom-post-types/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:36:"\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"WP-Members 2.8.2 beta release now available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://rocketgeek.com/release-announcements/wp-members-2-8-2-beta-release-now-available/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:97:"http://rocketgeek.com/release-announcements/wp-members-2-8-2-beta-release-now-available/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Feb 2013 22:42:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:21:"Release Announcements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://rocketgeek.com/?p=2080";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:545:"Current Release Candidate: RC 4 WP-Members 2.8.2 is both a feature release and a fix release.  Feature Updates There are some native fields in WordPress that, since they were not widely used were kind of overlooked by the WP-Members plugin.  I am changing that in this release, which will, among other things, improve the functionality of the...  <a href="http://rocketgeek.com/release-announcements/wp-members-2-8-2-beta-release-now-available/" class="more-link" title="Read WP-Members 2.8.2 beta release now available">Read more &#187;</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:93:"http://rocketgeek.com/release-announcements/wp-members-2-8-2-beta-release-now-available/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:27:"http://rocketgeek.com/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:4:"date";s:29:"Wed, 27 Mar 2013 18:22:38 GMT";s:6:"server";s:6:"Apache";s:10:"x-pingback";s:35:"http://rocketgeek.com/wp/xmlrpc.php";s:4:"etag";s:34:""60d0f8863a876e3bc16fec0b935c7391"";s:13:"last-modified";s:29:"Wed, 27 Mar 2013 18:13:06 GMT";s:4:"vary";s:15:"Accept-Encoding";s:10:"connection";s:5:"close";s:12:"content-type";s:23:"text/xml; charset=UTF-8";}s:5:"build";s:14:"20111015034325";}', 'no');
INSERT INTO `wp_options` VALUES (944, '_transient_timeout_feed_mod_5a25458da46a336967a55e430a3eace5', '1364451956', 'no');
INSERT INTO `wp_options` VALUES (945, '_transient_feed_mod_5a25458da46a336967a55e430a3eace5', '1364408756', 'no');
INSERT INTO `wp_options` VALUES (973, '_site_transient_timeout_browser_b4c18ecb06b751fa1bf7aec676f1e2e0', '1365455238', 'yes');
INSERT INTO `wp_options` VALUES (974, '_site_transient_browser_b4c18ecb06b751fa1bf7aec676f1e2e0', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"25.0.1364.172";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (1024, '_site_transient_timeout_browser_524bc892d6262ff099bceca9e958b2e6', '1365585573', 'yes');
INSERT INTO `wp_options` VALUES (1025, '_site_transient_browser_524bc892d6262ff099bceca9e958b2e6', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"26.0.1410.43";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (1059, '_site_transient_timeout_browser_263064a31c54f9718cf0f92088e8dc2c', '1365595618', 'yes');
INSERT INTO `wp_options` VALUES (1060, '_site_transient_browser_263064a31c54f9718cf0f92088e8dc2c', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"26.0.1410.43";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (1414, 'Yoast_Google_Analytics', 'a:44:{s:16:"advancedsettings";b:0;s:11:"allowanchor";b:0;s:9:"allowhash";b:0;s:11:"allowlinker";b:0;s:11:"anonymizeip";b:0;s:10:"customcode";s:0:"";s:11:"cv_loggedin";b:0;s:13:"cv_authorname";b:0;s:11:"cv_category";b:0;s:17:"cv_all_categories";b:0;s:7:"cv_tags";b:0;s:7:"cv_year";b:0;s:12:"cv_post_type";b:0;s:5:"debug";b:0;s:12:"dlextensions";s:30:"doc,exe,js,pdf,ppt,tgz,zip,xls";s:6:"domain";s:0:"";s:11:"domainorurl";s:6:"domain";s:7:"extrase";b:0;s:10:"extraseurl";s:0:"";s:11:"firebuglite";b:0;s:8:"ga_token";s:0:"";s:16:"ga_api_responses";a:0:{}s:16:"gajslocalhosting";b:0;s:7:"gajsurl";s:0:"";s:16:"ignore_userlevel";s:2:"11";s:12:"internallink";b:0;s:17:"internallinklabel";s:0:"";s:16:"outboundpageview";b:0;s:17:"downloadspageview";b:0;s:17:"othercrossdomains";s:0:"";s:8:"position";s:6:"footer";s:18:"primarycrossdomain";s:0:"";s:13:"theme_updated";b:0;s:16:"trackcommentform";b:1;s:16:"trackcrossdomain";b:0;s:12:"trackadsense";b:0;s:13:"trackoutbound";b:1;s:17:"trackregistration";b:0;s:14:"rsslinktagging";b:1;s:8:"uastring";s:0:"";s:7:"version";s:5:"4.3.3";s:3:"msg";s:0:"";s:14:"tracking_popup";s:4:"done";s:14:"yoast_tracking";b:1;}', 'yes');
INSERT INTO `wp_options` VALUES (1431, 'Yoast_Tracking_Hash', '16db3b9e09c37fdee7ba7dedbf3c04c5', 'yes');
INSERT INTO `wp_options` VALUES (1432, '_transient_timeout_yoast_tracking_cache', '1367057416', 'no');
INSERT INTO `wp_options` VALUES (1433, '_transient_yoast_tracking_cache', '1', 'no');
INSERT INTO `wp_options` VALUES (1525, 'ga_version', '6.4.3', 'yes');
INSERT INTO `wp_options` VALUES (1526, 'ga_status', 'enabled', 'yes');
INSERT INTO `wp_options` VALUES (1527, 'ga_uid', 'UA-XXXXXXXX-X', 'yes');
INSERT INTO `wp_options` VALUES (1528, 'ga_admin_status', 'enabled', 'yes');
INSERT INTO `wp_options` VALUES (1529, 'ga_admin_disable', 'remove', 'yes');
INSERT INTO `wp_options` VALUES (1530, 'ga_admin_role', 'a:1:{i:0;s:13:"administrator";}', 'yes');
INSERT INTO `wp_options` VALUES (1531, 'ga_dashboard_role', 'a:8:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:6:"author";i:3;s:11:"contributor";i:4;s:10:"subscriber";i:5;s:8:"etudiant";i:6;s:9:"encadrant";i:7;s:13:"responsableue";}', 'yes');
INSERT INTO `wp_options` VALUES (1532, 'ga_adsense', '', 'yes');
INSERT INTO `wp_options` VALUES (1533, 'ga_extra', '', 'yes');
INSERT INTO `wp_options` VALUES (1534, 'ga_extra_after', '', 'yes');
INSERT INTO `wp_options` VALUES (1535, 'ga_event', 'enabled', 'yes');
INSERT INTO `wp_options` VALUES (1536, 'ga_outbound', 'enabled', 'yes');
INSERT INTO `wp_options` VALUES (1537, 'ga_outbound_prefix', 'outgoing', 'yes');
INSERT INTO `wp_options` VALUES (1538, 'ga_downloads', '', 'yes');
INSERT INTO `wp_options` VALUES (1539, 'ga_downloads_prefix', 'download', 'yes');
INSERT INTO `wp_options` VALUES (1540, 'ga_widgets', 'enabled', 'yes');
INSERT INTO `wp_options` VALUES (1541, 'ga_annon', '0', 'yes');
INSERT INTO `wp_options` VALUES (1542, 'ga_defaults', 'no', 'yes');
INSERT INTO `wp_options` VALUES (1543, 'ga_google_token', 'UA-40264956-2', 'yes');
INSERT INTO `wp_options` VALUES (1709, 'sparkops_responsive-select-menu', 'a:18:{s:16:"current-panel-id";s:12:"basic-config";s:14:"max-menu-width";s:3:"960";s:14:"max-menu-depth";s:1:"0";s:6:"spacer";s:4:"– ";s:14:"exclude-hashes";s:2:"on";s:10:"first_item";s:12:"⇒ Navigate";s:16:"current_selected";s:2:"on";s:31:"activate_theme_locations_header";s:0:"";s:28:"activate_theme_locations_all";s:2:"on";s:22:"active_theme_locations";s:0:"";s:12:"display_only";s:0:"";s:9:"uber-info";s:0:"";s:12:"uber-enabled";s:3:"off";s:21:"uber-exclude-nonlinks";s:2:"on";s:19:"uber-exclude-notext";s:2:"on";s:20:"uber-exclude-sidebar";s:2:"on";s:30:"uber-exclude-content-overrides";s:2:"on";s:11:"ss_products";s:0:"";}', 'yes');
INSERT INTO `wp_options` VALUES (1782, 'widget_pw_login_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (1807, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (1808, 'widget_wpdm_newpacks_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (1810, 'widget_dc_jqdrilldown_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (1814, 'widget_dc_jqverticalmegamenu_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `wp_options` VALUES (1826, 'wpdm_login_msg', '1', 'yes');
INSERT INTO `wp_options` VALUES (1837, '_transient_timeout_dlm_categories', '1367877213', 'no');
INSERT INTO `wp_options` VALUES (1838, '_transient_dlm_categories', 'a:0:{}', 'no');
INSERT INTO `wp_options` VALUES (1839, '_transient_timeout_dlm_tags', '1367877213', 'no');
INSERT INTO `wp_options` VALUES (1840, '_transient_dlm_tags', 'a:0:{}', 'no');
INSERT INTO `wp_options` VALUES (1841, '_transient_timeout_dlm_used_tags', '1367877213', 'no');
INSERT INTO `wp_options` VALUES (1842, '_transient_dlm_used_tags', 'a:0:{}', 'no');
INSERT INTO `wp_options` VALUES (1844, 'wpfilebase', 'a:83:{s:11:"upload_path";s:27:"wp-content/uploads/filebase";s:14:"thumbnail_size";i:120;s:14:"thumbnail_path";s:0:"";s:15:"base_auto_thumb";s:1:"1";s:14:"fext_blacklist";s:6:"db,tmp";s:10:"attach_pos";s:1:"1";s:11:"attach_loop";s:0:"";s:17:"auto_attach_files";s:1:"1";s:16:"filelist_sorting";s:17:"file_display_name";s:20:"filelist_sorting_dir";s:1:"0";s:12:"filelist_num";i:0;s:16:"file_date_format";s:5:"j F Y";s:20:"bitrate_unregistered";i:0;s:18:"bitrate_registered";i:0;s:11:"traffic_day";i:0;s:13:"traffic_month";i:0;s:20:"traffic_exceeded_msg";s:47:"Traffic limit exceeded! Please try again later.";s:16:"file_offline_msg";s:31:"This file is currently offline.";s:17:"daily_user_limits";s:0:"";s:22:"daily_limit_subscriber";i:5;s:23:"daily_limit_contributor";i:10;s:18:"daily_limit_author";i:15;s:18:"daily_limit_editor";i:20;s:24:"daily_limit_exceeded_msg";s:39:"You can only download %d files per day.";s:18:"disable_permalinks";s:0:"";s:13:"download_base";s:8:"download";s:20:"file_browser_post_id";i:31;s:24:"file_browser_cat_sort_by";s:8:"cat_name";s:25:"file_browser_cat_sort_dir";s:1:"0";s:25:"file_browser_file_sort_by";s:17:"file_display_name";s:26:"file_browser_file_sort_dir";s:1:"0";s:16:"file_browser_fbc";s:0:"";s:15:"small_icon_size";i:32;s:13:"cat_drop_down";s:0:"";s:14:"force_download";s:0:"";s:14:"range_download";s:1:"1";s:10:"hide_links";s:0:"";s:16:"ignore_admin_dls";s:1:"1";s:17:"hide_inaccessible";s:1:"1";s:16:"inaccessible_msg";s:40:"You are not allowed to access this file!";s:21:"inaccessible_redirect";s:0:"";s:20:"cat_inaccessible_msg";s:26:"Access to category denied!";s:18:"login_redirect_src";s:0:"";s:12:"http_nocache";s:0:"";s:14:"parse_tags_rss";s:0:"";s:23:"allow_srv_script_upload";s:0:"";s:19:"protect_upload_path";s:1:"1";s:13:"private_files";s:0:"";s:15:"frontend_upload";s:0:"";s:21:"accept_empty_referers";s:1:"1";s:16:"allowed_referers";s:0:"";s:13:"use_fpassthru";s:0:"";s:19:"decimal_size_format";s:0:"";s:9:"admin_bar";s:1:"1";s:9:"cron_sync";s:0:"";s:20:"remove_missing_files";s:0:"";s:18:"search_integration";s:1:"1";s:17:"search_result_tpl";s:7:"default";s:11:"disable_id3";s:0:"";s:10:"search_id3";s:1:"1";s:13:"use_path_tags";s:0:"";s:18:"no_name_formatting";s:0:"";s:22:"disable_footer_credits";s:1:"1";s:20:"footer_credits_style";s:58:"margin:0 auto 2px auto; text-align:center; font-size:11px;";s:19:"late_script_loading";s:0:"";s:14:"default_author";s:0:"";s:13:"default_roles";a:0:{}s:11:"default_cat";i:0;s:9:"languages";s:21:"English|en\nDeutsch|de";s:9:"platforms";s:134:"Windows 95|win95\n*Windows 98|win98\n*Windows 2000|win2k\n*Windows XP|winxp\n*Windows Vista|vista\n*Windows 7|win7\nLinux|linux\nMac OS X|mac";s:8:"licenses";s:275:"*Freeware|free\nShareware|share\nGNU General Public License|gpl|http://www.gnu.org/copyleft/gpl.html\nGNU Lesser General Public License|lgpl\nGNU Affero General Public License|agpl\nCC Attribution-NonCommercial-ShareAlike|ccbyncsa|http://creativecommons.org/licenses/by-nc-sa/3.0/";s:12:"requirements";s:341:"PDF Reader|pdfread|http://www.foxitsoftware.com/pdf/reader/addons.php\nJava|java|http://www.java.com/download/\nFlash|flash|http://get.adobe.com/flashplayer/\nOpen Office|ooffice|http://www.openoffice.org/download/index.html\n.NET Framework 3.5|.net35|http://www.microsoft.com/downloads/details.aspx?FamilyID=333325fd-ae52-4e35-b531-508d977d32a6";s:22:"default_direct_linking";s:1:"1";s:13:"custom_fields";s:37:"Custom Field 1|cf1\nCustom Field 2|cf2";s:13:"template_file";s:1940:"<div class="wpfilebase-file-default" onclick="if(''undefined'' == typeof event.target.href) document.getElementById(''wpfb-file-link-%uid%'').click();">\r\n  <div class="icon"><a href="%file_url%" target="_blank" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" alt="%file_display_name%" /></a></div>\r\n  <div class="filetitle">\r\n    <a href="%file_url%" title="Download %file_display_name%" target="_blank" id="wpfb-file-link-%uid%">%file_display_name%</a>\r\n    <!-- IF %file_post_id% AND %post_id% != %file_post_id% --><a href="%file_post_url%" class="postlink">» %''Post''%</a><!-- ENDIF -->\r\n    <br />\r\n    %file_name%<br />\r\n    <!-- IF %file_version% -->%''Version:''% %file_version%<br /><!-- ENDIF -->\r\n  </div>\r\n  <div class="info">\r\n    %file_size%<br />\r\n    %file_hits% %''Downloads''%<br />\r\n    <a href="#" onclick="return wpfilebase_filedetails(%uid%);">%''Details''%</a>\r\n  </div>\r\n  <div class="details" id="wpfilebase-filedetails%uid%" style="display: none;">\r\n  <!-- IF %file_description% --><p>%file_description%</p><!-- ENDIF -->\r\n  <table border="0">\r\n   <!-- IF %file_languages% --><tr><td><strong>%''Languages''%:</strong></td><td>%file_languages%</td></tr><!-- ENDIF -->\r\n   <!-- IF %file_author% --><tr><td><strong>%''Author''%:</strong></td><td>%file_author%</td></tr><!-- ENDIF -->\r\n   <!-- IF %file_platforms% --><tr><td><strong>%''Platforms''%:</strong></td><td>%file_platforms%</td></tr><!-- ENDIF -->\r\n   <!-- IF %file_requirements% --><tr><td><strong>%''Requirements''%:</strong></td><td>%file_requirements%</td></tr><!-- ENDIF -->\r\n   <!-- IF %file_category% --><tr><td><strong>%''Category:''%</strong></td><td>%file_category%</td></tr><!-- ENDIF -->\r\n   <!-- IF %file_license% --><tr><td><strong>%''License''%:</strong></td><td>%file_license%</td></tr><!-- ENDIF -->\r\n   <tr><td><strong>%''Date''%:</strong></td><td>%file_date%</td></tr>\r\n  </table>\r\n  </div>\r\n <div style="clear: both;"></div>\r\n</div>";s:12:"template_cat";s:308:"<div class="wpfilebase-cat-default">\r\n  <h3>\r\n    <!-- IF %cat_has_icon% || true -->%cat_small_icon%<!-- ENDIF -->\r\n    <a href="%cat_url%" title="Go to category %cat_name%">%cat_name%</a>\r\n    <span>%cat_num_files% <!-- IF %cat_num_files% == 1 -->file<!-- ELSE -->files<!-- ENDIF --></span>\r\n  </h3>\r\n</div>";s:10:"dlclick_js";s:220:"if(typeof pageTracker == ''object'') {\r\n	pageTracker._trackPageview(file_url); // new google analytics tracker\r\n} else if(typeof urchinTracker == ''function'') {	\r\n	urchinTracker(file_url); // old google analytics tracker\r\n}";s:6:"widget";a:0:{}s:7:"version";s:8:"0.2.9.36";s:7:"tag_ver";i:2;s:20:"template_file_parsed";s:2746:"''<div class="wpfilebase-file-default" onclick="if(\\''undefined\\'' == typeof event.target.href) document.getElementById(\\''wpfb-file-link-''.$f->get_tpl_var(''uid'').''\\'').click();">\r\n  <div class="icon"><a href="''.$f->get_tpl_var(''file_url'').''" target="_blank" title="Download ''.$f->get_tpl_var(''file_display_name'').''"><img align="middle" src="''.$f->get_tpl_var(''file_icon_url'').''" alt="''.$f->get_tpl_var(''file_display_name'').''" /></a></div>\r\n  <div class="filetitle">\r\n    <a href="''.$f->get_tpl_var(''file_url'').''" title="Download ''.$f->get_tpl_var(''file_display_name'').''" target="_blank" id="wpfb-file-link-''.$f->get_tpl_var(''uid'').''">''.$f->get_tpl_var(''file_display_name'').''</a>\r\n    ''.((($f->get_tpl_var(''file_post_id'')) && get_the_ID() != ($f->get_tpl_var(''file_post_id'')))?(''<a href="''.$f->get_tpl_var(''file_post_url'').''" class="postlink">» ''.__(__(''Post'', WPFB)).''</a>''):('''')).''\r\n    <br />\r\n    ''.$f->get_tpl_var(''file_name'').''<br />\r\n    ''.((($f->get_tpl_var(''file_version'')))?(''''.__(__(''Version:'', WPFB)).'' ''.$f->get_tpl_var(''file_version'').''<br />''):('''')).''\r\n  </div>\r\n  <div class="info">\r\n    ''.$f->get_tpl_var(''file_size'').''<br />\r\n    ''.$f->get_tpl_var(''file_hits'').'' ''.__(__(''Downloads'', WPFB)).''<br />\r\n    <a href="#" onclick="return wpfilebase_filedetails(''.$f->get_tpl_var(''uid'').'');">''.__(__(''Details'', WPFB)).''</a>\r\n  </div>\r\n  <div class="details" id="wpfilebase-filedetails''.$f->get_tpl_var(''uid'').''" style="display: none;">\r\n  ''.((($f->get_tpl_var(''file_description'')))?(''<p>''.$f->get_tpl_var(''file_description'').''</p>''):('''')).''\r\n  <table border="0">\r\n   ''.((($f->get_tpl_var(''file_languages'')))?(''<tr><td><strong>''.__(__(''Languages'', WPFB)).'':</strong></td><td>''.$f->get_tpl_var(''file_languages'').''</td></tr>''):('''')).''\r\n   ''.((($f->get_tpl_var(''file_author'')))?(''<tr><td><strong>''.__(__(''Author'', WPFB)).'':</strong></td><td>''.$f->get_tpl_var(''file_author'').''</td></tr>''):('''')).''\r\n   ''.((($f->get_tpl_var(''file_platforms'')))?(''<tr><td><strong>''.__(__(''Platforms'', WPFB)).'':</strong></td><td>''.$f->get_tpl_var(''file_platforms'').''</td></tr>''):('''')).''\r\n   ''.((($f->get_tpl_var(''file_requirements'')))?(''<tr><td><strong>''.__(__(''Requirements'', WPFB)).'':</strong></td><td>''.$f->get_tpl_var(''file_requirements'').''</td></tr>''):('''')).''\r\n   ''.((($f->get_tpl_var(''file_category'')))?(''<tr><td><strong>''.__(__(''Category:'', WPFB)).''</strong></td><td>''.$f->get_tpl_var(''file_category'').''</td></tr>''):('''')).''\r\n   ''.((($f->get_tpl_var(''file_license'')))?(''<tr><td><strong>''.__(__(''License'', WPFB)).'':</strong></td><td>''.$f->get_tpl_var(''file_license'').''</td></tr>''):('''')).''\r\n   <tr><td><strong>''.__(__(''Date'', WPFB)).'':</strong></td><td>''.$f->get_tpl_var(''file_date'').''</td></tr>\r\n  </table>\r\n  </div>\r\n <div style="clear: both;"></div>\r\n</div>''";s:19:"template_cat_parsed";s:424:"''<div class="wpfilebase-cat-default">\r\n  <h3>\r\n    ''.((($f->get_tpl_var(''cat_has_icon'')) || true)?(''''.$f->get_tpl_var(''cat_small_icon'').''''):('''')).''\r\n    <a href="''.$f->get_tpl_var(''cat_url'').''" title="Go to category ''.$f->get_tpl_var(''cat_name'').''">''.$f->get_tpl_var(''cat_name'').''</a>\r\n    <span>''.$f->get_tpl_var(''cat_num_files'').'' ''.((($f->get_tpl_var(''cat_num_files'')) == 1)?(''file''):(''files'')).''</span>\r\n  </h3>\r\n</div>''";s:13:"traffic_stats";a:3:{s:5:"month";i:8200657;s:5:"today";i:2795271;s:4:"time";i:1380804207;}}', 'yes');
INSERT INTO `wp_options` VALUES (1845, 'wpfilebase_ftags', 'a:1:{s:0:"";i:4;}', 'no');
INSERT INTO `wp_options` VALUES (1846, 'wpfilebase_tpls_file', 'a:9:{s:11:"filebrowser";s:113:"%file_small_icon% <a href="%file_url%" title="Download %file_display_name%">%file_display_name%</a> (%file_size%)";s:15:"download-button";s:485:"<style type="text/css" media="screen">\r\n	.wpfb-dlbtn div { width:250px; height:40px; margin:0; padding:0; background:transparent url(''%wpfb_url%/images/dl_btn.png'') no-repeat top center;}\r\n	.wpfb-dlbtn div:hover { background-image: url(%wpfb_url%/images/dl_btn_hover.png); }\r\n</style>\r\n<div style="text-align:center; width:250px; margin: auto; font-size:smaller;"><a href="%file_url%" class="wpfb-dlbtn"><div></div></a>\r\n%file_display_name% (%file_size%, %file_hits% downloads)\r\n</div>";s:9:"image_320";s:284:"[caption id="file_%file_id%" align="alignnone" width="320" caption="<!-- IF %file_description% -->%file_description%<!-- ELSE -->%file_display_name%<!-- ENDIF -->"]<img class="size-full" title="%file_display_name%" src="%file_url%" alt="%file_display_name%" width="320" />[/caption]\n\n";s:9:"thumbnail";s:146:"<div class="wpfilebase-fileicon"><a href="%file_url%" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" /></a></div>\n";s:6:"simple";s:175:"<p><img src="%file_icon_url%" style="height:20px;vertical-align:middle;" /> <a href="%file_url%" title="Download %file_display_name%">%file_display_name%</a> (%file_size%)</p>";s:9:"3-col-row";s:102:"<tr><td><a href="%file_url%">%file_display_name%</a></td><td>%file_size%</td><td>%file_hits%</td></tr>";s:3:"mp3";s:845:"<div class="wpfilebase-attachment">\r\n <div class="wpfilebase-fileicon"><a href="%file_url%" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" alt="%file_display_name%" height="80"/></a></div>\r\n <div class="wpfilebase-rightcol">\r\n  <div class="wpfilebase-filetitle">\r\n   <a href="%file_url%" title="Download %file_display_name%">%file_info/tags/id3v2/title%</a><br />\r\n%file_info/tags/id3v2/artist%<br />\r\n%file_info/tags/id3v2/album%<br />\r\n   <!-- IF %file_post_id% AND %post_id% != %file_post_id% --><a href="%file_post_url%" class="wpfilebase-postlink">%''View post''%</a><!-- ENDIF -->\r\n  </div>\r\n </div>\r\n <div class="wpfilebase-fileinfo">\r\n  %file_info/playtime_string%<br />\r\n  %file_info/bitrate%<br />\r\n  %file_size%<br />\r\n  %file_hits% %''Downloads''%<br />\r\n </div>\r\n <div style="clear: both;"></div>\r\n</div>";s:10:"flv-player";s:894:"<!-- the player only works when permalinks are enabled!!! -->\r\n <object width=''%file_info/video/resolution_x%'' height=''%file_info/video/resolution_y%'' id=''flvPlayer%uid%''>\r\n  <param name=''allowFullScreen'' value=''true''>\r\n   <param name=''allowScriptAccess'' value=''always''> \r\n  <param name=''movie'' value=''%wpfb_url%extras/flvplayer/OSplayer.swf?movie=%file_url_encoded%&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=%file_display_name%&showTitle=yes''>\r\n  <embed src=''%wpfb_url%extras/flvplayer/OSplayer.swf?movie=%file_url_encoded%&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=%file_display_name%&showTitle=yes'' width=''%file_info/video/resolution_x%'' height=''%file_info/video/resolution_y%'' allowFullScreen=''true'' type=''application/x-shockwave-flash'' allowScriptAccess=''always''>\r\n </object>";s:10:"data-table";s:102:"<tr><td><a href="%file_url%">%file_display_name%</a></td><td>%file_size%</td><td>%file_hits%</td></tr>";}', 'no');
INSERT INTO `wp_options` VALUES (1847, 'wpfilebase_tpls_cat', 'a:3:{s:11:"filebrowser";s:75:"%cat_small_icon% <a href="%cat_url%" onclick="return false;">%cat_name%</a>";s:9:"3-col-row";s:82:"<tr><td colspan="3" style="text-align:center;font-size:120%;">%cat_name%</td></tr>";s:10:"data-table";s:61:"<!-- EMPTY: categories should not be listed in DataTables -->";}', 'no');
INSERT INTO `wp_options` VALUES (1848, 'wpfilebase_ptpls_file', 'a:9:{s:11:"filebrowser";s:220:"''''.$f->get_tpl_var(''file_small_icon'').'' <a href="''.$f->get_tpl_var(''file_url'').''" title="Download ''.$f->get_tpl_var(''file_display_name'').''">''.$f->get_tpl_var(''file_display_name'').''</a> (''.$f->get_tpl_var(''file_size'').'')''";s:15:"download-button";s:593:"''<style type="text/css" media="screen">\r\n	.wpfb-dlbtn div { width:250px; height:40px; margin:0; padding:0; background:transparent url(\\''''.(WPFB_PLUGIN_URI).''images/dl_btn.png\\'') no-repeat top center;}\r\n	.wpfb-dlbtn div:hover { background-image: url(''.(WPFB_PLUGIN_URI).''images/dl_btn_hover.png); }\r\n</style>\r\n<div style="text-align:center; width:250px; margin: auto; font-size:smaller;"><a href="''.$f->get_tpl_var(''file_url'').''" class="wpfb-dlbtn"><div></div></a>\r\n''.$f->get_tpl_var(''file_display_name'').'' (''.$f->get_tpl_var(''file_size'').'', ''.$f->get_tpl_var(''file_hits'').'' downloads)\r\n</div>''";s:9:"image_320";s:410:"''[caption id="file_''.$f->get_tpl_var(''file_id'').''" align="alignnone" width="320" caption="''.((($f->get_tpl_var(''file_description'')))?(''''.$f->get_tpl_var(''file_description'').''''):(''''.$f->get_tpl_var(''file_display_name'').'''')).''"]<img class="size-full" title="''.$f->get_tpl_var(''file_display_name'').''" src="''.$f->get_tpl_var(''file_url'').''" alt="''.$f->get_tpl_var(''file_display_name'').''" width="320" />[/caption]\n\n''";s:9:"thumbnail";s:211:"''<div class="wpfilebase-fileicon"><a href="''.$f->get_tpl_var(''file_url'').''" title="Download ''.$f->get_tpl_var(''file_display_name'').''"><img align="middle" src="''.$f->get_tpl_var(''file_icon_url'').''" /></a></div>\n''";s:6:"simple";s:282:"''<p><img src="''.$f->get_tpl_var(''file_icon_url'').''" style="height:20px;vertical-align:middle;" /> <a href="''.$f->get_tpl_var(''file_url'').''" title="Download ''.$f->get_tpl_var(''file_display_name'').''">''.$f->get_tpl_var(''file_display_name'').''</a> (''.$f->get_tpl_var(''file_size'').'')</p>''";s:9:"3-col-row";s:188:"''<tr><td><a href="''.$f->get_tpl_var(''file_url'').''">''.$f->get_tpl_var(''file_display_name'').''</a></td><td>''.$f->get_tpl_var(''file_size'').''</td><td>''.$f->get_tpl_var(''file_hits'').''</td></tr>''";s:3:"mp3";s:1205:"''<div class="wpfilebase-attachment">\r\n <div class="wpfilebase-fileicon"><a href="''.$f->get_tpl_var(''file_url'').''" title="Download ''.$f->get_tpl_var(''file_display_name'').''"><img align="middle" src="''.$f->get_tpl_var(''file_icon_url'').''" alt="''.$f->get_tpl_var(''file_display_name'').''" height="80"/></a></div>\r\n <div class="wpfilebase-rightcol">\r\n  <div class="wpfilebase-filetitle">\r\n   <a href="''.$f->get_tpl_var(''file_url'').''" title="Download ''.$f->get_tpl_var(''file_display_name'').''">''.$f->get_tpl_var(''file_info/tags/id3v2/title'').''</a><br />\r\n''.$f->get_tpl_var(''file_info/tags/id3v2/artist'').''<br />\r\n''.$f->get_tpl_var(''file_info/tags/id3v2/album'').''<br />\r\n   ''.((($f->get_tpl_var(''file_post_id'')) && get_the_ID() != ($f->get_tpl_var(''file_post_id'')))?(''<a href="''.$f->get_tpl_var(''file_post_url'').''" class="wpfilebase-postlink">''.__(__(''View post'', WPFB)).''</a>''):('''')).''\r\n  </div>\r\n </div>\r\n <div class="wpfilebase-fileinfo">\r\n  ''.$f->get_tpl_var(''file_info/playtime_string'').''<br />\r\n  ''.$f->get_tpl_var(''file_info/bitrate'').''<br />\r\n  ''.$f->get_tpl_var(''file_size'').''<br />\r\n  ''.$f->get_tpl_var(''file_hits'').'' ''.__(__(''Downloads'', WPFB)).''<br />\r\n </div>\r\n <div style="clear: both;"></div>\r\n</div>''";s:10:"flv-player";s:1137:"''<!-- the player only works when permalinks are enabled!!! -->\r\n <object width=\\''''.$f->get_tpl_var(''file_info/video/resolution_x'').''\\'' height=\\''''.$f->get_tpl_var(''file_info/video/resolution_y'').''\\'' id=\\''flvPlayer''.$f->get_tpl_var(''uid'').''\\''>\r\n  <param name=\\''allowFullScreen\\'' value=\\''true\\''>\r\n   <param name=\\''allowScriptAccess\\'' value=\\''always\\''> \r\n  <param name=\\''movie\\'' value=\\''''.(WPFB_PLUGIN_URI).''extras/flvplayer/OSplayer.swf?movie=''.$f->get_tpl_var(''file_url_encoded'').''&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=''.$f->get_tpl_var(''file_display_name'').''&showTitle=yes\\''>\r\n  <embed src=\\''''.(WPFB_PLUGIN_URI).''extras/flvplayer/OSplayer.swf?movie=''.$f->get_tpl_var(''file_url_encoded'').''&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=''.$f->get_tpl_var(''file_display_name'').''&showTitle=yes\\'' width=\\''''.$f->get_tpl_var(''file_info/video/resolution_x'').''\\'' height=\\''''.$f->get_tpl_var(''file_info/video/resolution_y'').''\\'' allowFullScreen=\\''true\\'' type=\\''application/x-shockwave-flash\\'' allowScriptAccess=\\''always\\''>\r\n </object>''";s:10:"data-table";s:188:"''<tr><td><a href="''.$f->get_tpl_var(''file_url'').''">''.$f->get_tpl_var(''file_display_name'').''</a></td><td>''.$f->get_tpl_var(''file_size'').''</td><td>''.$f->get_tpl_var(''file_hits'').''</td></tr>''";}', 'no');
INSERT INTO `wp_options` VALUES (1849, 'wpfilebase_ptpls_cat', 'a:3:{s:11:"filebrowser";s:140:"''''.$f->get_tpl_var(''cat_small_icon'').'' <a href="''.$f->get_tpl_var(''cat_url'').''" onclick="return false;">''.$f->get_tpl_var(''cat_name'').''</a>''";s:9:"3-col-row";s:105:"''<tr><td colspan="3" style="text-align:center;font-size:120%;">''.$f->get_tpl_var(''cat_name'').''</td></tr>''";s:10:"data-table";s:63:"''<!-- EMPTY: categories should not be listed in DataTables -->''";}', 'no');
INSERT INTO `wp_options` VALUES (1850, 'wpfilebase_list_tpls', 'a:4:{s:7:"default";a:4:{s:6:"header";s:0:"";s:6:"footer";s:0:"";s:12:"file_tpl_tag";s:7:"default";s:11:"cat_tpl_tag";s:7:"default";}s:5:"table";a:4:{s:6:"header";s:453:"%search_form%\r\n<table>\r\n<thead>\r\n	<tr><th scope="col"><a href="%sortlink:file_name%">Name</a></th><th scope="col"><a href="%sortlink:file_size%">Size</a></th><th scope="col"><a href="%sortlink:file_hits%">Hits</a></th></tr>\r\n</thead>\r\n<tfoot>\r\n	<tr><th scope="col"><a href="%sortlink:file_name%">Name</a></th><th scope="col"><a href="%sortlink:file_size%">Size</a></th><th scope="col"><a href="%sortlink:file_hits%">Hits</a></th></tr>\r\n</tfoot>\r\n<tbody>";s:6:"footer";s:64:"</tbody>\r\n</table>\r\n<div class="tablenav-pages">%page_nav%</div>";s:12:"file_tpl_tag";s:9:"3-col-row";s:11:"cat_tpl_tag";s:9:"3-col-row";}s:8:"mp3-list";a:4:{s:6:"header";s:0:"";s:6:"footer";s:0:"";s:12:"file_tpl_tag";s:3:"mp3";s:11:"cat_tpl_tag";s:7:"default";}s:10:"data-table";a:4:{s:6:"header";s:216:"%print_script:jquery-dataTables%\r\n%print_style:jquery-dataTables%\r\n<table id="wpfb-data-table-%uid%">\r\n<thead>\r\n	<tr><th scope="col">Name</th><th scope="col">Size</th><th scope="col">Hits</th></tr>\r\n</thead>\r\n<tbody>";s:6:"footer";s:172:"</tbody>\r\n</table>\r\n<script type="text/javascript" charset="utf-8">\r\n	jQuery(document).ready(function() {\r\n		jQuery(''#wpfb-data-table-%uid%'').dataTable();\r\n	} );\r\n</script>";s:12:"file_tpl_tag";s:10:"data-table";s:11:"cat_tpl_tag";s:10:"data-table";}}', 'no');
INSERT INTO `wp_options` VALUES (1851, 'wpfb_install_time', '1367273197', 'no');
INSERT INTO `wp_options` VALUES (1867, 'ng_3dfluxslider_transitions', 'a:13:{i:0;s:4:"bars";i:1;s:6:"blinds";i:2;s:6:"blocks";i:3;s:7:"blocks2";i:4;s:10:"concentric";i:5;s:5:"slide";i:6;s:4:"warp";i:7;s:3:"zip";i:8;s:6:"bars3d";i:9;s:8:"blinds3d";i:10;s:4:"cube";i:11;s:7:"tiles3d";i:12;s:4:"turn";}', 'yes');
INSERT INTO `wp_options` VALUES (1868, 'ng_3dfluxslider_controls', '0', 'yes');
INSERT INTO `wp_options` VALUES (1869, 'ng_3dfluxslider_pagination', '1', 'yes');
INSERT INTO `wp_options` VALUES (1870, 'ng_3dfluxslider_caption', '0', 'yes');
INSERT INTO `wp_options` VALUES (1871, 'ng_3dfluxslider_delay', '4', 'yes');
INSERT INTO `wp_options` VALUES (1880, 'ng_slider_theme', '0', 'yes');
INSERT INTO `wp_options` VALUES (1881, 'ng_slider_display_content', '0', 'yes');
INSERT INTO `wp_options` VALUES (1882, 'ng_slider_slideshow_speed', '7', 'yes');
INSERT INTO `wp_options` VALUES (1883, 'ng_slider_order', '0', 'yes');
INSERT INTO `wp_options` VALUES (1884, 'ng_slider_direction_nav', '1', 'yes');
INSERT INTO `wp_options` VALUES (1885, 'ng_slider_pagination', 'bullet', 'yes');
INSERT INTO `wp_options` VALUES (1886, 'ng_slider_us_width_for_img_slider', '0', 'yes');
INSERT INTO `wp_options` VALUES (1925, 'flgallery_version', '0.13.0', 'yes');
INSERT INTO `wp_options` VALUES (1934, 'wpns_category', '1', 'yes');
INSERT INTO `wp_options` VALUES (1935, 'wpns_effect', 'random', 'yes');
INSERT INTO `wp_options` VALUES (1936, 'wpns_slices', '5', 'yes');
INSERT INTO `wp_options` VALUES (1937, 'wpns_theme', 'default', 'yes');
INSERT INTO `wp_options` VALUES (2001, '_site_transient_update_plugins', 'O:8:"stdClass":2:{s:12:"last_checked";i:1387467406;s:8:"response";a:8:{s:19:"akismet/akismet.php";O:8:"stdClass":5:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:11:"new_version";s:5:"2.5.9";s:3:"url";s:37:"http://wordpress.org/plugins/akismet/";s:7:"package";s:55:"http://downloads.wordpress.org/plugin/akismet.2.5.9.zip";}s:43:"google-analyticator/google-analyticator.php";O:8:"stdClass":5:{s:2:"id";s:3:"130";s:4:"slug";s:19:"google-analyticator";s:11:"new_version";s:7:"6.4.7.1";s:3:"url";s:49:"http://wordpress.org/plugins/google-analyticator/";s:7:"package";s:61:"http://downloads.wordpress.org/plugin/google-analyticator.zip";}s:35:"login-with-ajax/login-with-ajax.php";O:8:"stdClass":5:{s:2:"id";s:4:"9425";s:4:"slug";s:15:"login-with-ajax";s:11:"new_version";s:5:"3.1.2";s:3:"url";s:45:"http://wordpress.org/plugins/login-with-ajax/";s:7:"package";s:63:"http://downloads.wordpress.org/plugin/login-with-ajax.3.1.2.zip";}s:19:"members/members.php";O:8:"stdClass":5:{s:2:"id";s:5:"10325";s:4:"slug";s:7:"members";s:11:"new_version";s:5:"0.2.4";s:3:"url";s:37:"http://wordpress.org/plugins/members/";s:7:"package";s:55:"http://downloads.wordpress.org/plugin/members.0.2.4.zip";}s:33:"theme-my-login/theme-my-login.php";O:8:"stdClass":5:{s:2:"id";s:4:"7109";s:4:"slug";s:14:"theme-my-login";s:11:"new_version";s:5:"6.3.8";s:3:"url";s:44:"http://wordpress.org/plugins/theme-my-login/";s:7:"package";s:62:"http://downloads.wordpress.org/plugin/theme-my-login.6.3.8.zip";}s:43:"user-access-manager/user-access-manager.php";O:8:"stdClass":5:{s:2:"id";s:4:"5677";s:4:"slug";s:19:"user-access-manager";s:11:"new_version";s:7:"1.2.5.0";s:3:"url";s:49:"http://wordpress.org/plugins/user-access-manager/";s:7:"package";s:69:"http://downloads.wordpress.org/plugin/user-access-manager.1.2.5.0.zip";}s:27:"wp-filebase/wp-filebase.php";O:8:"stdClass":5:{s:2:"id";s:5:"10299";s:4:"slug";s:11:"wp-filebase";s:11:"new_version";s:8:"0.3.0.02";s:3:"url";s:41:"http://wordpress.org/plugins/wp-filebase/";s:7:"package";s:62:"http://downloads.wordpress.org/plugin/wp-filebase.0.3.0.02.zip";}s:25:"wp-members/wp-members.php";O:8:"stdClass":5:{s:2:"id";s:5:"10426";s:4:"slug";s:10:"wp-members";s:11:"new_version";s:5:"2.8.8";s:3:"url";s:40:"http://wordpress.org/plugins/wp-members/";s:7:"package";s:58:"http://downloads.wordpress.org/plugin/wp-members.2.8.8.zip";}}}', 'yes');
INSERT INTO `wp_options` VALUES (2002, 'sImg1', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/dl.jpg', 'yes');
INSERT INTO `wp_options` VALUES (2003, 'sImg2', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/logo_ups_pres1.png', 'yes');
INSERT INTO `wp_options` VALUES (2004, 'sImg3', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/logoM2IMbis.png', 'yes');
INSERT INTO `wp_options` VALUES (2005, 'sImg4', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/master-ihm.gif', 'yes');
INSERT INTO `wp_options` VALUES (2006, 'sImg5', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/ups.jpg', 'yes');
INSERT INTO `wp_options` VALUES (2007, 'sImg6', '', 'yes');
INSERT INTO `wp_options` VALUES (2008, 'sImg7', '', 'yes');
INSERT INTO `wp_options` VALUES (2009, 'sImg8', '', 'yes');
INSERT INTO `wp_options` VALUES (2010, 'sImg9', '', 'yes');
INSERT INTO `wp_options` VALUES (2011, 'sImg10', '', 'yes');
INSERT INTO `wp_options` VALUES (2012, 'sImglink1', '', 'yes');
INSERT INTO `wp_options` VALUES (2013, 'sImglink2', '', 'yes');
INSERT INTO `wp_options` VALUES (2014, 'sImglink3', '', 'yes');
INSERT INTO `wp_options` VALUES (2015, 'sImglink4', '', 'yes');
INSERT INTO `wp_options` VALUES (2016, 'sImglink5', '', 'yes');
INSERT INTO `wp_options` VALUES (2017, 'sImglink6', '', 'yes');
INSERT INTO `wp_options` VALUES (2018, 'sImglink7', '', 'yes');
INSERT INTO `wp_options` VALUES (2019, 'sImglink8', '', 'yes');
INSERT INTO `wp_options` VALUES (2020, 'sImglink9', '', 'yes');
INSERT INTO `wp_options` VALUES (2021, 'sImglink10', '', 'yes');
INSERT INTO `wp_options` VALUES (2022, 'sPagination', 'yes', 'yes');
INSERT INTO `wp_options` VALUES (2023, 'activation', 'enable', 'yes');
INSERT INTO `wp_options` VALUES (2024, 'width', '480', 'yes');
INSERT INTO `wp_options` VALUES (2025, 'height', '185', 'yes');
INSERT INTO `wp_options` VALUES (2026, 'shadow', '', 'yes');
INSERT INTO `wp_options` VALUES (2027, 'interval', '4000', 'yes');
INSERT INTO `wp_options` VALUES (2028, 'transition', 'slide', 'yes');
INSERT INTO `wp_options` VALUES (2029, 'bgcolour', 'fff', 'yes');
INSERT INTO `wp_options` VALUES (2030, 'transpeed', '1200', 'yes');
INSERT INTO `wp_options` VALUES (2031, 'bwidth', '3', 'yes');
INSERT INTO `wp_options` VALUES (2032, 'bcolour', 'ccc', 'yes');
INSERT INTO `wp_options` VALUES (2033, 'preload', 'indicator', 'yes');
INSERT INTO `wp_options` VALUES (2034, 'start', '1', 'yes');
INSERT INTO `wp_options` VALUES (2035, 'buttons', '', 'yes');
INSERT INTO `wp_options` VALUES (2036, 'source', 'custom', 'yes');
INSERT INTO `wp_options` VALUES (2037, 'featcat', '1', 'yes');
INSERT INTO `wp_options` VALUES (2038, 'featpost', '5', 'yes');
INSERT INTO `wp_options` VALUES (2039, 'padbottom', '0', 'yes');
INSERT INTO `wp_options` VALUES (2040, 'padleft', '0', 'yes');
INSERT INTO `wp_options` VALUES (2041, 'padright', '0', 'yes');
INSERT INTO `wp_options` VALUES (2042, 'paddingtop', '0', 'yes');
INSERT INTO `wp_options` VALUES (2043, 'shadowstyle', 'large', 'yes');
INSERT INTO `wp_options` VALUES (2044, 'paginationon', '', 'yes');
INSERT INTO `wp_options` VALUES (2045, 'paginationoff', '', 'yes');
INSERT INTO `wp_options` VALUES (2046, 'next', '', 'yes');
INSERT INTO `wp_options` VALUES (2047, 'prev', '', 'yes');
INSERT INTO `wp_options` VALUES (2048, 'pageposition', 'outside', 'yes');
INSERT INTO `wp_options` VALUES (2049, 'pageside', 'left', 'yes');
INSERT INTO `wp_options` VALUES (2050, 'permalink', '', 'yes');
INSERT INTO `wp_options` VALUES (2051, 'jquery', 'true', 'yes');
INSERT INTO `wp_options` VALUES (2174, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1368308481', 'yes');
INSERT INTO `wp_options` VALUES (2175, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3750";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2382";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2259";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1877";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1799";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1549";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1282";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1282";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1272";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1221";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1185";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1090";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"960";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"935";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"917";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:3:"915";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"790";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"788";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"755";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"702";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"663";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"661";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"661";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"605";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"592";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"565";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"552";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"545";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"545";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"523";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"503";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"502";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"486";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"484";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"444";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"443";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"439";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"425";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"422";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"414";}}', 'yes');
INSERT INTO `wp_options` VALUES (2202, '_site_transient_timeout_browser_cfe547734366388b7a84253fd94ecae0', '1369515219', 'yes');
INSERT INTO `wp_options` VALUES (2203, '_site_transient_browser_cfe547734366388b7a84253fd94ecae0', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"26.0.1410.64";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2246, '_site_transient_timeout_browser_cdde89404bc0e25d5158ff337c3e2839', '1369521241', 'yes');
INSERT INTO `wp_options` VALUES (2247, '_site_transient_browser_cdde89404bc0e25d5158ff337c3e2839', 'a:9:{s:8:"platform";s:5:"Linux";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"23.0.1271.97";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2284, '_site_transient_timeout_browser_9cd12bc0603f21c5a2851402152b635b', '1369591781', 'yes');
INSERT INTO `wp_options` VALUES (2285, '_site_transient_browser_9cd12bc0603f21c5a2851402152b635b', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"26.0.1410.64";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2762, '_site_transient_timeout_browser_07ca19956b9a7751855bed4068e52c6a', '1380881675', 'yes');
INSERT INTO `wp_options` VALUES (2763, '_site_transient_browser_07ca19956b9a7751855bed4068e52c6a', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"23.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2796, '_site_transient_timeout_wporg_theme_feature_list', '1380287808', 'yes');
INSERT INTO `wp_options` VALUES (2797, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}s:8:"Features";a:19:{i:0;s:8:"blavatar";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:20:"front-page-post-form";i:11;s:19:"full-width-template";i:12;s:12:"microformats";i:13;s:12:"post-formats";i:14;s:20:"rtl-language-support";i:15;s:11:"sticky-post";i:16;s:13:"theme-options";i:17;s:17:"threaded-comments";i:18;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes');
INSERT INTO `wp_options` VALUES (2800, '_site_transient_timeout_browser_2df95fd6c049903f2a0d3811f4db9097', '1380882774', 'yes');
INSERT INTO `wp_options` VALUES (2801, '_site_transient_browser_2df95fd6c049903f2a0d3811f4db9097', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"29.0.1547.76";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2814, '_site_transient_timeout_browser_6fdfb4ac27a30f5aed9e6dce441515fa', '1380888520', 'yes');
INSERT INTO `wp_options` VALUES (2815, '_site_transient_browser_6fdfb4ac27a30f5aed9e6dce441515fa', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"23.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2816, '_site_transient_timeout_browser_3247a5fe3113cf2d8ac63d733949270b', '1380888698', 'yes');
INSERT INTO `wp_options` VALUES (2817, '_site_transient_browser_3247a5fe3113cf2d8ac63d733949270b', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"29.0.1547.76";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2832, '_site_transient_sp_update_themes', 'O:8:"stdClass":1:{s:8:"response";a:1:{s:7:"default";O:8:"stdClass":5:{s:4:"slug";s:7:"default";s:10:"stylesheet";s:11:"default.php";s:11:"new_version";s:5:"1.2.3";s:3:"url";s:23:"http://simple-press.com";s:7:"package";s:51:"http://simple-press.com/download-manager.php?id=641";}}}', 'yes');
INSERT INTO `wp_options` VALUES (2835, '_site_transient_timeout_browser_f804cd6630fe1bf7bb15ad831f20b8dd', '1380897251', 'yes');
INSERT INTO `wp_options` VALUES (2836, '_site_transient_browser_f804cd6630fe1bf7bb15ad831f20b8dd', 'a:9:{s:8:"platform";s:5:"Linux";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"28.0.1500.95";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2858, '_site_transient_timeout_browser_a728909e0257fa370259408250d9e4a0', '1381326776', 'yes');
INSERT INTO `wp_options` VALUES (2859, '_site_transient_browser_a728909e0257fa370259408250d9e4a0', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"24.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2889, '_transient_timeout_plugin_slugs', '1380809549', 'no');
INSERT INTO `wp_options` VALUES (2890, '_transient_plugin_slugs', 'a:14:{i:0;s:31:"add-multiple-users/multiadd.php";i:1;s:19:"akismet/akismet.php";i:2;s:30:"easing-slider/easingslider.php";i:3;s:21:"exec-php/exec-php.php";i:4;s:43:"google-analyticator/google-analyticator.php";i:5;s:50:"google-analytics-for-wordpress/googleanalytics.php";i:6;s:9:"hello.php";i:7;s:35:"login-with-ajax/login-with-ajax.php";i:8;s:19:"members/members.php";i:9;s:27:"simple-press/sp-control.php";i:10;s:33:"theme-my-login/theme-my-login.php";i:11;s:43:"user-access-manager/user-access-manager.php";i:12;s:27:"wp-filebase/wp-filebase.php";i:13;s:25:"wp-members/wp-members.php";}', 'no');
INSERT INTO `wp_options` VALUES (2900, '_site_transient_timeout_browser_9a3916eced3e1324a6a75abd7ead9426', '1381406706', 'yes');
INSERT INTO `wp_options` VALUES (2901, '_site_transient_browser_9a3916eced3e1324a6a75abd7ead9426', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"29.0.1547.76";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (2912, '_transient_timeout_feed_28accfffac9b4c3faf76b8db0590aa98', '1380845112', 'no');
INSERT INTO `wp_options` VALUES (2913, '_transient_feed_28accfffac9b4c3faf76b8db0590aa98', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"\n  \n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:33:"\n    \n    \n    \n    \n    \n    \n  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"link:http://www.gdnlteamtest.netsoro.net/wordpress/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://www.google.com/search?ie=utf-8&q=link:http://www.gdnlteamtest.netsoro.net/wordpress/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:103:"Your search - <b>link:http://www.gdnlteamtest.netsoro.net/wordpress/</b> - did not match any documents.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Thu, 03 Oct 2013 12:05:12 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=5388985626473682:FF=0:TM=1380801912:LM=1380801912:S=yugUV55RklQaEBi1; expires=Sat, 03-Oct-2015 12:05:12 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=jBSQZrbuxCGHdeRN-zKoLYkQka57s2E-NNA89IKx8tqOla5w_ZcURWhJEqYNih7wd-c0o5hdJ5chDiE6ktz8O4dobIQQkEWNviUApw74Li3DYUcLVSw5gbnLslOgCJg5; expires=Fri, 04-Apr-2014 12:05:12 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20111015034325";}', 'no');
INSERT INTO `wp_options` VALUES (2914, '_transient_timeout_feed_mod_28accfffac9b4c3faf76b8db0590aa98', '1380845112', 'no');
INSERT INTO `wp_options` VALUES (2915, '_transient_feed_mod_28accfffac9b4c3faf76b8db0590aa98', '1380801912', 'no');
INSERT INTO `wp_options` VALUES (2916, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1380845112', 'no');
INSERT INTO `wp_options` VALUES (2917, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<p>Ce widget envoie une requête vers <a href="http://blogsearch.google.com/">le moteur de recherche des blogs de Google</a>, de sorte que quand un autre blog fera un lien vers le vôtre, son nom s&rsquo;affichera ici. Ce moteur n&rsquo;a pas encore trouvé de lien entrant&hellip; Ce n&rsquo;est pas grave, on n&rsquo;est pas pressé.</p>\n', 'no');
INSERT INTO `wp_options` VALUES (2920, '_transient_timeout_feed_a5420c83891a9c88ad2a4f04584a5efc', '1380845113', 'no');
INSERT INTO `wp_options` VALUES (2921, '_transient_feed_a5420c83891a9c88ad2a4f04584a5efc', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n	\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"\n		\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 03 Oct 2013 12:02:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:86:"WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Fast Secure Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/si-contact-form/#post-12636";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2009 01:20:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"12636@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"An easy and powerful form builder that lets your visitors send you email. Blocks all automated spammers. No templates to mess with.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mike Challis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/contact-form-plugin/#post-26890";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 May 2011 07:34:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26890@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:43:"Add Contact Form to your WordPress website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Wordfence Security is a free enterprise class security plugin that includes a firewall, virus scanning, real-time traffic with geolocation and more.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:67:"Create a beautiful mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"Yet Another Related Posts Plugin (YARPP)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.org/plugins/yet-another-related-posts-plugin/#post-2769";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 Jan 2008 13:05:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2769@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"Display a list of related entries on your site and feeds based on a unique algorithm. Now with thumbnail support built-in!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:35:"mitcho (Michael Yoshitaka Erlewine)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 03 Oct 2013 12:05:13 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 01 Jan 2009 20:34:44 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20111015034325";}', 'no');
INSERT INTO `wp_options` VALUES (2922, '_transient_timeout_feed_mod_a5420c83891a9c88ad2a4f04584a5efc', '1380845113', 'no');
INSERT INTO `wp_options` VALUES (2923, '_transient_feed_mod_a5420c83891a9c88ad2a4f04584a5efc', '1380801913', 'no');
INSERT INTO `wp_options` VALUES (2924, '_transient_timeout_feed_57bc725ad6568758915363af670fd8bc', '1380845114', 'no');
INSERT INTO `wp_options` VALUES (2925, '_transient_feed_57bc725ad6568758915363af670fd8bc', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n	\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"\n		\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/plugins/browse/new/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 03 Oct 2013 11:36:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Form Generator - Powered by JotForm";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/form-generator-powered-by-jotform/#post-58611";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 22 Sep 2013 06:20:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58611@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:69:"Form Generator seamlessly delivers JotForm to your WordPress website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"tmontg1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Notices-Duyurular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/notices-duyurular/#post-58879";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 29 Sep 2013 18:54:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58879@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"[TR] Wordpress sitenizde Duyurular yayınlamanızı sağlar.\n[EN] Easy way to adding notifications in your Wordpress site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"sametatabasch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"renekreupl.de Client";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/renekreuplde-client/#post-58811";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Sep 2013 12:33:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58811@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:78:"renekreupl.de Client Plugin brings some functions and customizing to WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"renekreupl";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"bitcoins and litecoins for wp-woocommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wordpress.org/plugins/bitcoins-and-litecoin-for-wp-woocommerce/#post-58651";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Sep 2013 09:25:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58651@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:64:"Bitcoin/Litecoin Payments with WooCommerce plugin for WordPress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"btcmerch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Maxmind.eu Hotel Reservations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.org/plugins/maxmindeu-hotel-reservations/#post-58993";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 Oct 2013 09:35:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58993@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"Easily add a Maxmind.eu Hotel Reservation system widget to your WordPress site.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"vanMeerdervoort";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Script DeLoader";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/script-deloader/#post-58850";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 29 Sep 2013 10:50:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58850@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"For those poorly made wordpress themes which doesnot manages the scripts that loads your site.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sajesh Bahing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Article Difficulty Level";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.org/plugins/article-difficulty-level/#post-58990";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 Oct 2013 07:09:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58990@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:115:"Through this plugin, user can able to select the post difficulty level in admin dash board post area for each post.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"vinoth06";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"MBlogi cricket";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/mblogi-cricket/#post-58944";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 01 Oct 2013 03:40:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58944@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:57:"Show the cricket live scores and statistics on your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Md Waseem";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:8:"postTime";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/plugins/posttime/#post-58827";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Sep 2013 07:15:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58827@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:89:"Adds a column to the post-listing admin page displaying the post&#039;s set publish time.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"jaketblank";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Visitors Voice";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://wordpress.org/plugins/site-search-analytics-by-visitors-voice/#post-58949";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 01 Oct 2013 08:46:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58949@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:147:"Visitors Voice analyzes search- and click behavior and shows how to improve content and metadata of your site, no matter which site search you use.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Pontus Rosin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Collaboration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/collaboration/#post-59026";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 Oct 2013 17:10:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"59026@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:61:"A collaboration tool to integrate TogetherJS in to WordPress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Maxaud";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Hotlinks Manager";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/plugins/hotlinks-manager/#post-57035";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Aug 2013 14:15:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"57035@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Hotmart is ideal to who have, or want to create digital paid content online. In a simple, efficient way.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Apiki";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"CIELO Brazilian Payment Gateway for MarketPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wordpress.org/plugins/cielo-brazilian-payment-gateway-for-marketpress/#post-58488";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Sep 2013 19:15:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58488@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:144:"Payment gateway plugin by CIELO Brazilian Credit Cards, for Marketpress.\nPlugin de gateway de pagamento pela Cielo para MarketPress.Version: 1.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"diegpl";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"PressPlay Lite";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/pressplay-lite/#post-56044";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 16 Jul 2013 23:55:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"56044@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:72:"PressPlay Lite automatically adds a play button along side any MP3 link.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"dougwalker619";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Meks ThemeForest Smart Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.org/plugins/meks-themeforest-smart-widget/#post-58950";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 01 Oct 2013 10:05:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58950@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:57:"Easily display ThemeForest items inside WordPress widget.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"MeksHQ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:41:"http://wordpress.org/plugins/rss/view/new";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 03 Oct 2013 12:05:14 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Thu, 03 Oct 2013 12:11:19 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Thu, 03 Oct 2013 11:36:19 +0000";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20111015034325";}', 'no');
INSERT INTO `wp_options` VALUES (2926, '_transient_timeout_feed_mod_57bc725ad6568758915363af670fd8bc', '1380845114', 'no');
INSERT INTO `wp_options` VALUES (2927, '_transient_feed_mod_57bc725ad6568758915363af670fd8bc', '1380801914', 'no');
INSERT INTO `wp_options` VALUES (2928, '_transient_timeout_dash_de3249c4736ad3bd2cd29147c4a0d43e', '1380845114', 'no');
INSERT INTO `wp_options` VALUES (2929, '_transient_dash_de3249c4736ad3bd2cd29147c4a0d43e', '<h4>Plus populaire</h4>\n<h5><a href=''http://wordpress.org/plugins/woocommerce/''>WooCommerce - excelling eCommerce</a></h5>&nbsp;<span>(<a href=''plugin-install.php?tab=plugin-information&amp;plugin=woocommerce&amp;_wpnonce=aede496fb8&amp;TB_iframe=true&amp;width=600&amp;height=800'' class=''thickbox'' title=''WooCommerce - excelling eCommerce''>Installer</a>)</span>\n<p>WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.</p>\n<h4>Nouvelles extensions</h4>\n<h5><a href=''http://wordpress.org/plugins/collaboration/''>Collaboration</a></h5>&nbsp;<span>(<a href=''plugin-install.php?tab=plugin-information&amp;plugin=collaboration&amp;_wpnonce=5ee5885328&amp;TB_iframe=true&amp;width=600&amp;height=800'' class=''thickbox'' title=''Collaboration''>Installer</a>)</span>\n<p>A collaboration tool to integrate TogetherJS in to WordPress.</p>\n', 'no');
INSERT INTO `wp_options` VALUES (2935, '_site_transient_timeout_browser_81cf9356d9304bebdee60f38af12f726', '1381408848', 'yes');
INSERT INTO `wp_options` VALUES (2936, '_site_transient_browser_81cf9356d9304bebdee60f38af12f726', 'a:9:{s:8:"platform";s:5:"Linux";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"20.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (3059, '_site_transient_timeout_browser_f54dedbbde9ce0f69bf1533d442f67bb', '1384445464', 'yes');
INSERT INTO `wp_options` VALUES (3060, '_site_transient_browser_f54dedbbde9ce0f69bf1533d442f67bb', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:17:"Internet Explorer";s:7:"version";s:4:"10.0";s:10:"update_url";s:51:"http://www.microsoft.com/windows/internet-explorer/";s:7:"img_src";s:45:"http://s.wordpress.org/images/browsers/ie.png";s:11:"img_src_ssl";s:44:"https://wordpress.org/images/browsers/ie.png";s:15:"current_version";s:1:"9";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes');
INSERT INTO `wp_options` VALUES (3061, '_transient_timeout_feed_2c2fe0099a2578688413800ea68677d6', '1383883866', 'no');
INSERT INTO `wp_options` VALUES (3062, '_transient_feed_2c2fe0099a2578688413800ea68677d6', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n\n\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"\n	\n	\n	\n	\n	\n	\n		\n		\n	\n	\n		\n		\n		\n		\n		\n		\n		\n		\n		\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"ButlerBlog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://www.butlerblog.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:20:"chad butler''s weblog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Oct 2013 00:00:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.7.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"\n		\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"How To Avoid Distractions and Stay Focused as a Freelance Blogger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/9TnDoyVGx1Y/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:111:"http://www.butlerblog.com/2013/10/08/how-to-avoid-distractions-and-stay-focused-as-a-freelance-blogger/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Oct 2013 00:00:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2676";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1767:"A big challenge for old and new freelancers alike is avoiding distractions and staying focused.  This can be especially true for those that are in the &#8220;transition phase&#8221; where you might...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=9TnDoyVGx1Y:EpnN02-L-gE:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=9TnDoyVGx1Y:EpnN02-L-gE:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=9TnDoyVGx1Y:EpnN02-L-gE:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=9TnDoyVGx1Y:EpnN02-L-gE:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=9TnDoyVGx1Y:EpnN02-L-gE:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=9TnDoyVGx1Y:EpnN02-L-gE:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=9TnDoyVGx1Y:EpnN02-L-gE:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=9TnDoyVGx1Y:EpnN02-L-gE:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=9TnDoyVGx1Y:EpnN02-L-gE:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=9TnDoyVGx1Y:EpnN02-L-gE:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/9TnDoyVGx1Y" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:108:"http://www.butlerblog.com/2013/10/08/how-to-avoid-distractions-and-stay-focused-as-a-freelance-blogger/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.butlerblog.com/2013/10/08/how-to-avoid-distractions-and-stay-focused-as-a-freelance-blogger/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:36:"\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Clean Water and a Personal Consultation with Brian Gardner";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/arUkPJTftmY/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:104:"http://www.butlerblog.com/2013/10/07/clean-water-and-a-personal-consultation-with-brian-gardner/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Oct 2013 03:43:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2681";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1768:"If you&#8217;ve been in the WordPress or blogging world for even a short period of time, I am quite certain that you know Brian Gardner.  If you don&#8217;t, Brian is a partner of Copyblogger Media,...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=arUkPJTftmY:sk2BxI-ajR8:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=arUkPJTftmY:sk2BxI-ajR8:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=arUkPJTftmY:sk2BxI-ajR8:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=arUkPJTftmY:sk2BxI-ajR8:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=arUkPJTftmY:sk2BxI-ajR8:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=arUkPJTftmY:sk2BxI-ajR8:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=arUkPJTftmY:sk2BxI-ajR8:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=arUkPJTftmY:sk2BxI-ajR8:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=arUkPJTftmY:sk2BxI-ajR8:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=arUkPJTftmY:sk2BxI-ajR8:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/arUkPJTftmY" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:101:"http://www.butlerblog.com/2013/10/07/clean-water-and-a-personal-consultation-with-brian-gardner/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:96:"http://www.butlerblog.com/2013/10/07/clean-water-and-a-personal-consultation-with-brian-gardner/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:48:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"When A WordPress Plugin Review Is Not a Review";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/VSAT0kc2hJ0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:93:"http://www.butlerblog.com/2013/10/03/when-a-wordpress-plugin-review-is-not-a-review/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 03 Oct 2013 18:17:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"Plugin Reviews";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:7:"Reviews";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2671";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1768:"A cursory search on Google (or your favorite search engine) for WordPress Plugin Reviews is going to yield a massive number of results.  I entered &#8220;wordpress plugin review&#8221; in Google and...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=VSAT0kc2hJ0:SodDcZhafhI:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VSAT0kc2hJ0:SodDcZhafhI:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=VSAT0kc2hJ0:SodDcZhafhI:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VSAT0kc2hJ0:SodDcZhafhI:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VSAT0kc2hJ0:SodDcZhafhI:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=VSAT0kc2hJ0:SodDcZhafhI:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VSAT0kc2hJ0:SodDcZhafhI:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VSAT0kc2hJ0:SodDcZhafhI:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VSAT0kc2hJ0:SodDcZhafhI:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=VSAT0kc2hJ0:SodDcZhafhI:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/VSAT0kc2hJ0" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"http://www.butlerblog.com/2013/10/03/when-a-wordpress-plugin-review-is-not-a-review/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.butlerblog.com/2013/10/03/when-a-wordpress-plugin-review-is-not-a-review/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Are you following Matt Mullenweg?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/XmB4yd48398/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.butlerblog.com/2013/10/01/are-you-following-matt-mullenweg/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 01 Oct 2013 15:31:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"Web";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2665";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1766:"You do know who Matt is, don&#8217;t you?  And Automattic?  Why are you not paying attention? Matt Mullenweg is the developer of WordPress.  You know, that popular blogging software that so many...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=XmB4yd48398:ILHSKo-KUHM:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=XmB4yd48398:ILHSKo-KUHM:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=XmB4yd48398:ILHSKo-KUHM:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=XmB4yd48398:ILHSKo-KUHM:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=XmB4yd48398:ILHSKo-KUHM:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=XmB4yd48398:ILHSKo-KUHM:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=XmB4yd48398:ILHSKo-KUHM:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=XmB4yd48398:ILHSKo-KUHM:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=XmB4yd48398:ILHSKo-KUHM:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=XmB4yd48398:ILHSKo-KUHM:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/XmB4yd48398" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.butlerblog.com/2013/10/01/are-you-following-matt-mullenweg/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:70:"http://www.butlerblog.com/2013/10/01/are-you-following-matt-mullenweg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:51:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Plugin Review: Editorial Calendar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/5d2onkVp5R4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2013/09/30/plugin-review-editorial-calendar/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 30 Sep 2013 12:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:14:"Plugin Reviews";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:7:"Reviews";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2651";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1768:"After blogging for some time, it became evident to me that I needed an editorial calendar.  I used to use a spreadsheet for this, and I have seen many other people handle their posting schedule in a...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=5d2onkVp5R4:gH_qz6wrpzA:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=5d2onkVp5R4:gH_qz6wrpzA:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=5d2onkVp5R4:gH_qz6wrpzA:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=5d2onkVp5R4:gH_qz6wrpzA:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=5d2onkVp5R4:gH_qz6wrpzA:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=5d2onkVp5R4:gH_qz6wrpzA:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=5d2onkVp5R4:gH_qz6wrpzA:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=5d2onkVp5R4:gH_qz6wrpzA:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=5d2onkVp5R4:gH_qz6wrpzA:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=5d2onkVp5R4:gH_qz6wrpzA:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/5d2onkVp5R4" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.butlerblog.com/2013/09/30/plugin-review-editorial-calendar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:70:"http://www.butlerblog.com/2013/09/30/plugin-review-editorial-calendar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Methods to overcome writer’s block";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/VuCxJqUifGY/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.butlerblog.com/2013/09/29/methods-to-overcome-writers-block-2/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 29 Sep 2013 20:18:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2657";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1767:"One of the hardest things about being a blogger is the need to consistently write new material.  When you are trying to write worthwhile content, this can become an overwhelming issue.  If you are...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=VuCxJqUifGY:IYg-6KjSEII:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VuCxJqUifGY:IYg-6KjSEII:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=VuCxJqUifGY:IYg-6KjSEII:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VuCxJqUifGY:IYg-6KjSEII:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VuCxJqUifGY:IYg-6KjSEII:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=VuCxJqUifGY:IYg-6KjSEII:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VuCxJqUifGY:IYg-6KjSEII:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VuCxJqUifGY:IYg-6KjSEII:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=VuCxJqUifGY:IYg-6KjSEII:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=VuCxJqUifGY:IYg-6KjSEII:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/VuCxJqUifGY" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2013/09/29/methods-to-overcome-writers-block-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:73:"http://www.butlerblog.com/2013/09/29/methods-to-overcome-writers-block-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:51:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"WordPress Trends Infographic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/X2Shw4K4VZA/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.butlerblog.com/2013/09/27/wordpress-trends-infographic/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Sep 2013 12:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"Web";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:13:"odds-and-ends";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2637";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1767:"WordPress continues to grow in market share.  At present, it powers over 20% of all web sites.  When you consider sites that are using content management systems, WP&#8217;s market share is 58.5%,...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=X2Shw4K4VZA:XGZ-nvOQawc:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=X2Shw4K4VZA:XGZ-nvOQawc:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=X2Shw4K4VZA:XGZ-nvOQawc:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=X2Shw4K4VZA:XGZ-nvOQawc:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=X2Shw4K4VZA:XGZ-nvOQawc:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=X2Shw4K4VZA:XGZ-nvOQawc:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=X2Shw4K4VZA:XGZ-nvOQawc:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=X2Shw4K4VZA:XGZ-nvOQawc:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=X2Shw4K4VZA:XGZ-nvOQawc:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=X2Shw4K4VZA:XGZ-nvOQawc:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/X2Shw4K4VZA" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.butlerblog.com/2013/09/27/wordpress-trends-infographic/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:66:"http://www.butlerblog.com/2013/09/27/wordpress-trends-infographic/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n		\n				\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Chris Guillebeau Suggests Auditing Yourself";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/b6s_6pIh25w/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:89:"http://www.butlerblog.com/2013/09/26/chris-guillebeau-suggests-auditing-yourself/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Sep 2013 12:00:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2634";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1765:"Chris Guillebeau had a great post recently about auditing yourself from time to time.  Good advice. It is good to take some time to do some introspection and reflection on a regular basis.  This...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=b6s_6pIh25w:3c18dtywEjA:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=b6s_6pIh25w:3c18dtywEjA:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=b6s_6pIh25w:3c18dtywEjA:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=b6s_6pIh25w:3c18dtywEjA:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=b6s_6pIh25w:3c18dtywEjA:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=b6s_6pIh25w:3c18dtywEjA:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=b6s_6pIh25w:3c18dtywEjA:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=b6s_6pIh25w:3c18dtywEjA:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=b6s_6pIh25w:3c18dtywEjA:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=b6s_6pIh25w:3c18dtywEjA:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/b6s_6pIh25w" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:86:"http://www.butlerblog.com/2013/09/26/chris-guillebeau-suggests-auditing-yourself/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.butlerblog.com/2013/09/26/chris-guillebeau-suggests-auditing-yourself/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:48:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"Pressgram, iOS, and choosing your market";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/yjQOueDJiOY/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:85:"http://www.butlerblog.com/2013/09/25/pressgram-ios-and-choosing-your-market/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Sep 2013 15:00:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"Web";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"apps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"pressgram";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=2577";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1764:"Important update to this post. John Saddington does want to release an Android version (that is good), but he&#8217;s going need your help. Read the update to find out what you can do. A few days...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=yjQOueDJiOY:usQz-V7aj_w:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=yjQOueDJiOY:usQz-V7aj_w:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=yjQOueDJiOY:usQz-V7aj_w:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=yjQOueDJiOY:usQz-V7aj_w:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=yjQOueDJiOY:usQz-V7aj_w:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=yjQOueDJiOY:usQz-V7aj_w:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=yjQOueDJiOY:usQz-V7aj_w:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=yjQOueDJiOY:usQz-V7aj_w:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=yjQOueDJiOY:usQz-V7aj_w:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=yjQOueDJiOY:usQz-V7aj_w:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/yjQOueDJiOY" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.butlerblog.com/2013/09/25/pressgram-ios-and-choosing-your-market/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:76:"http://www.butlerblog.com/2013/09/25/pressgram-ios-and-choosing-your-market/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Troubleshooting the WordPress wp_mail function";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/HOL3AYFQNSE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.butlerblog.com/2013/09/24/troubleshooting-the-wp_mail-function/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Sep 2013 23:41:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"webdev";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"wp_mail";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://butlerblog.com/?p=2225";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1764:"This is a continuation of the thoughts presented in the article &#8220;Testing the wp_mail Function.&#8221;  That article focused on how to actually test the wp_mail function to be sure that the...<br/>\n<br/>\n[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">\n<a href="http://feeds.feedburner.com/~ff/butlerblog?a=HOL3AYFQNSE:zVuCtc6y9QQ:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=HOL3AYFQNSE:zVuCtc6y9QQ:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=HOL3AYFQNSE:zVuCtc6y9QQ:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=HOL3AYFQNSE:zVuCtc6y9QQ:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=HOL3AYFQNSE:zVuCtc6y9QQ:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=HOL3AYFQNSE:zVuCtc6y9QQ:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=HOL3AYFQNSE:zVuCtc6y9QQ:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=HOL3AYFQNSE:zVuCtc6y9QQ:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=HOL3AYFQNSE:zVuCtc6y9QQ:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=HOL3AYFQNSE:zVuCtc6y9QQ:gIN9vFwOqvQ" border="0"></img></a>\n</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/HOL3AYFQNSE" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.butlerblog.com/2013/09/24/troubleshooting-the-wp_mail-function/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.butlerblog.com/2013/09/24/troubleshooting-the-wp_mail-function/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:38:"http://feeds.feedburner.com/butlerblog";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:10:"butlerblog";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:10:"butlerblog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"ogdDqOoFPl65h2W1arY2qyEUu4Y";s:13:"last-modified";s:29:"Thu, 07 Nov 2013 15:28:36 GMT";s:4:"date";s:29:"Thu, 07 Nov 2013 16:11:06 GMT";s:7:"expires";s:29:"Thu, 07 Nov 2013 16:11:06 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20111015034325";}', 'no');
INSERT INTO `wp_options` VALUES (3063, '_transient_timeout_feed_mod_2c2fe0099a2578688413800ea68677d6', '1383883866', 'no');
INSERT INTO `wp_options` VALUES (3064, '_transient_feed_mod_2c2fe0099a2578688413800ea68677d6', '1383840666', 'no');
INSERT INTO `wp_options` VALUES (3065, '_transient_timeout_feed_2fb9572e3d6a42f680e36370936a57ae', '1383883884', 'no');
INSERT INTO `wp_options` VALUES (3066, '_transient_feed_2fb9572e3d6a42f680e36370936a57ae', 'a:4:{s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"feed";a:1:{i:0;a:6:{s:4:"data";s:268:"\n    \n    \n    \n    \n    \n    \n    \n  \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n            \n        ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:27:"http://www.w3.org/2005/Atom";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"WordPress Francophone : Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"subtitle";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:35:"http://www.wordpress-fr.net/planet/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:3:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:9:"alternate";s:4:"type";s:9:"text/html";s:4:"href";s:35:"http://www.wordpress-fr.net/planet/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:20:"application/atom+xml";s:4:"href";s:54:"http://feeds.feedburner.com/WordpressFrancophonePlanet";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"updated";a:1:{i:0;a:5:{s:4:"data";s:20:"2013-11-07T16:48:34Z";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:6:"Author";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:5:"entry";a:17:{i:0;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"L''écho des plugins WordPress : Multi Column Tag Map";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:64:"http://www.echodesplugins.li-an.fr/plugins/multi-column-tag-map/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:64:"http://www.echodesplugins.li-an.fr/plugins/multi-column-tag-map/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-06T09:42:20+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:83:"<div>Une pr&eacute;sentation alphab&eacute;tique de vos archives de mots-clef</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WordPress Francophone : WordCamp Paris 2014 : et si vous étiez orateur ?";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/g_h34lO6c00/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:67:"http://feedproxy.google.com/~r/WordpressFrancophone/~3/g_h34lO6c00/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-05T12:31:14+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:6641:"<div>\n<p><strong>Le 17 janvier prochain (2014) se tiendra le deuxi&egrave;me WordCamp Paris.</strong> On esp&egrave;re que &ccedil;a sera pour autant de gens que possible l&rsquo;occasion de se retrouver pour &eacute;changer, apprendre et&hellip; s&rsquo;amuser autour de WordPress.</p>\n<p>Un WordCamp, c&rsquo;est avant tout <strong>des conf&eacute;rences sur &nbsp;WordPress</strong>. Mais de quoi y parle-t-on exactement ? Vous voulez quelques exemples ? C&rsquo;est parti !</p>\n<h2>De la technique</h2>\n<p>Les conf&eacute;rences d&rsquo;un WordCamp sont-elles forc&eacute;ment techniques ? Non bien s&ucirc;r. Mais c&rsquo;est quand m&ecirc;me l&rsquo;occasion de b&eacute;n&eacute;ficier de conf&eacute;rences sur les bonnes pratiques techniques pour WordPress (d&eacute;veloppements de plugins et th&egrave;mes, performance, s&eacute;curit&eacute;, d&eacute;ploiements&hellip;).</p>\n<h2>Des &eacute;tudes de cas</h2>\n<p>Vous &ecirc;tes d&eacute;cisionnaire en entreprise ? Entrepreneur ? Agence ? Freelance ? Responsable associatif ? Alors qu&rsquo;est-ce qu&rsquo;on peut faire avec WordPress ? Des orateurs viennent pr&eacute;senter leurs r&eacute;alisations WordPress avec les bons et les mauvais c&ocirc;t&eacute;s (pas de blah blah). On peut aussi parler de comment on monte un projet WordPress.</p>\n<h2>Du marketing</h2>\n<p>WordPress peut &ecirc;tre un tr&egrave;s bon outil marketing. SEO, Analytics, social, quelles sont les bonnes pratiques pour tirer le maximum de WordPress et soigner son marketing digital ?</p>\n<h2>L&rsquo;&eacute;cosyst&egrave;me WordPress</h2>\n<p>WordPress, c&rsquo;est un logiciel mais c&rsquo;est aussi un &eacute;cosyst&egrave;me : th&egrave;mes, plugins, h&eacute;bergeurs, services SaaS, gratuit ou premium ? Comment on s&rsquo;y retrouve ? Comment choisir ? Comment profiter au maximum de cet &eacute;cosyst&egrave;me ?</p>\n<h2>Au-del&agrave; de WordPress et vers l&rsquo;infini</h2>\n<p>WordPress est peut-&ecirc;tre un peu plus qu&rsquo;un CMS. Ajoutez-y une pinc&eacute;e de BuddyPress et le voil&agrave; R&eacute;seau social, installez BBPress et vous aurez un forum de support. Deux exemples parmi beaucoup d&rsquo;autres sur les 1001 visages de WordPress.</p>\n<h2>La communaut&eacute;</h2>\n<p>Essentielle ! Comment organise-t-on un meetup, un WordCamp, comment peut-on participer et s&rsquo;impliquer dans le d&eacute;veloppement de WordPress (qu&rsquo;on soit technicien ou pas) ?</p>\n<h2>Alors pr&ecirc;t(e) pour &ecirc;tre orateur ou oratrice au prochain WordCamp ?</h2>\n<p>Le fameux &laquo; <a rel="nofollow" title="Lien vers l''appel &agrave; orateurs du WordCamp Paris 2014" target="_blank" href="http://2014.paris.wordcamp.org/2013/10/29/appel-a-orateurs/">appel &agrave; orateurs</a> &raquo;a &eacute;t&eacute; lanc&eacute;. Alors pourquoi pas vous ? Il n&rsquo;y a pas besoin d&rsquo;&ecirc;tre un orateur ou une oratrice professionnel(le). La communaut&eacute; est plut&ocirc;t bienveillante. Elle est m&ecirc;me avide d&rsquo;apprendre et d&rsquo;&eacute;changer avec vous en fait. Si vous pensez pouvoir d&eacute;velopper un sujet dont vous &ecirc;tes fier(e) et de le partager, n&rsquo;h&eacute;sitez pas une seconde ! L&rsquo;exp&eacute;rience en vaut le coup.</p>\n<h2>Petite mention finale (mais qui a son importance)</h2>\n<p>Les WordCamps ne sont pas des tribunes commerciales, politiques ou religieuses. Ils ont vocation &agrave; faire la promotion de la d&eacute;marche open source (et de WordPress bien s&ucirc;r). Quoi, je ne peux pas parler business ?! Si, si (et de bien d&rsquo;autres choses) mais en respectant certaines r&egrave;gles simples.</p>\n<ul>\n<li>La premi&egrave;re et la plus simple : votre sujet doit avoir un rapport avec&hellip; WordPress <img src="http://www.wordpress-fr.net/wp-includes/images/smilies/icon_wink.gif" alt=";-)" class="wp-smiley">\n</li>\n<li>Vous pouvez vous pr&eacute;senter bri&egrave;vement, ainsi que votre soci&eacute;t&eacute;, activit&eacute;, association&hellip; Cette pr&eacute;sentation doit avant tout servir au public &agrave; savoir &agrave; qui il a affaire (d&eacute;veloppeur, designer, entrepreneur, amateur&hellip;)</li>\n<li>La mention des activit&eacute;s commerciales doit avant tout servir d&rsquo;exemple et de retour d&rsquo;exp&eacute;rience et non pas &agrave; faire une promotion brute d&rsquo;un service payant</li>\n</ul>\n<p>Donc les agences, les entreprises, les services premiums, c&rsquo;est n&rsquo;est pas le mal mais le WordCamp n&rsquo;est pas un terrain de chasse pour les commerciaux avant-vente. C&rsquo;est un espace de partage ouvert et attentif aux besoins des utilisateurs. Vos r&eacute;ponses doivent avoir une valeur ajout&eacute;e (et j&rsquo;ai tendance &agrave; croire que c&rsquo;est aussi &nbsp;une des meilleures formes d&rsquo;avant-vente mais &ccedil;a n&rsquo;engage que moi).</p>\n<p>Attendez-vous aussi &agrave; des questions du public sur la d&eacute;marche open source de votre activit&eacute; ou votre entreprise. Les gens chercheront &agrave; savoir ce que vous apportez &agrave; la communaut&eacute; (et je vous encourage &agrave; apporter quelque chose &agrave; la communaut&eacute;).</p>\n<h3 style="text-align:center;"><a rel="nofollow" title="Lien vers l''appel &agrave; orateurs pour le WordCamp Paris 2014" target="_blank" href="http://2014.paris.wordcamp.org/2013/10/29/appel-a-orateurs/">Je propose une ou plusieurs conf&eacute;rences</a></h3>\n<p>&nbsp;</p>\n<p><strong>Voil&agrave;, on esp&egrave;re vous voir nombreux et en forme le 17 janvier prochain ! A bient&ocirc;t.</strong></p>\n<div class="feedflare">\n<a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=g_h34lO6c00:RVTsZHl76rU:V_sGLiPBpWU" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/WordpressFrancophone?a=g_h34lO6c00:RVTsZHl76rU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/WordpressFrancophone?i=g_h34lO6c00:RVTsZHl76rU:gIN9vFwOqvQ" border="0"></a>\n</div>\n<img src="http://feeds.feedburner.com/~r/WordpressFrancophone/~4/g_h34lO6c00" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WP Formation : 1000 icônes pour votre WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wpformation.com/icones-wordpress-plugin/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:47:"http://wpformation.com/icones-wordpress-plugin/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-11-04T14:15:24+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:1326:"<div>\n<p><img width="300" height="212" src="http://wpformation.com/wp-content/uploads/2013/11/icones-pour-wordpress-300x212.jpg" class="attachment-medium wp-post-image" alt="icones-pour-wordpress" style="float:right;margin:0 0 10px 10px;">Les ic&ocirc;nes c''est bien, c''est visuel, c''est beau, &ccedil;a attire l''attention et &ccedil;a incite au clic ! 1000 ic&ocirc;nes HD pour WordPress Une moyen simple et rapide pour ajouter des ic&ocirc;nes pour WordPress.&nbsp;Vector Icons&nbsp;est une nouvelle fa&ccedil;on d''utiliser les ic&ocirc;nes sur votre site. Plus besoin de personnaliser les fichiers image ou psd, maintenant tout peut ...</p>\n<p></p>\n<hr>\n<a rel="nofollow" target="_blank" href="http://wpformation.com/icones-wordpress-plugin/">1000 ic&ocirc;nes pour votre WordPress</a> est un article de <a rel="nofollow" title="Formation Internet WordPress Ecommerce" target="_blank" href="http://wpformation.com/">WP Formation</a><br>\nN''h&eacute;sitez pas &agrave; le suivre sur : <a rel="nofollow" title="Ajouter sur Facebook" target="_blank" href="http://www.facebook.com/Wibeweb">Facebook</a> - <a rel="nofollow" title="Suivre sur Twitter" target="_blank" href="http://twitter.com/wpformation">Twitter</a> - <a rel="nofollow" target="_blank" href="http://plus.google.com/107614015687669785725/">Google+</a>\n<hr>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"GeekPress : 9 thèmes WordPress pour rendre votre hôtel attractif";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.geekpress.fr/wordpress/guide/themes-hotel-attractif-1940/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:68:"http://www.geekpress.fr/wordpress/guide/themes-hotel-attractif-1940/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-10-31T10:30:50+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:183:"<div>Si vous voulez en mettre plein la vue &agrave; vos clients ou &agrave; un potentiel invit&eacute;, voici une s&eacute;lection de 9 th&egrave;mes WordPress pour h&ocirc;tel.</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WordPress Channel : <div>jQuery &amp; WordPress &ndash; Une sidebar flottante</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wpchannel.com/jquery-sidebar-flottante-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:56:"http://wpchannel.com/jquery-sidebar-flottante-wordpress/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-10-30T14:30:40+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:989:"<div>\n<p></p>\n<p style="float:right;margin:0 0 10px 15px;width:240px;">\n		<img src="http://wpchannel.com/images/2011/12/jQuery_logo_color_onwhite.png" width="240"></p>Il arrive parfois que le contenu d&rsquo;une page soit long et que votre molette de souris chauffe &agrave; force de faire des allez-retours pour pouvoir acc&eacute;der aux &eacute;l&eacute;ments de la sidebar. Une manipulation tr&egrave;s simple vous permet en CSS de fixer cette sidebar afin qu&rsquo;elle soit toujours visible &agrave; l&rsquo;&eacute;cran. Mais ce n&rsquo;est pas suffisamment [&hellip;]<p><a rel="nofollow" target="_blank" href="http://wpchannel.com/author/cybercraft/">Christopher Hennuyez</a> - <a rel="nofollow" target="_blank" href="http://wpchannel.com/">WordPress Channel - Tutoriels, th&egrave;mes &amp; plugins WordPress</a> - <a rel="nofollow" target="_blank" href="http://wpchannel.com/jquery-sidebar-flottante-wordpress/">jQuery &amp; WordPress &ndash; Une sidebar flottante</a></p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Lashon : WordPress 3.7 est peinard et sécurisant";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:46:"http://lashon.fr/wordpress-3-7-super-securite/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:46:"http://lashon.fr/wordpress-3-7-super-securite/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-10-28T07:15:50+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:855:"<div>\n<p>&nbsp; Juste quelques mots brefs pour dire que cette fois &ccedil;a y est, WordPress 3.7, nomm&eacute; &laquo;&nbsp;Basie&nbsp;&raquo; est une version de WordPress fort r&eacute;ussie. D&rsquo;ailleurs ce blog a saut&eacute; dedans &agrave; pieds joints et les yeux ferm&eacute;s. D&eacute;sormais vous tournerez vos blogs avec plus de s&eacute;curit&eacute; quasi en dormant. La grande nouveaut&eacute; est un processus [&hellip;]</p>\n<p>Exigez l''original ! ;-) \nL''original de cet article est l&agrave; <a rel="nofollow" target="_blank" href="http://lashon.fr/wordpress-3-7-super-securite/">WordPress 3.7 est peinard et s&eacute;curisant</a> - &eacute;crit par  <a rel="nofollow" target="_blank" href="http://lashon.fr/">WordPress Cr&eacute;ation Sites Internet - lashon.fr, le blog work in progress de Tikoun, cr&eacute;ateur Web</a></p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"SEOMix : Optimiser son référencement naturel WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.seomix.fr/optimiser-referencement-naturel-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:63:"http://www.seomix.fr/optimiser-referencement-naturel-wordpress/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-10-25T08:30:55+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:1611:"<div>\n<div><img width="160" height="180" src="http://www.seomix.fr/wp-content/uploads/2013/10/optimiser-referencement-naturel-wordpress-160x180.jpg" class="attachment-thumbnail wp-post-image" alt="Optimiser son r&eacute;f&eacute;rencement WordPress"></div>Le livre "Optimiser son r&eacute;f&eacute;rencement naturel WordPress" vient de para&icirc;tre aux &eacute;ditions Eyrolles. D&eacute;couvrez ce que ce livre peut vous apprendre sur le SEO et ce CMS\n      <p><strong>Article original :</strong> <a rel="nofollow" target="_blank" href="http://www.seomix.fr/optimiser-referencement-naturel-wordpress/">Optimiser son r&eacute;f&eacute;rencement naturel WordPress</a>.</p>\n      <p><strong>Debut du contenu :</strong> Le livre "Optimiser son r&eacute;f&eacute;rencement WordPress" vient de para&icirc;tre dans toutes les librairies qui se respectent. Apr&egrave;s 9 mois de travail et un accouchement presque sans douleur, je publie ainsi mon premier ouvrage aux &eacute;ditions Eyrolles. De quoi parle le livre Ce que vous allez apprendre Comme son nom l''indique, cet ouvrage traite de l''optimisation d''un site WordPress pour le r&eacute;f&eacute;rencement naturel. Il s''adresse &agrave; la fois aux d&eacute;butants qui veulent mieux ma&icirc;triser leur site, ainsi qu''aux d&eacute;veloppeurs, r&eacute;f&eacute;renceurs et responsables marketing qui veulent r&eacute;ellement approfondir leur ma&icirc;trise du CMS pour plus de visibilit&eacute;. En d''autres termes, vous n''avez plus [&hellip;]</p>\n<hr>\n<img src="http://feeds.feedburner.com/~r/seomix-wordpress/~4/7IFEfvAPFqY" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Cree1site : Mon expérience WordCamp Europe 2013";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:53:"http://www.cree1site.com/wordcamp-europe-2013-depart/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:53:"http://www.cree1site.com/wordcamp-europe-2013-depart/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-10-07T07:01:41+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:463:"<div>\n<p>Vu sur le site de <a rel="nofollow" target="_blank" href="http://www.cree1site.com/">l''agence web</a> Cree1site.com<br></p>\n<p>R&eacute;sum&eacute; de mon WordCamp, en compagnie de la French Team et de toute l''&eacute;quipe Wordpress Mondial.</p>\n<p>Cet article <a rel="nofollow" target="_blank" href="http://www.cree1site.com/wordcamp-europe-2013-depart/">Mon exp&eacute;rience WordCamp Europe 2013</a> est apparu en premier sur Cree1site.com</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"Grégoire Noyelle : Genesis :: Créer un modèle de page WordPress sur mesure";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.gregoirenoyelle.com/genesis-creer-modele-page-wordpress-sur-mesure/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:78:"http://www.gregoirenoyelle.com/genesis-creer-modele-page-wordpress-sur-mesure/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-10-01T07:01:15+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:7243:"<div>\n<p>Le framework <a rel="nofollow" target="_blank" href="http://www.studiopress.com/features" title="Ouverture">Genesis</a> respecte la <a rel="nofollow" target="_blank" href="http://codex.wordpress.org/Template_Hierarchy" title="Ouverture">hi&eacute;rarchie des th&egrave;mes classique WordPress</a>. Dans cette partie nous verrons comment cr&eacute;er simplement un mod&egrave;le de page.</p>\n<h3 id="crationdunmodledepage">Cr&eacute;ation d&rsquo;un mod&egrave;le de page</h3>\n<p>Comme tout mod&egrave;le de page, il suffit d&rsquo;ajouter en haut de son fichier en commentaire PHP la phrase suivante: </p>\n<pre><code>&lt;?php\n// Template Name: Nom du Mod&egrave;le de page\n?&gt;\n</code></pre>\n<p>Attention pour que &ccedil;a fonctionne, vous devez respecter les &eacute;l&eacute;ments suivants</p>\n<ul>\n<li>cela doit &ecirc;tre un commentaire PHP</li>\n<li>il n&rsquo;y a pas d&rsquo;espace entre <code>Name</code> et les <code>:</code> qui suivent</li>\n<li>les majuscules dans <code>Template Name:</code> sont optionnelles</li>\n<li>le <code>Nom du Mod&egrave;le de page</code> est le nom du mod&egrave;le que vous allez cr&eacute;er.</li>\n</ul>\n<h3 id="crationdunmodledepagegenesis">Cr&eacute;ation d&rsquo;un mod&egrave;le de Page Genesis</h3>\n<p>Pour que le mod&egrave;le fonctionne dans <a rel="nofollow" target="_blank" href="http://www.studiopress.com/features" title="Ouverture">Genesis</a>, il suffit de cr&eacute;er dans votre <strong>th&egrave;me enfant</strong> un fichier qui aura le nom que vous voulez. La seule chose &agrave; respecter est de mettre <code>genesis();</code> &agrave; la fin de votre fichier PHP.</p>\n<p>Au final vous aurez un fichier de type:</p>\n<pre><code>&lt;?php\n// Template Name: Nom du Mod&egrave;le de page\n\n// votre nouveau contenu ira ici\n\ngenesis();\n</code></pre>\n<p>C&rsquo;est tout. La simple fonction <code>genesis();</code> se chargera en fonction de la <a rel="nofollow" target="_blank" href="http://codex.wordpress.org/Template_Hierarchy" title="Ouverture">hi&eacute;rarchie WordPress</a> d&rsquo;afficher les boucles adapt&eacute;es et le HTML correspondant pour les pages, articles, archives&hellip;</p>\n<p><strong>Remarque</strong>: La fermeture du <code>php</code> n&rsquo;est pas obligatoire &agrave; la fin des fichiers et c&rsquo;est m&ecirc;me conseill&eacute;.</p>\n<p>Nous verrons dans un article ult&eacute;rieur comment personnaliser des mod&egrave;les plus complexes. Pour l&rsquo;instant concentrons nous sur un simple mod&egrave;le de page.</p>\n<p><span id="more-7365"></span></p>\n<h3 id="ajoutdenouveauxcontenusdanslapage">Ajout de nouveaux contenus dans la page</h3>\n<p><a rel="nofollow" target="_blank" href="http://www.studiopress.com/features" title="Ouverture">Genesis</a> poss&egrave;de de nombreux <a rel="nofollow" target="_blank" href="http://codex.wordpress.org/Plugin_API/Hooks" title="Ouverture">Hooks</a> ou crochets qui permettent de filtrer ou d&rsquo;injecter de nouvelle zone dans votre site. Un site r&eacute;pertorie tous ces hooks: le <a rel="nofollow" target="_blank" href="http://genesistutorials.com/visual-hook-guide/" title="Ouverture">Visual Hook Guide</a> cr&eacute;&eacute; par Christopher Cochran. Ce guide permet de voir toutes les zone o&ugrave; il est possible d&rsquo;injecter du contenu avec la fonction WordPress <code>add_action</code> (plus de d&eacute;tail voir <a rel="nofollow" target="_blank" href="http://codex.wordpress.org/Function_Reference/add_action" title="Ouverture">l&rsquo;article du codex</a>)</p>\n<h4 id="add_actionaprslecontenudelapage">add_action apr&egrave;s le contenu de la page</h4>\n<p><strong>Attention</strong> le guide qui suit repose sur la base de th&egrave;me HTML5 valable depuis la version 2 de Genesis. et depuis le nom des hooks a parfois &eacute;t&eacute; modifi&eacute;. Si vous avez un compte chez StudioPress, la <a rel="nofollow" target="_blank" href="http://my.studiopress.com/docs/genesis-loop-hooks-comparison/" title="Ouverture">liste compl&egrave;te sur le site officiel</a>.</p>\n<p>En suivant le guide, nous allons nous concentrer sur le <a rel="nofollow" target="_blank" href="http://genesistutorials.com/visual-hook-guide/sample/" title="Ouverture">mod&egrave;le de page classique d&eacute;taill&eacute; avec cette page</a>. </p>\n<p>Pour utiliser <code>add_action</code> il suffit de respecter l&rsquo;&eacute;criture suivante dans votre nouveau mod&egrave;le de page:</p>\n<pre><code>add_action(''nom_du_hook'',''nom_de_votre_function'');\nfunction nom_de_votre_function() {\n    // votre code PHP   \n}   \n</code></pre>\n<p>Ici, je veux ins&eacute;rer un titre apr&egrave;s mon contenu. Je vais alors choisir la zone <code>genesis_after_entry</code> et cela donnera:</p>\n<pre><code>&lt;?php\n// Template Name: Mod&egrave;le 1\n\n\nadd_action(''genesis_after_entry'',''gn_contenu_sup'');\nfunction gn_contenu_sup(){\n    echo "&lt;h3&gt;Nouveau contenu apr&egrave;s l''article&lt;/h3&gt;";\n}\n\ngenesis();\n</code></pre>\n<p>Ce qui donnera en ligne: </p>\n<p><img src="http://cdn.gregoirenoyelle.com/gnm/wpgen-niv1/wpgen-n1-template-nouveau-contenu.jpg" title="Nouveau contenu avec un hook sur un mod&egrave;le de page Genesis" alt="Capture: Nouveau contenu avec un hook sur un mod&egrave;le de page Genesis" width="600" height="575"></p>\n<p><strong>Remarque</strong>: comme indiqu&eacute; plus haut, si vous souhaitez utiliser une version plus ancienne de Genesis, <code>genesis_after_entry</code> est &agrave; remplacer par <code>genesis_after_post</code></p>\n<h4 id="add_actiondanslecontenudelapageaveclespriorits">add_action dans le contenu de la page avec les priorit&eacute;s</h4>\n<p>Ici nous allons aborder un autre concept du <code>add_action</code> en ajoutant une priorit&eacute;. Ce param&egrave;tre optionnel permet d&rsquo;utiliser la m&ecirc;me zone avec un ordre de priorit&eacute;. La priorit&eacute; par d&eacute;faut est de <code>10</code>. Je m&rsquo;explique.</p>\n<p>Si vous voulez avec l&rsquo;action pr&eacute;c&eacute;dente plac&eacute;e le nouveau contenu avant le contenu de l&rsquo;&eacute;diteur, il faudrait modifier notre code pr&eacute;c&eacute;dent en utilisant le hook Genesis qui correspond &agrave; <code>genesis_entry_content</code>. Cela donnerait:</p>\n<pre><code>&lt;?php\n// Template Name: Mod&egrave;le 1\n\n\nadd_action(''genesis_entry_content'',''gn_contenu_sup'', 5);\nfunction gn_contenu_sup(){\n    echo "&lt;h3&gt;Nouveau contenu apr&egrave;s l''article&lt;/h3&gt;";\n}\n\ngenesis(); \n</code></pre>\n<p>Dans ce cas, mon titre se placera juste apr&egrave;s le titre de la page, car j&rsquo;ai utilis&eacute; la priorit&eacute; <code>5</code> pour le hook. Du coup, si je veux placer mon nouveau contenu, juste apr&egrave;s celui de la page, je changerai <code>5</code>pour <code>15</code> ou tout nombre sup&eacute;rieur &agrave; <code>10</code> qui est la priorit&eacute; par d&eacute;faut. Ainsi, vous pouvez &agrave; loisir tr&egrave;s facilement ajouter des champs personnalis&eacute;s sans remettre en question l&rsquo;affichage de votre page.</p>\n<p><strong>Remarque</strong>: comme indiqu&eacute; plus haut, si vous souhaitez utiliser une version plus ancienne de Genesis, <code>genesis_entry_content</code> est &agrave; remplacer par <code>genesis_post_content</code></p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"4h18 : Facebook Post Planner";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:111:"http://4h18.com/facebook-post-planner/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=facebook-post-planner";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:111:"http://4h18.com/facebook-post-planner/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=facebook-post-planner";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-09-30T08:09:20+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:419:"<div>\n<p>Planifier la publication de vos articles sur Facebook</p>\n<p></p>\n<p> <a rel="nofollow" target="_blank" href="http://4h18.com/facebook-post-planner/">Facebook Post Planner</a> est un article original de <a rel="nofollow" target="_blank" href="http://4h18.com/">4h18</a>.</p>\n<p><a rel="nofollow" target="_blank" href="http://4h18.com/">4h18 - Devenez un blogueur pro avec St&eacute;phane Briot !</a></p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"GD6D : Créer une présentation et la diffuser dans son site avec… JETPACK";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:51:"http://feedproxy.google.com/~r/Gd6d/~3/Rng_PI-XPNg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:51:"http://feedproxy.google.com/~r/Gd6d/~3/Rng_PI-XPNg/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-09-12T01:19:54+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:13524:"<div>\n<img src="http://i0.wp.com/www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/shortcodes.jpg?fit=1024%2C1024" class="attachment-large wp-post-image" alt="shortcodes"><p>L&rsquo;extension <a rel="nofollow" title="Par WordPress.com" target="_blank" href="http://jetpack.me/"><strong>Jetpack</strong></a> propose des fonctions indispensables (formulaire de contact, statistique, partage, <a rel="nofollow" title="Nouveaut&eacute; JetPack : la fonction &laquo; Widget Visibility &raquo;" target="_blank" href="http://www.gd6d.fr/wordpressfr/blog/plugin-jetpack-visibility/">visibilit&eacute; des widgets</a>&hellip;), d&rsquo;autres moins (<a rel="nofollow" title="Nouveau : cr&eacute;ez un diaporama ou une mosa&iuml;que d&rsquo;images avec Jetpack" target="_blank" href="http://www.gd6d.fr/wordpressfr/blog/diaporama-slideshow-mosaique-images-avec-plugin-jetpack/">mosa&iuml;que d&rsquo;image</a>) et enfin il y a une troisi&egrave;me cat&eacute;gorie : les fonctions &laquo;&nbsp;gadget&nbsp;&raquo;. &laquo;&nbsp;C&rsquo;est totalement <em>inutile</em> et <em>donc</em> rigoureusement <em>indispensable</em> !&nbsp;&raquo; comme dirait J&eacute;rome Bonaldi, donc voyons comment l&rsquo;utiliser !</p>\n<h2>Remplacer gratuitement Powerpoint et Slideshare !!!</h2>\n<p>La premi&egrave;re utilit&eacute; du module &laquo;&nbsp;Presentation&nbsp;&raquo; est comme son nom l&rsquo;indique de pouvoir cr&eacute;er des pages qui pourront ainsi &ecirc;tre projet&eacute;es, exactement des diapos PowerPoint ou Keynote. Ces pages seront visible sous forme d&rsquo;un diaporama interactif int&eacute;gr&eacute; dans sa page et pouvant occuper tout l&rsquo;&eacute;cran. Voil&agrave; un exemple : </p>\n<p></p>\n<p class="not-supported-msg" style="display:inherit;padding:25%;text-align:center;">Impossible de lancer ce diaporama. Raffra&icirc;chissez la page&hellip; ou essayez un autre navigateur.</p>\n<br><p></p>\n<div class="shortcode-toggle toggle-voir-le-code closed default border">\n<h4 class="toggle-trigger"><a rel="nofollow">Voir le code</a></h4>\n<div class="toggle-content">\n<br>\nCode utilis&eacute; pour la pr&eacute;sentation ci-dessus.<br><em>Attention, j&rsquo;ai rajout&eacute; un espace autour des crochets !</em>\n<p>[ slide transition="down" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/bg-gd6d.jpg" ]<br>\n&lt;h3&gt;Presentations Shortcode Plugin&lt;/h3&gt;<br>\n&lt;h4&gt;with JETPACK&lt;/h4&gt;<br>\n[ /slide ][ slide bgcolor=#CEE4EA ]<br>\nWho doesn&rsquo;t love awesome presentations?</p>\n<p>This presentations plugin provides shortcodes to let you quickly and easily put together amazing presentations!</p>\n<p>Supported features include:<br>\n&lt;ul&gt;<br>\n&lt;li&gt;Choosing slide transitions&lt;/li&gt;<br>\n&lt;li&gt;Rotating and scaling slides for extra awesomeness&lt;/li&gt;<br>\n&lt;li&gt;Setting presentation backgrounds with solid colors or images&lt;/li&gt;<br>\n&lt;li&gt;Setting transition durations and sizes&lt;/li&gt;<br>\n&lt;/ul&gt;<br>\n[ /slide ]<br>\n[ slide bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/bg-arrow.jpg" ]<br>\n&lt;h3&gt;Viewing&lt;/h3&gt;<br>\n[ twocol_one ]Presentations can be navigated either using the onscreen arrows, or by using keyboard arrow keys.<br>\nTab or space will also navigate the slideshow forward.Fullscreen mode is toggled using the icon on the lower right.</p>\n<p>Hitting ESC on the keyboard will also exit fullscreen.[ /twocol_one ] [ twocol_one_last ][ /twocol_one_last ]<br>\n[ /slide ]<br>\n[ slide ]<br>\nTo begin, simply start with the presentation shortcode. Then put all your individual slide content inside slide shortcodes and you are good to go!<br>\n[ /slide ]<br>\n[ slide transition="down" ]<br>\n&lt;h2&gt;Down&lt;/h2&gt;<br>\nThe default transition!<br>\n[ /slide ]<br>\n[ slide transition="right" ]<br>\n&lt;h2&gt;Right&lt;/h2&gt;<br>\n[ /slide ]<br>\n[ slide transition="up" ]<br>\n&lt;h2&gt;Up&lt;/h2&gt;<br>\n[ /slide ]<br>\n[ slide transition="left" ]<br>\n&lt;h2&gt;Left&lt;/h2&gt;<br>\n[ /slide ]<br>\n[ slide ]<br>\n&lt;h2&gt;Or none!&lt;/h2&gt;<br>\nWhich only really works when fading is enabled.<br>\n[ /slide ]<br>\n[ slide rotate=45 ]<br>\nRotation</p>\n<p>Slides can be rotated using [ slide rotate= ] where the value is in degrees.<br>\n[ /slide ]<br>\n[ slide ]<br>\nScaling</p>\n<p>Emphasize your big ideas or explain the tiny details using [ slide scale= ].<br>\n[ /slide ]<br>\n[ slide scale=5 ]<br>\nBackgrounds</p>\n<p>Solid color backgrounds can be set using slide bgcolor= where the value can be any valid HTML color.</p>\n<p>Alternatively slide bgimg= with a valid image url will set it as the background, stretching the image to fill the slide.<br>\n[ /slide ]<br>\n[ slide fade=off ]<br>\nFading</p>\n<p>Fading between is enabled by default. It can easily be disabled via slide fade= with a value of &ldquo;off&rdquo; or &ldquo;false&rdquo;.<br>\n[ /slide ]<br>\n[ slide ]<br>\nEnjoy making your own presentations <img src="http://i1.wp.com/www.gd6d.fr/wordpressfr/wp-includes/images/smilies/icon_smile.gif" alt=":)" class="wp-smiley"></p>\n<p>[ /slide ]<br>\n[ /presentation ]</p>\n<p></p>\n</div>\n<input type="hidden" name="title_open" value="Fermer"><input type="hidden" name="title_closed" value="Voir le code">\n</div>\n<br><div class="woo-sc-hr"></div>\n<h2>Pour int&eacute;grer une pr&eacute;sentation</h2>\n<p>Ce module fonctionne tout naturellement avec des shortcodes et des variables qui permettent d&rsquo;en ajuster le comportement :</p>\n<ul>\n<li>S&eacute;lectionner diff&eacute;rentes transitions</li>\n<li>Effets de rotation et zoom</li>\n<li>Image ou couleur de fond</li>\n<li>Dur&eacute;e de transition</li>\n</ul>\n<p>On est donc en pr&eacute;sence d&rsquo;un outil minimaliste, mais complet et qui peut rendre d&rsquo;autres services, comme nous allons le voir.</p>\n<h3>Les shortcodes &agrave; utiliser</h3>\n<p>Pour cr&eacute;er une pr&eacute;sentation, utilisez simplement :<br>\n[ <code>presentation</code> ]</p>\n<p>Pour cr&eacute;er une diapo, utilisez :<br>\n[ <code>slide</code> ]</p>\n<p>Tous les [ <code>slide</code> ] doivent &ecirc;tre encadr&eacute;es par le shortcode [ <code>presentation</code> ], sinon les diapositives ne seront pas affich&eacute;es.</p>\n<p>Les param&egrave;tres tels que <em>la hauteur,</em> la <em>largeur</em> et la <em>dur&eacute;e de transition</em> (en seconde) peuvent tous &ecirc;tre configur&eacute;s en utilisant les attributs respectifs dans le shortcode [ <code>presentation</code> ] .</p>\n<p>Par exemple:</p>\n<p>Pour cr&eacute;er une pr&eacute;sentation de dimension 600 &times; 375 (comme dans l&rsquo;exemple ci-dessus), utilisez:<br>\n[ <code>presentation width=600 height=375</code> ]</p>\n<p>Pour d&eacute;finir une dur&eacute;e de transition pour chaque diapositive &eacute;gale &agrave; 5 secondes, utilisez:<br>\n[ <code>presentation duration=5</code> ]</p>\n<div class="shortcode-toggle toggle-les-codes-de-transition-et-dhabillage-en-detail closed default border">\n<h4 class="toggle-trigger"><a rel="nofollow">Les codes de transition et d''habillage en d&eacute;tail</a></h4>\n<div class="toggle-content">\n<h4 id="transitions">Quelques effets de transition</h4>\n<p>Voici une liste des effets de transition disponibles (&agrave; utiliser avec mod&eacute;ration&hellip;) :</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place vers le bas (la transition par d&eacute;faut), utilisez:<br>\n[ <code>slide transition="down"</code> ]</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place &agrave; droite, utilisez:<br>\n[ <code>slide transition="right"</code> ]</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place de bas en haut, utilisez:<br>\n[ <code>slide transition="up"</code> ]</p>\n<p>Pour cr&eacute;er une transition qui se d&eacute;place &agrave; gauche, utilisez:<br>\n[ <code>slide transition="left"</code> ]</p>\n<p>Pour ne pas afficher de transition, utilisez:<br>\n[ <code>slide transition="none"</code> ]</p>\n<h4 id="rotation-and-scaling">L&rsquo;effet rotation et mise &agrave; l&rsquo;&eacute;chelle</h4>\n<p>Vous pouvez faire pivoter et modifier la taille des diapositives pour cr&eacute;er diff&eacute;rents effets. Pour faire pivoter une diapositive, utilisez:</p>\n<p>[ <code>slide rotate=</code> ]</p>\n<p>La valeur est en degr&eacute;s. Par exemple: [ <code>slide rotate=45</code> ].</p>\n<p>Pour redimensionner une diapositive, utilisez:</p>\n<p>[ <code>slide scale=</code> ]</p>\n<p>Par exemple: [ <code>slide scale=5</code> ] ou [ <code>slide scale=1.75</code> ].</p>\n<h4 id="fading">Effet de fondu enchain&eacute;</h4>\n<p>Fondu encha&icirc;n&eacute; entre les diapositives est activ&eacute;e par d&eacute;faut. Pour le d&eacute;sactiver, utilisez:</p>\n<p>[ <code>slide fade="off"</code> ] ou [ <code>slide fade="false"</code> ]</p>\n<p>Pour le r&eacute;activer, utilisez:</p>\n<p>[ <code>slide fade="on"</code> ] ou [ <code>slide fade="true"</code> ]</p>\n<h4 id="background">Fond de diapo</h4>\n<p>Vous pouvez habiller un diaporama avec un fond de couleur ou une image personnalis&eacute;e. Pour d&eacute;finir une couleur unie, utilisez:</p>\n<p>[ <code>slide bgcolor=</code> ]</p>\n<p>La valeur est une couleur HTML valide. Par exemple: [ <code>slide bgcolor=#d3e7f8</code> ].</p>\n<p>Pour d&eacute;finir une image de fond, utilisez:</p>\n<p>[ <code>slide bgimg=</code> ]</p>\n<p>La valeur est l&rsquo;adresse URL de l&rsquo;image valide. la taille de l&rsquo;image s&rsquo;ajustera automatiquement &agrave; la diapositive.</p>\n<p><em>Astuce:</em> Toutes ces options peuvent &ecirc;tre r&eacute;gl&eacute;es sur la balise [ <code>presentation</code> ] pour les d&eacute;finir comme param&egrave;tres par d&eacute;faut.</p>\n</div>\n<input type="hidden" name="title_open" value="Fermer"><input type="hidden" name="title_closed" value="Les codes de transition et d''habillage en d&eacute;tail">\n</div>\n<br><div class="woo-sc-divider"></div> \n<h4>Lecture de la pr&eacute;sentation</h4>\n<p>Vous pouvez visionner une pr&eacute;sentation en plein &eacute;cran en cliquant sur l&rsquo;ic&ocirc;ne &agrave; quatre fl&egrave;che en bas &agrave; droite du diaporama. La touche ESC du clavier permet alors de quitter le mode plein &eacute;cran.</p>\n<p>Pour naviguer, on peut utiliser les fl&egrave;ches &agrave; l&rsquo;&eacute;cran ou les touches fl&eacute;ch&eacute;es du clavier. Vous pouvez &eacute;galement utiliser les touches tabulation ou d&rsquo;espace pour afficher la diapositive suivante.</p>\n<h4 id="viewing">Et pour les diaporamas photos, on a le droit ???</h4>\n<p>C&rsquo;est une utilisation int&eacute;ressante de cette fonctionnalit&eacute; : int&eacute;grer un diaporama photo avec fonction zoom plein &eacute;cran. C&rsquo;est tr&egrave;s simple &agrave; mettre en place et en plus on peut rajouter du texte, comme ici :</p>\n<p></p>\n<p class="not-supported-msg" style="display:inherit;padding:25%;text-align:center;">Impossible de lancer ce diaporama. Raffra&icirc;chissez la page&hellip; ou essayez un autre navigateur.</p>\n<br><div class="shortcode-toggle toggle-voir-le-code closed default border">\n<h4 class="toggle-trigger"><a rel="nofollow">Voir le code</a></h4>\n<div class="toggle-content">\n<br>\nCode utilis&eacute; pour le diaporama&hellip; pas compliqu&eacute;, non ?<br><em>Attention, j&rsquo;ai rajout&eacute; un espace autour des crochets !</em>\n<pre>[ presentation width=500 height=313 ]\n[ slide bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb12.jpg" transition="right" ]\n&lt;h2&gt;Formation WordPress&lt;/h2&gt;\n&lt;h3&gt;pour l''IIM&lt;/h3&gt;\n[ /slide ]\n[ slide transition="right" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb19.jpg" ]\n[ /slide]\n[ slide transition="right" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb06.jpg" ]\n[ /slide]\n[ slide transition="right" bgimg="http://www.gd6d.fr/wordpressfr/wp-content/uploads/2013/09/LangageWeb03.jpg" ]\n[ /slide ]\n[ /presentation ]</pre>\n<p></p>\n</div>\n<input type="hidden" name="title_open" value="Fermer"><input type="hidden" name="title_closed" value="Voir le code">\n</div>\n<div class="woo-sc-hr"></div>\n<h4>Conclusion</h4>\n<p>Au final, Le shortcode &laquo;&nbsp;Presentation&nbsp;&raquo; propos&eacute; avec JetPack est une fonction int&eacute;ressante &agrave; conna&icirc;tre. Elle peut rendre de nombreux services. Gageons qu&rsquo;elle sera l&rsquo;outil indispensable de tout d&eacute;veloppeur WordPress pour ses propres pr&eacute;sentations ! A voir au prochain WordCamp ?</p>\n<div class="woo-sc-divider"></div>\n<p>PS : Attention, j&rsquo;ai &eacute;t&eacute; confront&eacute; &agrave; un petit bug (avec Woothemes ??). Apr&egrave;s chaque pr&eacute;sentation, la balise &lt; <code>section</code> &gt; se referme et la mise en page explose ! J&rsquo;ai d&ucirc; rajouter dans le code html la balise correspondante pour r&eacute;-ouvrir la section&hellip;</p>\n<div class="woo-sc-box info  rounded full">Article source &laquo;&nbsp;<a rel="nofollow" title="Voir l''article" target="_blank" href="http://en.support.wordpress.com/presentations/">Shortcode : presentation</a>&nbsp;&raquo; sur le support de WordPress.com </div>\n<p>Cet article <a rel="nofollow" target="_blank" href="http://www.gd6d.fr/wordpressfr/blog/creer-presentation-diffuser-site-jetpack/">Cr&eacute;er une pr&eacute;sentation et la diffuser dans son site avec&hellip; JETPACK</a> est apparu en premier sur <a rel="nofollow" target="_blank" href="http://www.gd6d.fr/wordpressfr">Gd6d - sp&eacute;cialiste WordPress</a>.</p>\n<img src="http://feeds.feedburner.com/~r/Gd6d/~4/Rng_PI-XPNg" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Here With Me : Stress test de l’extension WP Rocket";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.herewithme.fr/2013/09/08/stress-test-extension-wp-rocket/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:68:"http://www.herewithme.fr/2013/09/08/stress-test-extension-wp-rocket/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-09-08T02:16:18+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:16907:"<div>\n<p><img class="alignright size-full wp-image-1394" alt="wp rocket Stress test de lextension WP Rocket" src="http://www.herewithme.fr/wp-content/uploads/2013/09/wp-rocket.png" width="231" height="198" title="Stress test de lextension WP Rocket">Difficile&nbsp;exercice que de faire le test d&rsquo;une extension WordPress,&nbsp;d&eacute;velopp&eacute;e&nbsp;par des personnalit&eacute;s &eacute;minentes de la communaut&eacute; fran&ccedil;aise. (Xavier me dirait : diplomatie, diplomatie&hellip;)</p>\n<p>Je me lance tout de m&ecirc;me dans l&rsquo;aventure&hellip;</p>\n<p>Apr&egrave;s avoir lu beaucoup d&rsquo;articles d&eacute;di&eacute;s &agrave; l&rsquo;extension (dont beaucoup s&rsquo;apparentent davantage &agrave; la de publi-information qu&rsquo;&agrave; une v&eacute;ritable analyse), j&rsquo;ai profit&eacute; d&rsquo;une promo sur Twitter pour acqu&eacute;rir une licence &laquo;&nbsp;professionnelle&nbsp;&raquo; et j&rsquo;ai test&eacute; l&rsquo;extension sur une plateforme de d&eacute;veloppement ainsi que sur 2 projets en phase de production pour me forger MON opinion.</p>\n<p>Voici le premier article de la s&eacute;rie stress test d&rsquo;un plugin WP !</p>\n<h2>La promesse cliente</h2>\n<p>WP-Rocket est une extension pour WordPress qui a comme vocation d&rsquo;am&eacute;liorer les performances de votre site internet. C&rsquo;est une extension&nbsp;&nbsp;&raquo;premium&nbsp;&raquo;, vendue sous 3 licences : personnelle, business et professionnelle.</p>\n<p>Les&nbsp;fonctionnalit&eacute;s&nbsp;propos&eacute;es sont :</p>\n<ul>\n<li>Mise en cache des pages</li>\n<li>Pr&eacute;chargement du cache</li>\n<li>Compression des fichiers statiques</li>\n<li>Chargement diff&eacute;r&eacute; des images</li>\n<li>Optimisation pour le navigateur</li>\n<li>Optimisation des images</li>\n<li>Chargement diff&eacute;r&eacute; des fichiers JavaScript</li>\n</ul>\n<p>Juste que l&agrave;, c&rsquo;est du tr&egrave;s classique on retrouve ni plus ni moins que tous les ingr&eacute;dients de la &laquo;&nbsp;performance web&nbsp;&raquo;.</p>\n<p>Mais la vraie promesse cliente du plugin &agrave; mes yeux, c&rsquo;est &laquo;&nbsp;une configuration rapide&nbsp;&raquo;.</p>\n<p>Dans l&rsquo;univers des plugins WordPress, on trouve des centaines d&rsquo;extensions ayant comme objectif d&rsquo;am&eacute;liorer la performance web d&rsquo;un site internet, et ces extensions partagent syst&eacute;matiquement le m&ecirc;me point commun : elles sont complexes et proposent des tonnes d&rsquo;options. Et le pire, c&rsquo;est que ces options ne sont utilis&eacute;es que par une minorit&eacute; de personnes.</p>\n<p>WP Rocket, &agrave; l&rsquo;image de l&rsquo;extension WYSIJA, mise sur le c&ocirc;t&eacute;&nbsp;simple, rapide et p&eacute;dagogique de leur extension. (un principe de base de la philosophie WP : <a rel="nofollow" target="_blank" href="http://wordpress.org/about/philosophy/#decisions">D&eacute;cisions, not options</a>)</p>\n<p>Et de ce c&ocirc;t&eacute;, on est tr&egrave;s bien servi ! L&rsquo;interface est&nbsp;extr&ecirc;mement&nbsp;propre, les r&eacute;glages de base permettent d&rsquo;activer facilement les fonctionnalit&eacute;s&nbsp;principales de l&rsquo;extension.</p>\n<p>A noter qu&rsquo;il ne semble pas possible de d&eacute;sactiver le cache statique, donc impossible de n&rsquo;utiliser que les fonctionnalit&eacute;s de minification ou de chargement diff&eacute;r&eacute; des images.</p>\n<h2>Analyse technique</h2>\n<p>La question que l&rsquo;on peut se poser face &agrave; une extension qui promet d&rsquo;am&eacute;liorer la performance, c&rsquo;est comment ? Quels m&eacute;canismes sont mis en place ? Les voici en d&eacute;tails</p>\n<h3>Cache statique</h3>\n<p>LA fonctionnalit&eacute; la plus r&eacute;pandue pour am&eacute;liorer la performance d&rsquo;un site WordPress, c&rsquo;est d&rsquo;installer et configurer un cache statique. Le principe est simple, le premier visiteur consulte une page de votre site, le code HTML est g&eacute;n&eacute;r&eacute; dynamiquement par WP et il est stock&eacute; dans le cache pour une dur&eacute;e d&eacute;finie, les visiteurs suivants consultent alors la copie HTML.</p>\n<p>Sur ce point, le plugin est tr&egrave;s classique, les fichiers de cache sont stock&eacute;s sur le syst&egrave;me de fichiers (dans le dossier wp-rocket-cache), ce choix exclut &laquo;&nbsp;en grande majorit&eacute;&nbsp;&raquo; les architectures multi-serveurs (rare c&rsquo;est vrai). A noter, que le cache peut &ecirc;tre diff&eacute;renci&eacute; pour les mobiles, ceci afin de permettre l&rsquo;utilisation de th&egrave;me sp&eacute;cifique. (WP-Touch notamment)</p>\n<p>Ma grande surprise concernant le cache statique et WP Rocket, c&rsquo;est la non-utilisation &nbsp;du &laquo;&nbsp;drop-in&nbsp;&raquo; <em>advanced-cache.php</em>. Ce fichier, que l&rsquo;on trouve g&eacute;n&eacute;ralement dans le dossier <em>wp-content </em>pour peu que votre installation WP utilise un plugin de cache statique &laquo;&nbsp;traditionnel&nbsp;&raquo; permet de g&eacute;rer la fonctionnalit&eacute; de cache statique assez t&ocirc;t dans l&rsquo;ex&eacute;cution de WordPress.</p>\n<p>Ici, point de dropin advanced-cache.php, le plugin utilise exclusivement les r&egrave;gles de r&eacute;&eacute;critures (automatiquement ajout&eacute; dans le fichier .htaccess) pour permettre au serveur HTTP de charger les copies HTML en cache sans solliciter WordPress, ni PHP. C&rsquo;est la technique la plus performante, mais elle requiert l&rsquo;utilisation du serveur HTTP Apache2, cela veut dire que si votre serveur web est NGINX, ou bien Microsoft IIS, le plugin ne sollicitera jamais le cache statique g&eacute;n&eacute;r&eacute;.</p>\n<p>Il faut donc pr&eacute;voir le fait que &laquo;&nbsp;WP-Rocket&nbsp;&raquo; apporte des restrictions suppl&eacute;mentaires par rapport aux pr&eacute;requis de WordPress. Ce qui est dommage, c&rsquo;est qu&rsquo;il est techniquement possible de cumuler les 2 fonctionnalit&eacute;s, c&rsquo;est notamment ce que r&eacute;alise l&rsquo;extension WP-Super-Cache, elle propose de servir les fichiers directement avec le serveur HTTP, et &agrave; d&eacute;faut elle utilise le dropin pour charger la copie en cache un peu plus tard dans le processus.</p>\n<h3>LazyLoad</h3>\n<p>La technique LazyLoad permet de diff&eacute;rer le chargement des images, pour r&eacute;sum&eacute;, seules les images affich&eacute;es r&eacute;ellement sur l&rsquo;&eacute;cran de vos internautes sont t&eacute;l&eacute;charg&eacute;es. Les images pr&eacute;sentes en base de page ne seront t&eacute;l&eacute;charg&eacute;es que si l&rsquo;utilisateur scroll dans son navigateur et affiche cette partie du site.</p>\n<p>La fonctionnalit&eacute; agit uniquement sur le contenu des articles/pages, les widgets, les images &agrave; la une et les avatars. A noter que le code JS n&eacute;cessaire pour cette fonctionnalit&eacute; est ajout&eacute; automatiquement dans le code HTML de votre page afin d&rsquo;&eacute;viter de charger une ressource suppl&eacute;mentaire.</p>\n<h3>Concat&eacute;nation &amp; Minification des JS/CSS</h3>\n<p>La concat&eacute;nation et la minification des ressources JavaScript et des feuilles de style CSS permettent de diminuer le nombre de requ&ecirc;tes HTTP n&eacute;cessaires &agrave; l&rsquo;affichage d&rsquo;une page internet. Le plugin fait appel &agrave; la librairie PHP &laquo;&nbsp;minify&nbsp;&raquo;, &eacute;galement utilis&eacute; par le plugin WP-Minify/BWP-Minify.</p>\n<p>C&rsquo;est donc une valeur s&ucirc;re en terme de technologie, par contre on ne peut &ecirc;tre que d&eacute;&ccedil;u que ce script ne g&eacute;n&egrave;re pas de vrais fichiers CSS/JS comme peut notamment le faire AssetsMinify ou W3 Total Cache.</p>\n<p>Les requ&ecirc;tes vers les ressources JS/CSS font syst&eacute;matiquement appel &agrave; une ressource PHP, moins performante et qui peut s&rsquo;av&eacute;rer probl&eacute;matique &nbsp;lors de la mise en place d&rsquo;un CDN notamment.</p>\n<h3>Compression, expiration des ressources statiques</h3>\n<p>Le plugin affine largement la configuration du serveur web HTTP Apache2 (via le fichier .htaccess) en red&eacute;finissant les propri&eacute;t&eacute;s de mise en cache, de compression des ressources statiques, etc. Cela permet notamment de sp&eacute;cifier que les ressources JS/CSS doivent &ecirc;tre mises en cache par les navigateurs pour une dur&eacute;e d&eacute;finie, et non rafraichies &agrave; chaque visite de la page.</p>\n<p>Les r&egrave;gles ajout&eacute;es sont tr&egrave;s r&eacute;pandues sur la toile, on peut notamment les retrouver dans le starter-kit de r&eacute;f&eacute;rence <a rel="nofollow" target="_blank" href="http://html5boilerplate.com/">HTML5 Boilerplate</a>.</p>\n<h3>Divers</h3>\n<p>Enfin, je passe tr&egrave;s rapidement sur les autres fonctionnalit&eacute;s de l&rsquo;extension que je consid&egrave;re comme mineure ou comme trop &laquo;&nbsp;avanc&eacute;e&nbsp;&raquo; :</p>\n<ul>\n<li>Cookie de 3 minutes pour les personnes ayant post&eacute; un commentaire</li>\n<li>JavaScript avec l&rsquo;attribut &laquo;&nbsp;deferred&nbsp;&raquo; + utilisation du script LABjs</li>\n<li>Suppression des num&eacute;ros de version dans les ressources JS/CSS, notamment s&rsquo;il s&rsquo;agit du num&eacute;ro de version de WP</li>\n<li>Sp&eacute;cification syst&eacute;matique des dimensions des images</li>\n</ul>\n<h2>La sp&eacute;cificit&eacute; du projet et de l&rsquo;extension : Le pr&eacute;chargement</h2>\n<p>Une fonctionnalit&eacute; int&eacute;ressante du projet, c&rsquo;est le pr&eacute;chargement du cache. Au lieu de laisser vos visiteurs patienter lors de la g&eacute;n&eacute;ration des copies HTML et leur mise en cache, le plugin sollicite un robot qui parcourt pour vous les pages les plus visit&eacute;es de votre site pour pr&eacute;charger le cache.</p>\n<p>Notez que ce n&rsquo;est pas une fonctionnalit&eacute; exclusive &agrave; ce projet, le plugin WP Super Cache propose d&eacute;j&agrave; la m&ecirc;me chose. (le c&ocirc;t&eacute; complexe et mystique en plus)</p>\n<p>La diff&eacute;rence, c&rsquo;est que le robot n&rsquo;est pas int&eacute;gr&eacute; au plugin, le robot fonctionne depuis les serveurs de WP-Rocket et ce choix technique est contestable &agrave; mes yeux&nbsp;pour plusieurs points :</p>\n<ul>\n<li>Confidentialit&eacute;, un robot de cette nature fournit indirectement des donn&eacute;es concernant l&rsquo;activit&eacute; d&rsquo;un site internet</li>\n<li>Confidentialit&eacute;, la pr&eacute;sence du robot indique aux auteurs l&rsquo;existence d&rsquo;un site</li>\n<li>Restriction d&rsquo;utilisation, notamment dans la cadre d&rsquo;un site intranet, sans domaine public</li>\n<li>Restriction d&rsquo;utilisation, notamment si le site est prot&eacute;g&eacute; par une authentification</li>\n</ul>\n<p>Alors effectivement, dans la cadre d&rsquo;un site personnel, d&rsquo;un site de TPE/PME, &ccedil;a peut sembler assez anodin. Mais en entreprise, ma cible pr&eacute;f&eacute;r&eacute;e pour WP, c&rsquo;est clairement un mode de fonctionnement&nbsp;r&eacute;dhibitoire.&nbsp;Par ailleurs, la fonctionnalit&eacute; n&rsquo;est pas d&eacute;sactivable&hellip;</p>\n<p>Dans le m&ecirc;me th&egrave;me, l&rsquo;obligation de d&eacute;clarer chaque site utilisant le plugin via le site officiel est quelque chose d&rsquo;assez contraignant. Sur ce point, le mode de fonctionnement de la licence GravityForms est bien plus pratique. Bien heureusement, le contr&ocirc;le de licence est facilement d&eacute;sactivable dans le code source PHP&hellip;</p>\n<h2>Benchmark : Avant/Apr&egrave;s ?</h2>\n<p>Pour &ecirc;tre tout &agrave; fait honn&ecirc;te, j&rsquo;avais initialement pr&eacute;vu d&rsquo;afficher les notes GTmetrix avant et apr&egrave;s.Mais je suis revenu sur ma d&eacute;cision car l&rsquo;impact de l&rsquo;extension sur les performances d&rsquo;un site WordPress d&eacute;pend d&rsquo;un trop grand nombre de param&egrave;tres, notamment :</p>\n<ul>\n<li>L&rsquo;h&eacute;bergement, le plugin peut tr&egrave;s bien fonctionner chez un prestataire A, et avoir un effet quasiment nul chez un prestataire B, notamment s&rsquo;il manque des modules Apache2&hellip;</li>\n<li>Le projet, le th&egrave;me et les extensions utilis&eacute;s, le plugin fonctionne parfaitement avec une installation fraiche, mais il peut g&eacute;n&eacute;rer des conflits JS important sur les th&egrave;mes premiums ou les projets &laquo;&nbsp;complexes&nbsp;&raquo;&hellip;</li>\n</ul>\n<p>Personnellement, j&rsquo;ai rencontr&eacute; des probl&egrave;mes de minification sur les 2 sites de production que j&rsquo;ai test&eacute;, et une fois les probl&egrave;mes r&eacute;solus (ou plut&ocirc;t contourn&eacute;) j&rsquo;ai constat&eacute; une baisse de la notation GTmetrix, malgr&eacute; une am&eacute;lioration de l&rsquo;impression de fluidit&eacute;&hellip;</p>\n<p>Mais tout cela n&rsquo;est gu&egrave;re &eacute;tonnant car ces projets n&rsquo;ont pas &eacute;t&eacute; b&acirc;tis autour de cette extension, il n&rsquo;est donc pas anormal de rencontrer des conflits de cette nature&hellip;</p>\n<p>En conclusion de ce chapitre, je pense que le benchmark comparatif de la performance des plugins de cache est possible, mais il ne refl&egrave;te absolument pas le niveau de performance que vous allez pouvoir obtenir sur votre installation.</p>\n<p>Par exp&eacute;rience, selon les projets et les plugins utilis&eacute;s, j&rsquo;obtiens parfois de meilleurs r&eacute;sultats avec Hyper-Cache, et parfois c&rsquo;est WP-Super-Cache qui fait des merveilles&hellip;</p>\n<h2>Faut-il passer son chemin ?</h2>\n<p>C&rsquo;est une question tr&egrave;s compliqu&eacute;e et la r&eacute;ponse varie selon moi d&rsquo;apr&egrave;s votre niveau technique et l&rsquo;environnement technique de votre projet.</p>\n<p>On peut d&eacute;j&agrave; &eacute;liminer WP-Rocket dans les situations suivantes :</p>\n<ul>\n<li>Utilisation d&rsquo;un serveur web exotique NGINX, Cherokee, Microsoft IIS</li>\n<li>Utilisation d&rsquo;un reverse-proxy avec Varnish ou autre (bien que compatible)</li>\n<li>Architecture multi-serveur, car le cache aura davantage sa place dans un cache objet (cf Batcache)</li>\n<li>Projet d&rsquo;intranet</li>\n</ul>\n<p>Dans ce type d&rsquo;environnement, vous n&rsquo;utiliserez pas 100% des fonctionnalit&eacute;s de WP-Rocket et d&rsquo;autres solutions sont &agrave; consid&eacute;rer &agrave; mon avis.</p>\n<p>Ensuite&hellip;</p>\n<h3>Si vous &ecirc;tes fauch&eacute;s/radins/amateurs des logiciels libres et que vous &ecirc;tes un bidouilleur :<br>\nou<br>\nSi vous &ecirc;tes un professionnel/d&eacute;veloppeur WP :</h3>\n<p>Passez votre chemin, et installez le jeu d&rsquo;extensions suivant</p>\n<ul>\n<li>LazyLoad</li>\n<li>WP Super Cache ou HyperCache</li>\n<li>BWP Minify</li>\n<li>+ fichier HTACCESS optimis&eacute; en s&rsquo;inspirant des r&egrave;gles de HTML5 Boilerplate</li>\n</ul>\n<p>Vous obtiendrez un p&eacute;rim&egrave;tre fonctionnel tr&egrave;s proche de WP-Rocket, des plugins interchangeables et un niveau de performances comparable.</p>\n<h3>Si vous n&rsquo;aviez rien compris &agrave; cet article, que vous n&rsquo;&ecirc;tes pas un bidouilleur ou que vous n&rsquo;avez tout simplement pas de temps &agrave; investir dans la performance web :</h3>\n<p>Vous devriez probablement ouvrir un blog sur WordPress.com ou &agrave; d&eacute;faut prendre une licence WP-Rocket car, et c&rsquo;est ma conclusion,<strong> WP-Rocket ce n&rsquo;est pas simplement une extension de plus &agrave; installer, c&rsquo;est &eacute;galement un service de support (gratuit le temps de la licence &ndash; 1 an) pour vous assister &agrave; la bonne mise en place de la solution.</strong></p>\n<p>Pour avoir fait un tour rapide dans le forum de support, on constate qu&rsquo;une extension de cette nature g&eacute;n&egrave;re beaucoup de discussion, car chaque installation est unique et les bugs rencontr&eacute;s sont &agrave; g&eacute;rer au cas par cas.</p>\n<p>Et donc m&ecirc;me si je ne partage pas l&rsquo;ensemble des choix techniques r&eacute;alis&eacute;s, et que je pr&eacute;f&egrave;re une solution compos&eacute;e de diff&eacute;rentes extensions, je tiens juste &agrave; tirer mon chapeau pour le travail de support que r&eacute;alise les auteurs de cette belle et prometteuse extension.</p>\n<h3>Ma wishlist</h3>\n<p>Assez courte :</p>\n<ul>\n<li>Support de advanced-cache.php</li>\n<li>Documentation &eacute;largie au serveur HTTP Nginx</li>\n<li>Robot de pr&eacute;chargement, en local ou &agrave; distance (au choix)</li>\n<li>Am&eacute;lioration du moteur de minification\n<ul>\n<li>Notamment le filtre d&rsquo;exclusion, qui exclut bien le JS de la minification mais qui le d&eacute;place tout de m&ecirc;me dans l&rsquo;ent&ecirc;te de la page :(</li>\n<li>Utilisation de AssetsMinify ?</li>\n</ul>\n</li>\n<li>Suppression du contr&ocirc;le de licence en mode GravityForms (utilis&eacute; pour les MAJ)</li>\n</ul>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"Blog Tool Box : WordPress : exclure ses propres visites dans Google Analytics";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:65:"http://blogtoolbox.fr/wordpress-exclure-visites-google-analytics/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:65:"http://blogtoolbox.fr/wordpress-exclure-visites-google-analytics/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-08-19T00:05:18+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:2240:"<div>\n<p>Si vous avez un site qui fait peu de visites, il est tr&egrave;s important d&rsquo;exclure son propre trafic dans Google Analytics pour ne pas fausser les statistiques.<br>\nChaque aper&ccedil;u d&rsquo;article, chaque test sur le design, chaque recherche d&rsquo;un article lors de la r&eacute;daction, etc, entra&icirc;nent des remont&eacute;es de pages vues inutiles dans Analytics.</p>\n<h2>Exclure son propre trafic via un filtre</h2>\n<p>Solution la plus simple si vous avez une adresse IP fixe, il suffit d&rsquo;acc&eacute;der &agrave; l&rsquo;administration du compte ou du profil Analytics puis d&rsquo;acc&eacute;der aux &laquo;&nbsp;Filtres&nbsp;&raquo;. De l&agrave;, il ne reste plus qu&rsquo;&agrave; cr&eacute;er un nouveau filtre qui va exclure le trafic en provenance de votre adresse IP.</p>\n<p><img src="http://blogtoolbox.fr/wp-content/uploads/filtre-google-analytics.png" alt="Filtre Google Analytics"></p>\n<p>A noter que si vous &ecirc;tes plusieurs r&eacute;dacteurs, si vous &eacute;crivez de plusieurs endroits, etc, il sera n&eacute;cessaire de mettre en place plusieurs filtres d&rsquo;IP.</p>\n<h2>Ne pas charger le code de tracking pour les administrateurs/utilisateurs connect&eacute;s</h2>\n<p>Une autre solution est de ne pas lancer le code Google Analytics si le visiteur est un administrateur du site WordPress. Pour ce faire, il suffit d&rsquo;englober le code de tracking par la condition suivante : si le visiteur est un administrateur logg&eacute; alors le code de tracking n&rsquo;est pas actif.</p>\n<p>Exemple ci-dessous : le code Google Analytics est mis en place seulement si l&rsquo;utilisateur (current_user_can) n&rsquo;a pas la capacit&eacute; de modifier les options de WordPress (manage_options = administrateur).</p>\n<pre><code>&lt;?php if(!current_user_can(''manage_options'')){ ?&gt;\n  &lt;script type="text/javascript"&gt;\n    [...] script Google Analytics [...]\n  &lt;/script&gt;\n&lt;?php } ?&gt;</code></pre>\n<p>Il est &eacute;galement possible d&rsquo;utiliser la fonction WordPress <a rel="nofollow" target="_blank" href="http://codex.wordpress.org/Function_Reference/is_user_logged_in"><i>is user logged in()</i></a> pour matcher tous les utilisateurs connect&eacute;s.</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Insidedaweb : Les Solutions Flipbooks pour WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:152:"http://www.insidedaweb.com/wordpress-seo/solutions-flipbooks-wordpress/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=solutions-flipbooks-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:152:"http://www.insidedaweb.com/wordpress-seo/solutions-flipbooks-wordpress/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=solutions-flipbooks-wordpress";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-06-12T11:29:47+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:652:"<div>\n<p>Aujourd&rsquo;hui, les magazines ou les brochures feuilletables en ligne sont de plus en plus pr&eacute;sents sur la toile, en effet, cela constitue une solution avantageuse pour diffuser vos documents, PDF et autres e-books. Les flipbooks sont [&hellip;]</p>\n<p>Cet article <a rel="nofollow" target="_blank" href="http://www.insidedaweb.com/wordpress-seo/solutions-flipbooks-wordpress/">Les Solutions Flipbooks pour WordPress</a> est apparu en premier sur <a rel="nofollow" target="_blank" href="http://www.insidedaweb.com/">Blog WordPress, Blog eCommerce, Blog R&eacute;f&eacute;rencement, Emailing &amp; FOSS. Le site 5 en 1</a>.</p>\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Lumière de Lune : Optimiser son thème WordPress";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:76:"http://www.lumieredelune.com/encrelune/optimiser-theme-referencement,2013,04";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:76:"http://www.lumieredelune.com/encrelune/optimiser-theme-referencement,2013,04";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2013-04-09T10:28:45+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:424:"<div>Comme le disait Niou142 en commentaire : on regarde le th&egrave;me :ok il est joli. Mais finalement qui regarde le code source ? Moi&hellip; parce que le code source c&rsquo;est essentiel pour le r&eacute;f&eacute;rencement, et les d&eacute;fauts les plus courants sont parfois extr&ecirc;mement p&eacute;nibles &agrave; corriger (surtout quand il s&rsquo;agit d&rsquo;un th&egrave;me &agrave; options avec [...]</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"Fran6art : Ma veille en détails: historique et outils utilisés.";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:61:"http://feedproxy.google.com/~r/Fran6artLeBlog/~3/SqxjR5rCujU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:61:"http://feedproxy.google.com/~r/Fran6artLeBlog/~3/SqxjR5rCujU/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2012-10-16T14:35:34+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:14479:"<div>\n<p>Hier, mon ami Aur&eacute;lien d&rsquo;All For Design a publi&eacute; <a rel="nofollow" target="_blank" href="http://all-for-design.com/web-design/les-outils-de-ma-veille/">un article int&eacute;ressant</a> expliquant comment il fait sa veille. Je trouve la d&eacute;marche tr&egrave;s int&eacute;ressante parce qu&rsquo;elle permet &agrave; tous de d&eacute;couvrir de nouveaux sites et de nouveaux services. On faisait pas mal &ccedil;a il y a quelques ann&eacute;es, quand le blogging &eacute;tait &agrave; son apog&eacute;e et on a un peu perdu cette habitude. Donc j&rsquo;ai voulu, d&rsquo;une certaine mani&egrave;re, r&eacute;pondre &agrave; Aur&eacute;lien en d&eacute;taillant ici comment je fais ma veille en ligne, comment je me tiens au courant des news du web.</p>\n<p><strong>Une question de temps</strong></p>\n<p>Je crois qu&rsquo;avant de d&eacute;tailler comment je fais ma veille, il est important de parler du facteur temps. Quand j&rsquo;ai commenc&eacute; ce m&eacute;tier en 2005, je blogais beaucoup, je faisais &eacute;norm&eacute;ment de veille. Je &ldquo;veillais&rdquo; jusqu&rsquo;&agrave; 4/5 heures par jour &agrave; ce moment-l&agrave;. Puis ma fille est arriv&eacute;e en 2007, et tout &agrave; chang&eacute;. La charge de travail a aussi consid&eacute;rablement augment&eacute;, me laissant peu de temps pour me tenir au courant chaque jour.</p>\n<p>Jusqu&rsquo;&agrave; il y a peu, ma veille &eacute;tait tr&egrave;s simple. Elle se limitait &agrave; Google Reader et &agrave; <a rel="nofollow" target="_blank" href="https://twitter.com/Fran6/">Twitter</a>. Un grand classique. J&rsquo;ai fait le tri dans mes flux RSS mais sans parvenir &agrave; tout lire r&eacute;guli&egrave;rement. Je me retrouvais donc avec plus de 1000 &eacute;l&eacute;ments &agrave; lire par moment et au final des articles datant de trop longtemps, sans oublier parfois le fait que je les avais d&eacute;j&agrave; vu passer sur Twitter.</p>\n<p>J&rsquo;ai donc laiss&eacute; de c&ocirc;t&eacute; les flux RSS et ai d&eacute;cid&eacute; de concentrer ma veille <a rel="nofollow" target="_blank" href="https://twitter.com/Fran6/">sur Twitter</a>. Je suis 500 personnes environ et j&rsquo;ai d&eacute;j&agrave; l&rsquo;impression que c&rsquo;est trop. Aur&eacute;lien, dans son article, parle de veille passive et active. La veille sur Twitter est un m&eacute;lange des deux pour moi. Elle est active parce que je suis l&agrave; pour &ccedil;a mais aussi passive parce que je lis globalement ce qui se dit sans pour autant faire vraiment de la veille. J&rsquo;esp&egrave;re que je me fais bien comprendre ! <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_biggrin.gif" alt=":D" class="wp-smiley"></p>\n<p>Mais l&agrave; encore, je ne suis pas toujours dispo, donc je loupe pas mal de choses int&eacute;ressantes aussi sur Twitter. L&rsquo;info y file &agrave; une vitesse grand V.</p>\n<p><strong>L&rsquo;iPad, compagnon id&eacute;al pour la veille</strong></p>\n<p>Tout a commenc&eacute; &agrave; changer quand je me suis achet&eacute; un iPad. Je lis &eacute;norm&eacute;ment de livres mais tr&egrave;s peu sur ordinateur. Du coup, la tablette &eacute;tait le bon compromis pour faire de la veille sans pour autant &ecirc;tre bloqu&eacute; derri&egrave;re mon bureau. J&rsquo;avais Twitter en poche, puis j&rsquo;ai adopt&eacute; <a rel="nofollow" target="_blank" href="http://www.instapaper.com/">Instapaper</a>. Super outil pour bookmarker des articles et les lire plus tard. <strong>A condition de les lire plus tard</strong>. J&rsquo;ai accumul&eacute;, tout comme je faisais auparavant avec mes flux RSS et je n&rsquo;arrivais pas &agrave; m&rsquo;en sortir. J&rsquo;ai donc &ldquo;ressorti&rdquo; aussi mes flux RSS en nettoyant bien la liste des sites que je suivais pour me concentrer sur le principal: A list Apart, Smashing Magazine, quelques sites d&rsquo;UX, beaucoup de typo et puis basta. J&rsquo;ai donc utilis&eacute; <a rel="nofollow" target="_blank" href="http://reederapp.com/">Reeder</a>, comme pas mal de monde sur OSX ou iOS, mais l&rsquo;exp&eacute;rience utilisateur pour moi s&rsquo;est av&eacute;r&eacute;e pas terrible. Je trouve que Reeder est tr&egrave;s chouette au niveau style mais n&rsquo;apporte pas vraiment grand chose de plus que Google Reader comme exp&eacute;rience. Ca reste un lecteur plut&ocirc;t classique de flux RSS.</p>\n<p>J&rsquo;ai donc test&eacute; <a rel="nofollow" target="_blank" href="http://flipboard.com/">Flipboard</a>. Super interface, on peut y ajouter nos flux RSS. Pr&eacute;sentation magazine, c&rsquo;&eacute;tait g&eacute;nial. J&rsquo;en ai profit&eacute; pour utiliser l&rsquo;application pour d&rsquo;autres sites que mes flux RSS. J&rsquo;y ai m&ecirc;me install&eacute; Twitter pour tout faire au m&ecirc;me endroit. Super exp&eacute;rience mais un souci. Flipboard ne marque pas tr&egrave;s bien les articles lus sur Google Reader. C&rsquo;est un peu p&eacute;nible &agrave; g&eacute;rer. Si on trouve des articles qui nous int&eacute;ressent pas, il faut quand m&ecirc;me les ouvrir pour les &ldquo;marquer comme lu&rdquo;.</p>\n<p>Puis sont apparus trois outils qui ont consid&eacute;rablement chang&eacute; ma mani&egrave;re de faire de la veille.</p>\n<p><strong>1. Zite</strong></p>\n<p><img class="aligncenter size-medium wp-image-1920" title="ipad" src="http://www.fran6art.com/wp-content/uploads/2012/10/ipad-470x396.png" alt="" width="470" height="396"></p>\n<p><a rel="nofollow" target="_blank" href="http://zite.com/">Zite</a> est une application qui vous propose toutes une s&eacute;ries d&rsquo;articles, selon ce qui vous int&eacute;resse. En gros et pour faire simple, vous commencez avec une s&eacute;rie d&rsquo;articles, propos&eacute;s un peu &agrave; la mani&egrave;re de Flipboard et &agrave; chaque fois vous avez la possibilit&eacute; de dire si vous avez aim&eacute; l&rsquo;article ou pas, et l&rsquo;application vous proposera plus d&rsquo;articles que vous aimez. Plus vous allez lire, plus les articles propos&eacute;s seront proches de ce que vous voulez lire. Et pas besoin de compte Google Reader ici, les sources sont propos&eacute;es par l&rsquo;application. Donc pas de stress inutile &agrave; devoir lire &ldquo;500 &eacute;l&eacute;ments non lus&rdquo;. Les articles sont globalement de tr&egrave;s bonne qualit&eacute; et correspondent aux nouveaut&eacute;s du jour. Tr&egrave;s int&eacute;ressant quand vous avez un moment tranquille sur votre sofa, on a un peu l&rsquo;impression de lire son journal sans trop savoir sur quoi on va tomber.</p>\n<p><strong>2. Feedly</strong></p>\n<p> \n</p>\n<p><a rel="nofollow" target="_blank" href="http://vimeo.com/49048256">The New Feedly Mobile</a> from <a rel="nofollow" target="_blank" href="http://vimeo.com/feedly">Feedly</a> on <a rel="nofollow" target="_blank" href="http://vimeo.com/">Vimeo</a>.</p>\n<p>J&rsquo;avais test&eacute; l&rsquo;application &agrave; ses d&eacute;buts mais c&rsquo;&eacute;tait trop bugg&eacute; pour moi et pas assez original par rapport &agrave; un Flipboard. Sauf que les derni&egrave;res versions se sont fortement am&eacute;lior&eacute;s et qu&rsquo;elles apportent quelques nouveaut&eacute;s qui ont chang&eacute; pas mal de choses pour moi.</p>\n<p>Pour ceux qui ne connaissent pas, Feedly est un lecteur de flux RSS, mais pas seulement, il propose maintenant des flux un peu comme Flipboard.</p>\n<p>Le souci de Feedly au d&eacute;part &eacute;tait le m&ecirc;me, justement, que pour Flipboard. Que faire quand on tombe sur une page avec des articles qu&rsquo;on n&rsquo;a pas trop envie de lire ? Il faut les ouvrir un par un pour les marquer comme lu. Relou. Avec la derni&egrave;re version de Feedly, un swipe vers le bas sur la page marque les articles comme lus. Tip top et super simple. Je lis quelques blogs Apple ou encore The Verge et chez certains la quantit&eacute; d&rsquo;articles r&eacute;dig&eacute;s par jour est &eacute;norme et seulement une partie m&rsquo;int&eacute;resse. Avec Reeder, j&rsquo;aurais vir&eacute; le flux parce que &ccedil;a aurait rapidement &eacute;t&eacute; impossible &agrave; g&eacute;rer ou j&rsquo;aurais tout marqu&eacute; comme lu. Avec Feedly, je parcoure les pages rapidement sur mon iPad, je swipe vers le bas pour marquer comme lu chaque page et je lis ce qui m&rsquo;int&eacute;resse. Ca peut para&icirc;tre con mais j&rsquo;ai retrouv&eacute; le plaisir de lire mes flux RSS de mani&egrave;re simple et intuitive gr&acirc;ce &agrave; une tr&egrave;s belle mise en page magazine. J&rsquo;en profite aussi pour bookmarker certains articles sur <a rel="nofollow" target="_blank" href="http://http://getpocket.com">Pocket</a> ( qui a remplac&eacute; Instapaper chez moi&hellip;) m&ecirc;me si comme expliqu&eacute; plus haut, je bookmarke plus que je lis.</p>\n<p>En fait, le souci de ces outils comme Pocket, Instapaper ou m&ecirc;me Google Reader, c&rsquo;est que la plupart du temps, il est publi&eacute; plus d&rsquo;articles qu&rsquo;on ne peut en lire. Donc c&rsquo;est vou&eacute; &agrave; l&rsquo;&eacute;chec d&rsquo;une certaine mani&egrave;re, sauf si on a du temps&hellip;</p>\n<p><strong>3. Pinterest</strong></p>\n<p><img class="aligncenter size-medium wp-image-1921" title="Pinterest-application-ipad-android" src="http://www.fran6art.com/wp-content/uploads/2012/10/Pinterest-application-ipad-android-470x310.jpg" alt="" width="470" height="310"></p>\n<p>Pendant un moment j&rsquo;ai utilis&eacute; <a rel="nofollow" target="_blank" href="https://gimmebar.com/">Gimme Bar</a> comme Aur&eacute;lien pour toute une veille graphique: sites web, UX, illustration, photo et typo. Mais j&rsquo;ai quelques soucis avec l&rsquo;interface et pour bookmarker des sites web, j&rsquo;utilise Little Snapper, malgr&eacute; que ce soit loin d&rsquo;&ecirc;tre parfait. Gimme Bar a pourtant sorti une application iPhone mais elle n&rsquo;est m&ecirc;me pas finalis&eacute;, certaines fonctions affichent m&ecirc;me un message &ldquo;Coming soon&rdquo;. Super.</p>\n<p>Et il y a quelques semaines, je d&eacute;cide de rouvrir <a rel="nofollow" target="_blank" href="http://pinterest.com/fran6/">mon compte Pinterest</a> et d&rsquo;aller &agrave; la p&ecirc;che aux id&eacute;es. Et l&agrave;, je suis surpris par la qualit&eacute; des &eacute;l&eacute;ments partag&eacute;s. C&rsquo;est clair que si vous y recherchez des exemples de sites web, vous allez &ecirc;tre d&eacute;&ccedil;us. Il y en a mais pas des masses. Par contre, pour toute autre inspiration, je trouve le site g&eacute;nial.</p>\n<p>D&eacute;j&agrave; il y a une communaut&eacute; impressionnante. Difficile m&ecirc;me parfois de suivre plus de 100 personnes tellement certaines proposent de nouvelles choses constamment. Les &eacute;l&eacute;ments que je pr&eacute;f&egrave;re sont bien entendu <a rel="nofollow" target="_blank" href="http://pinterest.com/fran6/typography/">la typographie</a>. Je n&rsquo;ai encore trouv&eacute; nulle part ailleurs autant de choses de qualit&eacute; et aussi diversifi&eacute;es. Vraiment sympa. Pas mal d&rsquo;inspiration au niveau d&eacute;co d&rsquo;int&eacute;rieur, print, illustration &eacute;galement. Personnellement, j&rsquo;aime aussi aller chercher parfois mon inspiration dans des domaines qui sont plus annexes &agrave; mon activit&eacute;. Et l&agrave; j&rsquo;y trouve mon compte.</p>\n<p>Un gros plus de Pinterest c&rsquo;est aussi ses applications iPhone et iPad. O&ugrave; que je sois, je peux acc&eacute;der &agrave; ce que j&rsquo;ai bookmark&eacute;. Et tout comme Zite par exemple, ici pas de chiffre d&rsquo;&eacute;l&eacute;ments non lus. On surfe sur une page, on peut naviguer aussi selon des cat&eacute;gories. Encore une super veille &agrave; faire sur son sofa en soir&eacute;e ! <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_wink.gif" alt=";-)" class="wp-smiley"></p>\n<p>Enfin, c&rsquo;est aussi un r&eacute;seau social donc vous pouvez suivre vos amis ou vos designers pr&eacute;f&eacute;r&eacute;s.</p>\n<p>Donc, vous l&rsquo;aurez s&ucirc;rement compris, je fais maintenant principalement ma veille sur tablette et quasiment plus sur mon ordinateur. Je suis aussi plus disponible pour faire cette veille via la tablette. Sur l&rsquo;ordi, je ne consulte que Twitter au final, sur lequel je retweete pas mal de choses que je d&eacute;couvre. Le reste se fait le matin apr&egrave;s le petit dej ou le soir apr&egrave;s le travail. Je consulte rapidement Zite, puis Pinterest et d&eacute;roule mes flux RSS. Et si j&rsquo;ai le temps je lis quelques articles bookmark&eacute;s sur Pocket. C&rsquo;est tout, mais c&rsquo;est d&eacute;j&agrave; pas mal, vu le temps qui m&rsquo;est donn&eacute;. Je dois avouer que l&rsquo;iPad joue un r&ocirc;le important ici. Sans lui je ne ferai probablement plus beaucoup de veille. A noter aussi que toujours gr&acirc;ce &agrave; ma tablette, je suis plus productif dans la journ&eacute;e car je ne fais pas vraiment de veille, hormis un peu Twitter.</p>\n<p>Voici donc ma m&eacute;thode pour suivre l&rsquo;actu web. Largement moins d&rsquo;outils et de services qu&rsquo;Aur&eacute;lien mais plut&ocirc;t un retour d&rsquo;exp&eacute;rience comme j&rsquo;aime les faire. Je ne dis pas non plus que c&rsquo;est la mani&egrave;re id&eacute;ale de faire de la veille mais c&rsquo;est celle qui me correspond le mieux, avec le temps qui m&rsquo;est donn&eacute; <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_smile.gif" alt=":)" class="wp-smiley"></p>\n<p>N&rsquo;h&eacute;sitez pas &agrave; partager vos m&eacute;thodes pour faire de la veille, que ce soit en commentaire ou, comme j&rsquo;ai pu le faire apr&egrave;s la lecture de l&rsquo;article d&rsquo;Aur&eacute;lien, sur votre blog, si vous en avez un ! <img src="http://www.fran6art.com/wp-includes/images/smilies/icon_smile.gif" alt=":)" class="wp-smiley"></p>\n<div class="feedflare">\n<a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/Fran6artLeBlog?a=SqxjR5rCujU:k3kXTXqFDpU:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/Fran6artLeBlog?i=SqxjR5rCujU:k3kXTXqFDpU:D7DqB2pKExk" border="0"></a> <a rel="nofollow" target="_blank" href="http://feeds.feedburner.com/~ff/Fran6artLeBlog?a=SqxjR5rCujU:k3kXTXqFDpU:guobEISWfyQ"><img src="http://feeds.feedburner.com/~ff/Fran6artLeBlog?i=SqxjR5rCujU:k3kXTXqFDpU:guobEISWfyQ" border="0"></a>\n</div>\n<img src="http://feeds.feedburner.com/~r/Fran6artLeBlog/~4/SqxjR5rCujU" height="1" width="1">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:68:"\n        \n        \n        \n        \n        \n        \n        \n    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Webinventif : [Wordpress] iTypo: thème WordPress gratuit";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:2:"id";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.webinventif.com/itypo/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:9:"alternate";s:4:"href";s:33:"http://www.webinventif.com/itypo/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"published";a:1:{i:0;a:5:{s:4:"data";s:25:"2011-01-01T15:36:24+00:00";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"name";a:1:{i:0;a:5:{s:4:"data";s:9:"anonymous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}s:7:"content";a:1:{i:0;a:5:{s:4:"data";s:5703:"<div>\n<p>Apr&egrave;s 1 an sans rien avoir &eacute;crit sur ce blog (bouhhhh), je fais mon retour en vous proposant un joli <strong>th&egrave;me WordPress</strong>, le 1er que je distribue publiquement et <em>gratuitement</em> &eacute;videment. D''ailleurs si les retours sont bons, &ccedil;a sera peut-&ecirc;tre le d&eacute;but d''une s&eacute;rie plus ou moins longue.</p>\n<p><strong>iTypo</strong> est donc un th&egrave;me WordPress simple et l&eacute;ger. A la base, je cherchais un th&egrave;me pour un petit projet personnel qui soit assez &eacute;pur&eacute; et l&eacute;ger pour mettre le contenu du blog en avant. Apr&egrave;s de nombreuses recherches dans la jungle des th&egrave;mes WordPress, rien ne me convenait, et comme j''avais une id&eacute;e tr&egrave;s pr&eacute;cise de ce que je voulais, j''ai fini par le faire moi-m&ecirc;me ... l''histoire classique de la naissance d''un th&egrave;me en somme <img src="http://www.webinventif.com/wp-includes/images/smilies/icon_wink.gif" alt=";)" class="wp-smiley" title="Icon Wink"></p>\n<p>Il est &eacute;videment "Widgets ready", compatible WordPress 3.0+, disponible en 4 coloris et 6 langues, convient parfaitement pour un blog perso ou un mini blog "&agrave; la Tumblr" et est absolument gratuit. <img src="http://www.webinventif.com/wp-includes/images/smilies/icon_wink.gif" alt=";)" class="wp-smiley" title="Icon Wink"></p>\n<p><img src="http://www.webinventif.com/wp-content/uploads/2011/01/pres1.png" alt="pres1" title="pres" class="aligncenter wp-image-621"></p>\n<h3>Telecharger le th&egrave;me gratuitement</h3>\n<p> iTypo est sous license GPL, vous pouvez l''utiliser gratuitement pour vos projets sans restrictions</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complete.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complete-300x740.png" alt="capture-complete-300x740" title="capture-complete" class="alignnone size-medium wp-image-610"></a></p>\n<ul>\n<li><a rel="nofollow" target="_blank" href="http://themes.webinventif.fr/">Live demo</a></li>\n<li><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complete.png">Large preview (.png, 310 Kb)</a></li>\n<li><a rel="nofollow" target="_blank" href="http://www.webinventif.com/itypo/2/">Guide d''installation et documentation</a></li>\n<li><a rel="nofollow" target="_blank" href="http://goo.gl/H7i2c">Telecharger le .zip, v1.0.2 (zip, 353 kb)</a></li>\n</ul>\n<h3>Features</h3>\n<ul>\n<li>Widget ready (footer et sidebar)</li>\n<li>Disponible par d&eacute;faut en 6 langues (et plus si n&eacute;cessaire)</li>\n<li>4 coloris diff&eacute;rents</li>\n<li>Facile &agrave; personnaliser avec sa page d''options</li>\n<li>Choix de miniatures carr&eacute; ou large sur la page d''accueil</li>\n<li>Choix d''afficher un extrait ou le post complet sur la home</li>\n<li>WordPress Post Thumbnail activ&eacute;</li>\n<li>Shortcode pour miniature</li>\n<li>JQuery Colorbox Lightbox (d&eacute;sactivable via la page d''options)</li>\n<li>"Sticky post" skinn&eacute;</li>\n<li>Commentaires en "thread" (discussion)</li>\n<li>Mise en avant de l''auteur</li>\n<li>Logo personnalisable (upload d''image)</li>\n<li>Compatible Feedburner</li>\n<li>WP-pagenavi ready</li>\n<li>Et encore plein de petites choses ...</li>\n</ul>\n<h3>Captures</h3>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/commentaires.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/commentaires-300x894.png" alt="commentaires-300x894" title="commentaires" class="alignnone size-medium wp-image-615"></a><br>\n(Commentaires)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/avec-thumb-wide.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/avec-thumb-wide-300x823.png" alt="avec-thumb-wide-300x823" title="avec-thumb-wide" class="alignnone size-medium wp-image-609"></a><br>\n(Avec miniatures larges)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complet-fullpost.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/capture-complet-fullpost-300x1932.png" alt="capture-complet-fullpost-300x1932" title="capture-complet-fullpost" class="alignnone size-medium wp-image-614"></a><br>\n(Accueil avec les billets complets)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/options-page.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/options-page-300x192.png" alt="options-page-300x192" title="options-page" class="alignnone size-medium wp-image-618"></a><br>\n(Page d''options)</p>\n<p><a rel="nofollow" target="_blank" href="http://www.webinventif.com/wp-content/uploads/2011/01/upload-logo.png"><img src="http://www.webinventif.com/wp-content/uploads/2011/01/upload-logo-300x202.png" alt="upload-logo-300x202" title="upload-logo" class="alignnone size-medium wp-image-619"></a><br>\n(Page d''upload de logo)</p>\n<p>A noter que m&ecirc;me si il fonctionne sous IE6 et sup&eacute;rieur, certains effets CSS3 ne seront pas pris en charge (typographie personnalis&eacute;e, ombres, inclinaisons, ...)</p>\n<p>Voil&agrave;, en esp&eacute;rant qu''il plaira &agrave; certains d''entre vous ! Comme je le distribue gratuitement, il serait fairplay de laisser les cr&eacute;dits du footer <img src="http://www.webinventif.com/wp-includes/images/smilies/icon_wink.gif" alt=";)" class="wp-smiley" title="Icon Wink"></p>\n<img src="http://www.webinventif.com/wp-content/plugins/mycompteur/compte.php?idpage=608" width="0" height="0" alt="" title="">\n</div>";s:7:"attribs";a:1:{s:0:"";a:1:{s:4:"type";s:4:"html";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:26:"wordpressfrancophoneplanet";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}s:4:"type";i:512;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"gbaMeLcZjqmrf5XVXfTH+B0YFqQ";s:13:"last-modified";s:29:"Thu, 07 Nov 2013 15:48:35 GMT";s:4:"date";s:29:"Thu, 07 Nov 2013 16:11:24 GMT";s:7:"expires";s:29:"Thu, 07 Nov 2013 16:11:24 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20111015034325";}', 'no');
INSERT INTO `wp_options` VALUES (3067, '_transient_timeout_feed_mod_2fb9572e3d6a42f680e36370936a57ae', '1383883884', 'no');
INSERT INTO `wp_options` VALUES (3068, '_transient_feed_mod_2fb9572e3d6a42f680e36370936a57ae', '1383840684', 'no');
INSERT INTO `wp_options` VALUES (3070, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1383883884', 'no');
INSERT INTO `wp_options` VALUES (3071, '_transient_timeout_dash_aa95765b5cc111c56d5993d476b1c2f0', '1383883884', 'no');
INSERT INTO `wp_options` VALUES (3072, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=''rsswidget'' href=''http://www.echodesplugins.li-an.fr/plugins/multi-column-tag-map/'' title=''Une présentation alphabétique de vos archives de mots-clef [&hellip;]''>L&#039;écho des plugins WordPress : Multi Column Tag Map</a> <span class="rss-date">6 novembre 2013</span><div class=''rssSummary''>Une présentation alphabétique de vos archives de mots-clef [&hellip;]</div></li><li><a class=''rsswidget'' href=''http://feedproxy.google.com/~r/WordpressFrancophone/~3/g_h34lO6c00/'' title=''Le 17 janvier prochain (2014) se tiendra le deuxième WordCamp Paris. On espère que ça sera pour autant de gens que possible l’occasion de se retrouver pour échanger, apprendre et… s’amuser autour de WordPress. Un WordCamp, c’est avant tout des conférences sur  WordPress. Mais de quoi y parle-t-on exactement ? Vous voulez quelques exemples ? C’est parti ! De  [&hellip;]''>WordPress Francophone : WordCamp Paris 2014 : et si vous étiez orateur ?</a> <span class="rss-date">5 novembre 2013</span><div class=''rssSummary''>Le 17 janvier prochain (2014) se tiendra le deuxième WordCamp Paris. On espère que ça sera pour autant de gens que possible l’occasion de se retrouver pour échanger, apprendre et… s’amuser autour de WordPress. Un WordCamp, c’est avant tout des conférences sur  WordPress. Mais de quoi y parle-t-on exactement ? Vous voulez quelques exemples ? C’est parti ! De  [&hellip;]</div></li></ul></div>', 'no');
INSERT INTO `wp_options` VALUES (3073, '_transient_dash_aa95765b5cc111c56d5993d476b1c2f0', '<div class="rss-widget"><ul><li><a class=''rsswidget'' href=''http://www.echodesplugins.li-an.fr/plugins/multi-column-tag-map/'' title=''Une présentation alphabétique de vos archives de mots-clef [&hellip;]''>L&#039;écho des plugins WordPress : Multi Column Tag Map</a></li><li><a class=''rsswidget'' href=''http://feedproxy.google.com/~r/WordpressFrancophone/~3/g_h34lO6c00/'' title=''Le 17 janvier prochain (2014) se tiendra le deuxième WordCamp Paris. On espère que ça sera pour autant de gens que possible l’occasion de se retrouver pour échanger, apprendre et… s’amuser autour de WordPress. Un WordCamp, c’est avant tout des conférences sur  WordPress. Mais de quoi y parle-t-on exactement ? Vous voulez quelques exemples ? C’est parti ! De  [&hellip;]''>WordPress Francophone : WordCamp Paris 2014 : et si vous étiez orateur ?</a></li><li><a class=''rsswidget'' href=''http://wpformation.com/icones-wordpress-plugin/'' title=''Les icônes c&#039;est bien, c&#039;est visuel, c&#039;est beau, ça attire l&#039;attention et ça incite au clic ! 1000 icônes HD pour WordPress Une moyen simple et rapide pour ajouter des icônes pour WordPress. Vector Icons est une nouvelle façon d&#039;utiliser les icônes sur votre site. Plus besoin de personnaliser les fichiers image ou psd, maintenant tou [&hellip;]''>WP Formation : 1000 icônes pour votre WordPress</a></li><li><a class=''rsswidget'' href=''http://www.geekpress.fr/wordpress/guide/themes-hotel-attractif-1940/'' title=''Si vous voulez en mettre plein la vue à vos clients ou à un potentiel invité, voici une sélection de 9 thèmes WordPress pour hôtel. [&hellip;]''>GeekPress : 9 thèmes WordPress pour rendre votre hôtel attractif</a></li><li><a class=''rsswidget'' href=''http://wpchannel.com/jquery-sidebar-flottante-wordpress/'' title=''Il arrive parfois que le contenu d’une page soit long et que votre molette de souris chauffe à force de faire des allez-retours pour pouvoir accéder aux éléments de la sidebar. Une manipulation très simple vous permet en CSS de fixer cette sidebar afin qu’elle soit toujours visible à l’écran. Mais ce n’est pas suffisamment […]Christopher Hennuyez - WordPress [&hellip;]''>WordPress Channel : jQuery &amp; WordPress &ndash; Une sidebar flottante</a></li></ul></div>', 'no');
INSERT INTO `wp_options` VALUES (3246, '_site_transient_timeout_theme_roots', '1387469205', 'yes');
INSERT INTO `wp_options` VALUES (3247, '_site_transient_theme_roots', 'a:2:{s:15:"northern-clouds";s:7:"/themes";s:9:"twentyten";s:7:"/themes";}', 'yes');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_pageflip`
-- 

CREATE TABLE `wp_pageflip` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `date` bigint(11) NOT NULL DEFAULT '1367279457',
  `bgImage` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Contenu de la table `wp_pageflip`
-- 

INSERT INTO `wp_pageflip` VALUES (1, 'Accueil', 1367279796, 0);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_pageflip_gallery`
-- 

CREATE TABLE `wp_pageflip_gallery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `date` bigint(11) NOT NULL DEFAULT '1367279457',
  `preview` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Contenu de la table `wp_pageflip_gallery`
-- 

INSERT INTO `wp_pageflip_gallery` VALUES (1, 'Accueil', 1367279611, 0);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_pageflip_img`
-- 

CREATE TABLE `wp_pageflip_img` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `filename` text NOT NULL,
  `date` bigint(11) NOT NULL DEFAULT '1367279457',
  `type` varchar(10) NOT NULL DEFAULT 'img',
  `gallery` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Contenu de la table `wp_pageflip_img`
-- 

INSERT INTO `wp_pageflip_img` VALUES (1, 'dl.jpg', 'i_zea3I0.jpg', 1367279683, 'img', 1);
INSERT INTO `wp_pageflip_img` VALUES (2, 'logoM2IMbis.png', 'i_tXssTqaY702t.png', 1367279683, 'img', 1);
INSERT INTO `wp_pageflip_img` VALUES (3, 'master-ihm.gif', 'i_SbjymJ9.gif', 1367279683, 'img', 1);
INSERT INTO `wp_pageflip_img` VALUES (4, 'ups.jpg', 'i_nvyNAzE0.jpg', 1367279684, 'img', 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_postmeta`
-- 

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=471 DEFAULT CHARSET=utf8 AUTO_INCREMENT=471 ;

-- 
-- Contenu de la table `wp_postmeta`
-- 

INSERT INTO `wp_postmeta` VALUES (2, 4, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (3, 4, '_edit_lock', '1365630434:1');
INSERT INTO `wp_postmeta` VALUES (6, 14, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (7, 14, '_edit_lock', '1367870359:1');
INSERT INTO `wp_postmeta` VALUES (8, 22, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (9, 22, '_edit_lock', '1367233647:1');
INSERT INTO `wp_postmeta` VALUES (10, 25, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (11, 25, '_edit_lock', '1364405298:1');
INSERT INTO `wp_postmeta` VALUES (14, 29, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (15, 29, '_edit_lock', '1367239183:1');
INSERT INTO `wp_postmeta` VALUES (16, 31, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (17, 31, '_edit_lock', '1367276397:1');
INSERT INTO `wp_postmeta` VALUES (18, 33, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (19, 33, '_edit_lock', '1366825336:1');
INSERT INTO `wp_postmeta` VALUES (20, 35, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (21, 35, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (22, 35, '_menu_item_object_id', '33');
INSERT INTO `wp_postmeta` VALUES (23, 35, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (24, 35, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (25, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (26, 35, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (27, 35, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (29, 36, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (30, 36, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (31, 36, '_menu_item_object_id', '22');
INSERT INTO `wp_postmeta` VALUES (32, 36, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (33, 36, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (34, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (35, 36, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (36, 36, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (47, 38, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (48, 38, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (49, 38, '_menu_item_object_id', '29');
INSERT INTO `wp_postmeta` VALUES (50, 38, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (51, 38, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (52, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (53, 38, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (54, 38, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (56, 39, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (57, 39, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (58, 39, '_menu_item_object_id', '25');
INSERT INTO `wp_postmeta` VALUES (59, 39, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (60, 39, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (61, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (62, 39, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (63, 39, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (65, 40, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (66, 40, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (67, 40, '_menu_item_object_id', '14');
INSERT INTO `wp_postmeta` VALUES (68, 40, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (69, 40, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (70, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (71, 40, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (72, 40, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (74, 41, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (75, 41, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (76, 41, '_menu_item_object_id', '31');
INSERT INTO `wp_postmeta` VALUES (77, 41, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (78, 41, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (79, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (80, 41, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (81, 41, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (83, 42, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (84, 42, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (85, 42, '_menu_item_object_id', '4');
INSERT INTO `wp_postmeta` VALUES (86, 42, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (87, 42, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (88, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (89, 42, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (90, 42, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (101, 33, '_wp_page_template', 'choisir_template.php');
INSERT INTO `wp_postmeta` VALUES (102, 22, '_wp_page_template', 'Codes/jTableSimplePagedSorted.php');
INSERT INTO `wp_postmeta` VALUES (104, 29, '_wp_page_template', 'default');
INSERT INTO `wp_postmeta` VALUES (105, 25, '_wp_page_template', 'default');
INSERT INTO `wp_postmeta` VALUES (106, 14, '_wp_page_template', 'default');
INSERT INTO `wp_postmeta` VALUES (107, 31, '_wp_page_template', 'default');
INSERT INTO `wp_postmeta` VALUES (108, 4, '_wp_page_template', 'listeEtu.php');
INSERT INTO `wp_postmeta` VALUES (110, 1, '_edit_lock', '1368922592:1');
INSERT INTO `wp_postmeta` VALUES (111, 1, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (136, 67, '_edit_lock', '1364260742:1');
INSERT INTO `wp_postmeta` VALUES (187, 67, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (188, 67, '_wp_page_template', 'default');
INSERT INTO `wp_postmeta` VALUES (189, 100, '_wp_page_template', 'default');
INSERT INTO `wp_postmeta` VALUES (190, 100, '_edit_lock', '1380285279:1');
INSERT INTO `wp_postmeta` VALUES (193, 100, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (194, 103, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (195, 103, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (196, 103, '_menu_item_object_id', '100');
INSERT INTO `wp_postmeta` VALUES (197, 103, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (198, 103, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (199, 103, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (200, 103, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (201, 103, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (205, 115, '_dedo_file_url', 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/delightful-downloads/2013/03/ScolariteClient-step-client-etu-eval.zip');
INSERT INTO `wp_postmeta` VALUES (206, 115, '_dedo_file_size', '6484');
INSERT INTO `wp_postmeta` VALUES (207, 115, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (208, 115, '_dedo_file_count', '0');
INSERT INTO `wp_postmeta` VALUES (209, 115, '_edit_lock', '1363531273:1');
INSERT INTO `wp_postmeta` VALUES (228, 142, '_menu_item_type', 'custom');
INSERT INTO `wp_postmeta` VALUES (229, 142, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (230, 142, '_menu_item_object_id', '142');
INSERT INTO `wp_postmeta` VALUES (231, 142, '_menu_item_object', 'custom');
INSERT INTO `wp_postmeta` VALUES (232, 142, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (233, 142, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (234, 142, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (235, 142, '_menu_item_url', 'http://www.gdnlteamtest.netsoro.net/wordpress/');
INSERT INTO `wp_postmeta` VALUES (241, 222, '_wp_attached_file', '2013/03/campus2.jpg');
INSERT INTO `wp_postmeta` VALUES (242, 222, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"437";s:6:"height";s:3:"290";s:14:"hwstring_small";s:23:"height=''84'' width=''128''";s:4:"file";s:19:"2013/03/campus2.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:3:{s:4:"file";s:19:"campus2-150x150.jpg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:6:"medium";a:3:{s:4:"file";s:19:"campus2-300x199.jpg";s:5:"width";s:3:"300";s:6:"height";s:3:"199";}s:14:"post-thumbnail";a:3:{s:4:"file";s:19:"campus2-437x198.jpg";s:5:"width";s:3:"437";s:6:"height";s:3:"198";}}s:10:"image_meta";a:10:{s:8:"aperture";s:2:"11";s:6:"credit";s:0:"";s:6:"camera";s:9:"NIKON D70";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1173974469";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"18";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (246, 236, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (247, 236, '_edit_lock', '1366824894:1');
INSERT INTO `wp_postmeta` VALUES (248, 236, '_wp_page_template', 'sendmsgetuseul.php');
INSERT INTO `wp_postmeta` VALUES (259, 258, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (260, 258, '_edit_lock', '1366824989:1');
INSERT INTO `wp_postmeta` VALUES (261, 258, '_wp_page_template', 'msgAllEtu.php');
INSERT INTO `wp_postmeta` VALUES (262, 260, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (263, 260, '_edit_lock', '1366825011:1');
INSERT INTO `wp_postmeta` VALUES (264, 260, '_wp_page_template', 'msgEncadrant.php');
INSERT INTO `wp_postmeta` VALUES (265, 266, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (266, 266, '_menu_item_menu_item_parent', '38');
INSERT INTO `wp_postmeta` VALUES (267, 266, '_menu_item_object_id', '236');
INSERT INTO `wp_postmeta` VALUES (268, 266, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (269, 266, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (270, 266, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (271, 266, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (272, 266, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (274, 267, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (275, 267, '_menu_item_menu_item_parent', '38');
INSERT INTO `wp_postmeta` VALUES (276, 267, '_menu_item_object_id', '258');
INSERT INTO `wp_postmeta` VALUES (277, 267, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (278, 267, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (279, 267, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (280, 267, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (281, 267, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (283, 268, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (284, 268, '_menu_item_menu_item_parent', '38');
INSERT INTO `wp_postmeta` VALUES (285, 268, '_menu_item_object_id', '260');
INSERT INTO `wp_postmeta` VALUES (286, 268, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (287, 268, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (288, 268, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (289, 268, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (290, 268, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (343, 281, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (344, 281, '_edit_lock', '1366824964:1');
INSERT INTO `wp_postmeta` VALUES (345, 281, '_wp_page_template', 'EtuEncMsgRespUE.php');
INSERT INTO `wp_postmeta` VALUES (346, 283, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (347, 283, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (348, 283, '_menu_item_object_id', '281');
INSERT INTO `wp_postmeta` VALUES (349, 283, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (350, 283, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (351, 283, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (352, 283, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (353, 283, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (357, 293, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (358, 293, '_edit_lock', '1367277784:1');
INSERT INTO `wp_postmeta` VALUES (359, 293, '_wp_page_template', 'default');
INSERT INTO `wp_postmeta` VALUES (360, 296, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (361, 296, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (362, 296, '_menu_item_object_id', '293');
INSERT INTO `wp_postmeta` VALUES (363, 296, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (364, 296, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (365, 296, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (366, 296, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (367, 296, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (375, 301, '_wp_attached_file', '2013/03/gerer-user.jpg');
INSERT INTO `wp_postmeta` VALUES (376, 301, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"259";s:6:"height";s:3:"194";s:14:"hwstring_small";s:23:"height=''96'' width=''128''";s:4:"file";s:22:"2013/03/gerer-user.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:3:{s:4:"file";s:22:"gerer-user-150x150.jpg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (386, 312, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (387, 312, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (388, 312, '_menu_item_object_id', '67');
INSERT INTO `wp_postmeta` VALUES (389, 312, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (390, 312, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (391, 312, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (392, 312, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (393, 312, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (395, 316, '_wp_attached_file', '2013/03/msg1.jpg');
INSERT INTO `wp_postmeta` VALUES (396, 316, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"222";s:6:"height";s:3:"227";s:14:"hwstring_small";s:22:"height=''96'' width=''93''";s:4:"file";s:16:"2013/03/msg1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:3:{s:4:"file";s:16:"msg1-150x150.jpg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:14:"post-thumbnail";a:3:{s:4:"file";s:16:"msg1-222x198.jpg";s:5:"width";s:3:"222";s:6:"height";s:3:"198";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (397, 317, '_wp_attached_file', '2013/03/msg2.jpg');
INSERT INTO `wp_postmeta` VALUES (398, 317, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"200";s:6:"height";s:3:"200";s:14:"hwstring_small";s:22:"height=''96'' width=''96''";s:4:"file";s:16:"2013/03/msg2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:3:{s:4:"file";s:16:"msg2-150x150.jpg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:14:"post-thumbnail";a:3:{s:4:"file";s:16:"msg2-200x198.jpg";s:5:"width";s:3:"200";s:6:"height";s:3:"198";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (399, 33, '_members_access_role', 'encadrant');
INSERT INTO `wp_postmeta` VALUES (400, 22, '_members_access_role', 'encadrant');
INSERT INTO `wp_postmeta` VALUES (401, 331, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (402, 331, '_edit_lock', '1366825048:1');
INSERT INTO `wp_postmeta` VALUES (408, 331, '_wp_page_template', 'msgAunEtu.php');
INSERT INTO `wp_postmeta` VALUES (409, 336, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (410, 336, '_menu_item_menu_item_parent', '38');
INSERT INTO `wp_postmeta` VALUES (411, 336, '_menu_item_object_id', '331');
INSERT INTO `wp_postmeta` VALUES (412, 336, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (413, 336, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (414, 336, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (415, 336, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (416, 336, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (420, 339, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (421, 339, '_edit_lock', '1366824856:1');
INSERT INTO `wp_postmeta` VALUES (422, 339, '_wp_page_template', 'calculChargeEnc.php');
INSERT INTO `wp_postmeta` VALUES (423, 341, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (424, 341, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (425, 341, '_menu_item_object_id', '339');
INSERT INTO `wp_postmeta` VALUES (426, 341, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (427, 341, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (428, 341, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (429, 341, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (430, 341, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (431, 345, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (432, 345, '_edit_lock', '1367229924:1');
INSERT INTO `wp_postmeta` VALUES (433, 345, '_wp_page_template', 'Codes/jTableGroup.php');
INSERT INTO `wp_postmeta` VALUES (435, 347, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` VALUES (436, 347, '_menu_item_menu_item_parent', '0');
INSERT INTO `wp_postmeta` VALUES (437, 347, '_menu_item_object_id', '345');
INSERT INTO `wp_postmeta` VALUES (438, 347, '_menu_item_object', 'page');
INSERT INTO `wp_postmeta` VALUES (439, 347, '_menu_item_target', '');
INSERT INTO `wp_postmeta` VALUES (440, 347, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (441, 347, '_menu_item_xfn', '');
INSERT INTO `wp_postmeta` VALUES (442, 347, '_menu_item_url', '');
INSERT INTO `wp_postmeta` VALUES (445, 364, '_edit_last', '1');
INSERT INTO `wp_postmeta` VALUES (446, 364, '_edit_lock', '1367236982:1');
INSERT INTO `wp_postmeta` VALUES (447, 364, '_wp_page_template', 'sendAllGroup_template.php');
INSERT INTO `wp_postmeta` VALUES (448, 293, '_members_access_role', 'responsableue');
INSERT INTO `wp_postmeta` VALUES (451, 396, '_wp_attached_file', '2013/05/dl.jpg');
INSERT INTO `wp_postmeta` VALUES (452, 396, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"280";s:6:"height";s:3:"120";s:14:"hwstring_small";s:23:"height=''54'' width=''128''";s:4:"file";s:14:"2013/05/dl.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:3:{s:4:"file";s:14:"dl-150x120.jpg";s:5:"width";s:3:"150";s:6:"height";s:3:"120";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (463, 403, '_wp_attached_file', '2013/05/logo_ups_pres1.png');
INSERT INTO `wp_postmeta` VALUES (464, 403, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"280";s:6:"height";s:3:"120";s:14:"hwstring_small";s:23:"height=''54'' width=''128''";s:4:"file";s:26:"2013/05/logo_ups_pres1.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:3:{s:4:"file";s:26:"logo_ups_pres1-150x120.png";s:5:"width";s:3:"150";s:6:"height";s:3:"120";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (465, 404, '_wp_attached_file', '2013/05/logoM2IMbis.png');
INSERT INTO `wp_postmeta` VALUES (466, 404, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"280";s:6:"height";s:3:"120";s:14:"hwstring_small";s:23:"height=''54'' width=''128''";s:4:"file";s:23:"2013/05/logoM2IMbis.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:3:{s:4:"file";s:23:"logoM2IMbis-150x120.png";s:5:"width";s:3:"150";s:6:"height";s:3:"120";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (467, 405, '_wp_attached_file', '2013/05/master-ihm.gif');
INSERT INTO `wp_postmeta` VALUES (468, 405, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"280";s:6:"height";s:3:"120";s:14:"hwstring_small";s:23:"height=''54'' width=''128''";s:4:"file";s:22:"2013/05/master-ihm.gif";s:5:"sizes";a:1:{s:9:"thumbnail";a:3:{s:4:"file";s:22:"master-ihm-150x120.gif";s:5:"width";s:3:"150";s:6:"height";s:3:"120";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');
INSERT INTO `wp_postmeta` VALUES (469, 406, '_wp_attached_file', '2013/05/ups.jpg');
INSERT INTO `wp_postmeta` VALUES (470, 406, '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"280";s:6:"height";s:3:"120";s:14:"hwstring_small";s:23:"height=''54'' width=''128''";s:4:"file";s:15:"2013/05/ups.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:3:{s:4:"file";s:15:"ups-150x120.jpg";s:5:"width";s:3:"150";s:6:"height";s:3:"120";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_posts`
-- 

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=413 DEFAULT CHARSET=utf8 AUTO_INCREMENT=413 ;

-- 
-- Contenu de la table `wp_posts`
-- 

INSERT INTO `wp_posts` VALUES (1, 1, '2013-03-14 10:47:55', '2013-03-14 09:47:55', '<p style="text-align: center;"></p>\r\n\r\n<div style="background: gray; float: right; \r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\r\n\r\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>\r\n\r\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'publish', 'closed', 'closed', '', 'bonjour-tout-le-monde', '', '', '2013-05-18 21:55:46', '2013-05-18 20:55:46', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=1', 0, 'post', '', 0);
INSERT INTO `wp_posts` VALUES (4, 1, '2013-03-14 11:51:50', '2013-03-14 10:51:50', '', 'Espace Etudiants', '', 'publish', 'closed', 'closed', '', 'informations-etudiants', '', '', '2013-03-26 21:49:31', '2013-03-26 20:49:31', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=4', 1, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (5, 1, '2013-03-14 11:51:19', '2013-03-14 10:51:19', '', 'I', '', 'inherit', 'open', 'open', '', '4-revision', '', '', '2013-03-14 11:51:19', '2013-03-14 10:51:19', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=5', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (6, 1, '2013-03-14 11:51:50', '2013-03-14 10:51:50', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-2', '', '', '2013-03-14 11:51:50', '2013-03-14 10:51:50', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=6', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (14, 1, '2013-03-14 11:56:42', '2013-03-14 10:56:42', '[wp-members page="members-area"]', 'Modifier Paramètres', '', 'publish', 'closed', 'closed', '', 'modifier-parametres', '', '', '2013-03-27 19:28:46', '2013-03-27 18:28:46', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=14', 9, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (15, 1, '2013-03-14 11:56:28', '2013-03-14 10:56:28', '', 'Brouillon auto', '', 'inherit', 'open', 'open', '', '14-revision', '', '', '2013-03-14 11:56:28', '2013-03-14 10:56:28', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=15', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (16, 1, '2013-03-14 11:56:42', '2013-03-14 10:56:42', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '14-revision-2', '', '', '2013-03-14 11:56:42', '2013-03-14 10:56:42', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=16', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (17, 1, '2013-03-14 11:57:06', '2013-03-14 10:57:06', '', 'Téléchargements', '', 'inherit', 'open', 'open', '', '14-revision-3', '', '', '2013-03-14 11:57:06', '2013-03-14 10:57:06', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=17', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (18, 1, '2013-03-14 11:57:34', '2013-03-14 10:57:34', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '14-revision-4', '', '', '2013-03-14 11:57:34', '2013-03-14 10:57:34', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=18', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (19, 1, '2013-03-14 11:57:55', '2013-03-14 10:57:55', '', 'Liste des sujets', '', 'inherit', 'open', 'open', '', '14-revision-5', '', '', '2013-03-14 11:57:55', '2013-03-14 10:57:55', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=19', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (20, 1, '2013-03-14 11:58:11', '2013-03-14 10:58:11', '', 'Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-6', '', '', '2013-03-14 11:58:11', '2013-03-14 10:58:11', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=20', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (21, 1, '2013-03-14 11:58:20', '2013-03-14 10:58:20', '', 'Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-7', '', '', '2013-03-14 11:58:20', '2013-03-14 10:58:20', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=21', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (22, 1, '2013-03-14 15:51:37', '2013-03-14 14:51:37', '', 'Espace Encadrants', '', 'publish', 'closed', 'closed', '', 'informations-encadrants', '', '', '2013-04-24 18:40:09', '2013-04-24 17:40:09', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=22', 2, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (23, 1, '2013-03-14 15:51:15', '2013-03-14 14:51:15', '', 'I', '', 'inherit', 'open', 'open', '', '22-revision', '', '', '2013-03-14 15:51:15', '2013-03-14 14:51:15', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=23', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (24, 1, '2013-03-14 15:51:37', '2013-03-14 14:51:37', '', 'Infrmations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-2', '', '', '2013-03-14 15:51:37', '2013-03-14 14:51:37', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=24', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (25, 1, '2013-03-14 15:52:36', '2013-03-14 14:52:36', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php">Supprimer des utilisateurs</a></p>', 'Gestion des membres', '', 'publish', 'closed', 'closed', '', 'mises-a-jour', '', '', '2013-03-26 23:19:54', '2013-03-26 22:19:54', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=25', 6, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (26, 1, '2013-03-14 15:52:20', '2013-03-14 14:52:20', '', 'Brouillon auto', '', 'inherit', 'open', 'open', '', '25-revision', '', '', '2013-03-14 15:52:20', '2013-03-14 14:52:20', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=26', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (29, 1, '2013-03-14 15:53:22', '2013-03-14 14:53:22', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg"><img class="alignleft size-full wp-image-316" title="msg1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg" alt="" width="222" height="227" /></a><a href="/wordpress/?page_id=236"> Envoyer un message aux étudiants sans groupe</a>\r\n<a href="/wordpress/?page_id=258 ">Envoyer un message aux étudiants</a>\r\n<a href="/wordpress/?page_id=260"> Envoyer un message à un encadrant</a>\r\n<a href="/wordpress/?page_id=331 ">Envoyer un message à un étudiant</a>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg"><img class="alignright size-full wp-image-317" title="msg2" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg" alt="" width="200" height="200" /></a></p>', 'Messagerie', '', 'publish', 'closed', 'closed', '', 'messagerie', '', '', '2013-04-24 18:44:56', '2013-04-24 17:44:56', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=29', 5, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (30, 1, '2013-03-14 15:53:13', '2013-03-14 14:53:13', '', 'Brouillon auto', '', 'inherit', 'open', 'open', '', '29-revision', '', '', '2013-03-14 15:53:13', '2013-03-14 14:53:13', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=30', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (31, 1, '2013-03-14 15:54:00', '2013-03-14 14:54:00', '', 'Téléchargements', '', 'publish', 'closed', 'closed', '', 'downloads', '', '', '2013-04-29 23:59:50', '2013-04-29 22:59:50', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=31', 7, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (32, 1, '2013-03-14 15:53:42', '2013-03-14 14:53:42', '', 'Brouillon auto', '', 'inherit', 'open', 'open', '', '31-revision', '', '', '2013-03-14 15:53:42', '2013-03-14 14:53:42', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=32', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (33, 1, '2013-03-14 15:54:50', '2013-03-14 14:54:50', '', 'Choisir projet', '', 'publish', 'closed', 'closed', '', 'ajouter-un-sujet', '', '', '2013-04-24 18:43:25', '2013-04-24 17:43:25', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=33', 4, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (34, 1, '2013-03-14 15:54:23', '2013-03-14 14:54:23', '', 'Brouillon auto', '', 'inherit', 'open', 'open', '', '33-revision', '', '', '2013-03-14 15:54:23', '2013-03-14 14:54:23', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=34', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (35, 1, '2013-03-14 15:56:56', '2013-03-14 14:56:56', ' ', '', '', 'publish', 'open', 'open', '', '35', '', '', '2013-04-24 18:56:47', '2013-04-24 17:56:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=35', 4, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (36, 1, '2013-03-14 15:56:55', '2013-03-14 14:56:55', ' ', '', '', 'publish', 'open', 'open', '', '36', '', '', '2013-04-24 18:56:47', '2013-04-24 17:56:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=36', 3, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (38, 1, '2013-03-14 15:56:56', '2013-03-14 14:56:56', ' ', '', '', 'publish', 'open', 'open', '', '38', '', '', '2013-04-24 18:56:47', '2013-04-24 17:56:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=38', 5, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (39, 1, '2013-03-14 15:56:56', '2013-03-14 14:56:56', ' ', '', '', 'publish', 'open', 'open', '', '39', '', '', '2013-04-24 18:56:48', '2013-04-24 17:56:48', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=39', 10, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (40, 1, '2013-03-14 15:56:57', '2013-03-14 14:56:57', ' ', '', '', 'publish', 'open', 'open', '', '40', '', '', '2013-04-24 18:56:48', '2013-04-24 17:56:48', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=40', 13, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (41, 1, '2013-03-14 15:56:56', '2013-03-14 14:56:56', ' ', '', '', 'publish', 'open', 'open', '', '41', '', '', '2013-04-24 18:56:48', '2013-04-24 17:56:48', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=41', 12, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (42, 1, '2013-03-14 15:56:55', '2013-03-14 14:56:55', ' ', '', '', 'publish', 'open', 'open', '', '42', '', '', '2013-04-24 18:56:46', '2013-04-24 17:56:46', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=42', 2, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (44, 1, '2013-03-14 11:58:27', '2013-03-14 10:58:27', '', 'Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-8', '', '', '2013-03-14 11:58:27', '2013-03-14 10:58:27', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=44', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (45, 1, '2013-03-14 15:54:50', '2013-03-14 14:54:50', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-2', '', '', '2013-03-14 15:54:50', '2013-03-14 14:54:50', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=45', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (46, 1, '2013-03-14 15:52:08', '2013-03-14 14:52:08', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-3', '', '', '2013-03-14 15:52:08', '2013-03-14 14:52:08', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=46', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (48, 1, '2013-03-14 15:53:22', '2013-03-14 14:53:22', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-2', '', '', '2013-03-14 15:53:22', '2013-03-14 14:53:22', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=48', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (49, 1, '2013-03-14 15:52:36', '2013-03-14 14:52:36', '', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-2', '', '', '2013-03-14 15:52:36', '2013-03-14 14:52:36', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=49', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (50, 1, '2013-03-14 15:57:47', '2013-03-14 14:57:47', '', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-9', '', '', '2013-03-14 15:57:47', '2013-03-14 14:57:47', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=50', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (51, 1, '2013-03-14 15:54:00', '2013-03-14 14:54:00', '', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-2', '', '', '2013-03-14 15:54:00', '2013-03-14 14:54:00', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=51', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (52, 1, '2013-03-14 11:52:06', '2013-03-14 10:52:06', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-3', '', '', '2013-03-14 11:52:06', '2013-03-14 10:52:06', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=52', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (54, 1, '2013-05-01 22:27:02', '2013-05-01 21:27:02', '\n<p style="text-align: center;"></p>\n\n<div style="background: gray; float: right; \n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\n\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\n<p style="text-align: center;">Bon courage !</p>\n<p style="text-align: center;"></p>\n\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-autosave', '', '', '2013-05-01 22:27:02', '2013-05-01 21:27:02', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=54', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (55, 1, '2013-03-14 10:47:55', '2013-03-14 10:47:55', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous&nbsp;!', 'Bonjour tout le monde&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision', '', '', '2013-03-14 10:47:55', '2013-03-14 10:47:55', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=55', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (56, 1, '2013-03-14 16:06:46', '2013-03-14 15:06:46', 'Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités (DL, IARF, IM, IHM, CAMSI) .\r\n\r\nIdentifiez-vous et  trouvez le projet qui vous correspond.\r\n\r\nBon courage !', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-2', '', '', '2013-03-14 16:06:46', '2013-03-14 15:06:46', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=56', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (57, 1, '2013-03-14 16:07:36', '2013-03-14 15:07:36', 'Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités (<em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI</em></strong>) .\r\n\r\nIdentifiez-vous et  trouvez le projet qui vous correspond.\r\n\r\nBon courage !', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-3', '', '', '2013-03-14 16:07:36', '2013-03-14 15:07:36', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=57', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (58, 1, '2013-03-14 16:07:50', '2013-03-14 15:07:50', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités (<em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI</em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-4', '', '', '2013-03-14 16:07:50', '2013-03-14 15:07:50', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=58', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (59, 1, '2013-03-14 16:08:11', '2013-03-14 15:08:11', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">(<em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI</em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-5', '', '', '2013-03-14 16:08:11', '2013-03-14 15:08:11', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=59', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (60, 1, '2013-03-14 16:08:36', '2013-03-14 15:08:36', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-6', '', '', '2013-03-14 16:08:36', '2013-03-14 15:08:36', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=60', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (61, 1, '2013-03-14 16:12:30', '2013-03-14 15:12:30', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-7', '', '', '2013-03-14 16:12:30', '2013-03-14 15:12:30', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=61', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (66, 1, '2013-03-14 16:17:27', '2013-03-14 15:17:27', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-8', '', '', '2013-03-14 16:17:27', '2013-03-14 15:17:27', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=66', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (67, 1, '2013-03-15 15:05:15', '2013-03-15 14:05:15', '<strong><em>Vous êtes déconnecté(e)</em></strong>\r\n\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/campus2.jpg"><img class="size-full wp-image-222 alignright" title="campus2" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/campus2.jpg" alt="" width="437" height="290" /></a>', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2013-03-26 02:04:58', '2013-03-26 01:04:58', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=67', 10, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (70, 1, '2013-03-14 15:58:44', '2013-03-14 14:58:44', '', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-10', '', '', '2013-03-14 15:58:44', '2013-03-14 14:58:44', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=70', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (71, 1, '2013-03-14 15:58:33', '2013-03-14 14:58:33', '', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-3', '', '', '2013-03-14 15:58:33', '2013-03-14 14:58:33', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=71', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (72, 1, '2013-03-15 16:16:24', '2013-03-15 15:16:24', '[wpuf-edit-users]', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-4', '', '', '2013-03-15 16:16:24', '2013-03-15 15:16:24', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=72', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (73, 1, '2013-03-26 23:21:00', '2013-03-26 22:21:00', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php">Supprimer des utilisateurs</a></p>', 'Gestion des membres', '', 'inherit', 'open', 'open', '', '25-autosave', '', '', '2013-03-26 23:21:00', '2013-03-26 22:21:00', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=73', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (86, 1, '2013-03-14 15:58:02', '2013-03-14 14:58:02', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-3', '', '', '2013-03-14 15:58:02', '2013-03-14 14:58:02', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/33-revision-3', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (87, 1, '2013-03-14 15:58:11', '2013-03-14 14:58:11', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-4', '', '', '2013-03-14 15:58:11', '2013-03-14 14:58:11', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/22-revision-4', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (89, 1, '2013-03-15 15:05:15', '2013-03-15 14:05:15', '[theme-my-login]', 'Login', '', 'inherit', 'open', 'open', '', '67-revision', '', '', '2013-03-15 15:05:15', '2013-03-15 14:05:15', '', 67, 'http://www.gdnlteamtest.netsoro.net/wordpress/67-revision', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (90, 1, '2013-03-14 15:58:24', '2013-03-14 14:58:24', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-3', '', '', '2013-03-14 15:58:24', '2013-03-14 14:58:24', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/29-revision-3', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (91, 1, '2013-03-17 11:44:27', '2013-03-17 10:44:27', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-4', '', '', '2013-03-17 11:44:27', '2013-03-17 10:44:27', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/29-revision-4', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (92, 1, '2013-03-15 16:17:55', '2013-03-15 15:17:55', ' [wpuf_dashboard]', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-5', '', '', '2013-03-15 16:17:55', '2013-03-15 15:17:55', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/25-revision-5', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (93, 1, '2013-03-15 15:46:03', '2013-03-15 14:46:03', '[wpuf_editprofile]', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-11', '', '', '2013-03-15 15:46:03', '2013-03-15 14:46:03', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/14-revision-11', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (94, 1, '2013-03-17 11:46:14', '2013-03-17 10:46:14', '[wpuf_editprofile]', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-12', '', '', '2013-03-17 11:46:14', '2013-03-17 10:46:14', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/14-revision-12', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (95, 1, '2013-03-14 15:58:50', '2013-03-14 14:58:50', '', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-3', '', '', '2013-03-14 15:58:50', '2013-03-14 14:58:50', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/31-revision-3', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (97, 1, '2013-03-14 15:58:57', '2013-03-14 14:58:57', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-4', '', '', '2013-03-14 15:58:57', '2013-03-14 14:58:57', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/4-revision-4', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (98, 1, '2013-03-17 11:43:14', '2013-03-17 10:43:14', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-5', '', '', '2013-03-17 11:43:14', '2013-03-17 10:43:14', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/22-revision-5', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (99, 1, '2013-03-17 11:45:13', '2013-03-17 10:45:13', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-5', '', '', '2013-03-17 11:45:13', '2013-03-17 10:45:13', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/29-revision-5', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (100, 1, '2013-03-17 11:58:43', '2013-03-17 10:58:43', '', 'Forum', '', 'publish', 'closed', 'closed', '', 'forum-2', '', '', '2013-03-26 09:10:13', '2013-03-26 08:10:13', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=100', 8, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (102, 1, '2013-03-17 11:58:43', '2013-03-17 10:58:43', '', 'Forum', '', 'inherit', 'open', 'open', '', '100-revision', '', '', '2013-03-17 11:58:43', '2013-03-17 10:58:43', '', 100, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=102', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (103, 1, '2013-03-17 12:03:42', '2013-03-17 11:03:42', ' ', '', '', 'publish', 'open', 'open', '', '103', '', '', '2013-04-24 18:56:49', '2013-04-24 17:56:49', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=103', 14, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (105, 1, '2013-03-17 11:47:29', '2013-03-17 10:47:29', '', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-4', '', '', '2013-03-17 11:47:29', '2013-03-17 10:47:29', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=105', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (106, 1, '2013-03-17 16:17:33', '2013-03-17 15:17:33', '<p style="text-align: right;">Ajouter un nouveau fichier</p>\n[wpdm_all_packages]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-autosave', '', '', '2013-03-17 16:17:33', '2013-03-17 15:17:33', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/31-autosave', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (107, 1, '2013-03-17 13:42:05', '2013-03-17 12:42:05', '[page_download]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-5', '', '', '2013-03-17 13:42:05', '2013-03-17 12:42:05', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=107', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (108, 1, '2013-03-17 14:54:04', '2013-03-17 13:54:04', '[page_download]', 'Downloads', '', 'inherit', 'open', 'open', '', '31-revision-6', '', '', '2013-03-17 14:54:04', '2013-03-17 13:54:04', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=108', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (109, 1, '2013-03-17 14:55:35', '2013-03-17 13:55:35', '[page_download]', 'Download', '', 'inherit', 'open', 'open', '', '31-revision-7', '', '', '2013-03-17 14:55:35', '2013-03-17 13:55:35', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=109', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (110, 1, '2013-03-17 15:01:47', '2013-03-17 14:01:47', '[page_download]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-8', '', '', '2013-03-17 15:01:47', '2013-03-17 14:01:47', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=110', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (111, 1, '2013-03-17 15:15:15', '2013-03-17 14:15:15', '[page_download categorie="1"]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-9', '', '', '2013-03-17 15:15:15', '2013-03-17 14:15:15', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=111', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (112, 1, '2013-03-17 15:15:52', '2013-03-17 14:15:52', '[page_download]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-10', '', '', '2013-03-17 15:15:52', '2013-03-17 14:15:52', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/31-revision-10/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (113, 1, '2013-03-17 15:17:16', '2013-03-17 14:17:16', '[page_download]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-11', '', '', '2013-03-17 15:17:16', '2013-03-17 14:17:16', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=113', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (115, 1, '2013-03-17 15:42:50', '2013-03-17 14:42:50', '', 'Test IAWS', '', 'publish', 'closed', 'closed', '', 'test-iaws', '', '', '2013-03-17 15:42:50', '2013-03-17 14:42:50', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?post_type=dedo_download&#038;p=115', 0, 'dedo_download', '', 0);
INSERT INTO `wp_posts` VALUES (116, 1, '2013-03-17 15:26:23', '2013-03-17 14:26:23', '[download_page]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-12', '', '', '2013-03-17 15:26:23', '2013-03-17 14:26:23', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=116', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (117, 1, '2013-03-17 15:51:19', '2013-03-17 14:51:19', '[wpdm_all_packages]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-13', '', '', '2013-03-17 15:51:19', '2013-03-17 14:51:19', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=117', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (118, 1, '2013-03-17 11:42:31', '2013-03-17 10:42:31', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-4', '', '', '2013-03-17 11:42:31', '2013-03-17 10:42:31', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=118', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (119, 1, '2013-03-17 11:45:43', '2013-03-17 10:45:43', '[wpuf_dashboard]', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-6', '', '', '2013-03-17 11:45:43', '2013-03-17 10:45:43', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=119', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (120, 1, '2013-03-17 16:17:49', '2013-03-17 15:17:49', '<p style="text-align: right;"><a title="addfic" href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-admin/post.php?post=31&amp;action=edit">Ajouter un nouveau fichier</a></p>\r\n[wpdm_all_packages]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-14', '', '', '2013-03-17 16:17:49', '2013-03-17 15:17:49', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=120', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (121, 1, '2013-03-17 16:25:42', '2013-03-17 15:25:42', '[wpuf_dashboard]', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-7', '', '', '2013-03-17 16:25:42', '2013-03-17 15:25:42', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=121', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (122, 1, '2013-03-17 16:48:18', '2013-03-17 15:48:18', '[wpuf-edit-users]', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-8', '', '', '2013-03-17 16:48:18', '2013-03-17 15:48:18', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=122', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (123, 1, '2013-03-17 16:52:19', '2013-03-17 15:52:19', 'Inscrire les étudiants avec un fichier CVS\r\n\r\nAjouter un nouveau utilisateur\r\n\r\nGérer les téléchargements', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-9', '', '', '2013-03-17 16:52:19', '2013-03-17 15:52:19', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=123', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (124, 1, '2013-04-10 08:17:29', '2013-04-10 07:17:29', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg"><img class="alignleft size-full wp-image-316" title="msg1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg" alt="" width="222" height="227" /></a><a href="/wordpress/?page_id=236"> Envoyer un message aux étudiants sans groupe</a>\n<a href="/wordpress/?page_id=258 ">Envoyer un message aux étudiants</a>\n<a href="/wordpress/?page_id=260"> Envoyer un message à un encadrant</a><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg"><img class="alignright size-full wp-image-317" title="msg2" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg" alt="" width="200" height="200" /></a></p>\n\n<a href="/wordpress/?page_id=331 ">Envoyer un message à un étudiant</a>\n\nhttp://www.gdnlteamtest.netsoro.net/wordpress/wp-admin/post.php?post=&action=edit', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-autosave', '', '', '2013-04-10 08:17:29', '2013-04-10 07:17:29', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=124', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (125, 1, '2013-03-17 11:49:43', '2013-03-17 10:49:43', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-6', '', '', '2013-03-17 11:49:43', '2013-03-17 10:49:43', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=125', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (126, 1, '2013-03-17 17:08:41', '2013-03-17 16:08:41', 'Ecrire à un encadrant\r\n\r\nEcrire aux etudiants sans groupe\r\n\r\nEcrire à tous les étudiants', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-7', '', '', '2013-03-17 17:08:41', '2013-03-17 16:08:41', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=126', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (137, 1, '2013-03-17 16:53:01', '2013-03-17 15:53:01', 'Inscrire les étudiants à partir d'' un fichier CVS\r\n\r\nAjouter un nouveau utilisateur\r\n\r\nGérer les téléchargements', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-10', '', '', '2013-03-17 16:53:01', '2013-03-17 15:53:01', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=137', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (138, 1, '2013-03-14 16:54:32', '2013-03-14 15:54:32', '</br>\r\n<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-9', '', '', '2013-03-14 16:54:32', '2013-03-14 15:54:32', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=138', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (140, 1, '2013-03-17 17:59:13', '2013-03-17 16:59:13', '&nbsp;\r\n<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !HH</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-10', '', '', '2013-03-17 17:59:13', '2013-03-17 16:59:13', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=140', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (141, 1, '2013-03-17 18:00:48', '2013-03-17 17:00:48', '&nbsp;\r\n\r\n<img class="alignleft size-full wp-image-139" title="img1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/img1.jpg" alt="" width="261" height="193" />\r\n<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-11', '', '', '2013-03-17 18:00:48', '2013-03-17 17:00:48', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=141', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (142, 1, '2013-03-17 18:11:26', '2013-03-17 17:11:26', '', 'Accueil', '', 'publish', 'open', 'open', '', 'accueil', '', '', '2013-04-24 18:56:46', '2013-04-24 17:56:46', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=142', 1, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (143, 1, '2013-03-17 17:09:29', '2013-03-17 16:09:29', 'Ecrire à un encadrant\r\n\r\nEcrire aux étudiants sans groupe\r\n\r\nEcrire à tous les étudiants', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-8', '', '', '2013-03-17 17:09:29', '2013-03-17 16:09:29', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=143', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (144, 1, '2013-03-17 18:29:59', '2013-03-17 17:29:59', ' <a href="<?php get_permalink(''127''); ?>" title="Ecrire à un encadrant">Ecrire à un encadrant </a>\r\n\r\n<a href="<?php get_permalink(''131''); ?>" title="Ecrire aux étudiants sans groupe">Ecrire aux étudiants sans groupe</a>\r\n\r\n <a href="<?php get_permalink(''129''); ?>" title="Ecrire à tous les étudiants">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-9', '', '', '2013-03-17 18:29:59', '2013-03-17 17:29:59', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=144', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (145, 1, '2013-03-17 18:30:50', '2013-03-17 17:30:50', ' <a href="<?php get_permalink(''127''); ?>" title="Ecrire à un encadrant">Ecrire à un encadrant </a>\r\n</br>\r\n</br>\r\n<a href="<?php get_permalink(''131''); ?>" title="Ecrire aux étudiants sans groupe">Ecrire aux étudiants sans groupe</a>\r\n</br>\r\n</br>\r\n <a href="<?php get_permalink(''129''); ?>" title="Ecrire à tous les étudiants">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-10', '', '', '2013-03-17 18:30:50', '2013-03-17 17:30:50', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=145', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (146, 1, '2013-03-17 18:32:34', '2013-03-17 17:32:34', '<p> <a href="<?php get_permalink(''127''); ?>" title="Ecrire à un encadrant">Ecrire à un encadrant </a> </p>\r\n<p><a href="<?php get_permalink(''131''); ?>" title="Ecrire aux étudiants sans groupe">Ecrire aux étudiants sans groupe</a></p>\r\n<p> <a href="<?php get_permalink(''129''); ?>" title="Ecrire à tous les étudiants">Ecrire à tous les étudiants</a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-11', '', '', '2013-03-17 18:32:34', '2013-03-17 17:32:34', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=146', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (147, 1, '2013-03-17 18:34:50', '2013-03-17 17:34:50', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(''127''); ?&gt;">Ecrire à un encadrant </a>\r\n\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(''131''); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(''129''); ?&gt;">Ecrire à tous les étudiants</a>\r\n\r\nle <a href="<?php get_permalink(''131''); ?>" title="Plan du site">plan du site</a>.</p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-12', '', '', '2013-03-17 18:34:50', '2013-03-17 17:34:50', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=147', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (148, 1, '2013-03-17 18:36:03', '2013-03-17 17:36:03', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(''127''); ?&gt;">Ecrire à un encadrant </a> </br>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(''131''); ?&gt;">Ecrire aux étudiants sans groupe</a> </br>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(''129''); ?&gt;">Ecrire à tous les étudiants</a>\r\n</p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-13', '', '', '2013-03-17 18:36:03', '2013-03-17 17:36:03', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=148', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (149, 1, '2013-03-17 18:40:19', '2013-03-17 17:40:19', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(''4''); ?&gt;">Ecrire à un encadrant </a> </br>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(''131''); ?&gt;">Ecrire aux étudiants sans groupe</a> </br>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(''129''); ?&gt;">Ecrire à tous les étudiants</a>\r\n</p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-14', '', '', '2013-03-17 18:40:19', '2013-03-17 17:40:19', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=149', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (150, 1, '2013-03-17 18:41:40', '2013-03-17 17:41:40', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(''127''); ?&gt;">Ecrire à un encadrant </a> </br>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(''131''); ?&gt;">Ecrire aux étudiants sans groupe</a> </br>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(''129''); ?&gt;">Ecrire à tous les étudiants</a>\r\n</p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-15', '', '', '2013-03-17 18:41:40', '2013-03-17 17:41:40', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=150', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (151, 1, '2013-03-17 18:43:05', '2013-03-17 17:43:05', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-16', '', '', '2013-03-17 18:43:05', '2013-03-17 17:43:05', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=151', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (152, 1, '2013-03-17 18:44:41', '2013-03-17 17:44:41', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>\r\n\r\n<ul>\r\n<li>MyBlog info:\r\n    <ul>\r\n    <li><a href="<?php echo get_permalink(127); ?>">About MyBlog</a></li>\r\n    <li><a href="<?php echo get_permalink(129); ?>">About the owner</a></li>\r\n    </ul>\r\n</li>\r\n</ul>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-17', '', '', '2013-03-17 18:44:41', '2013-03-17 17:44:41', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=152', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (153, 1, '2013-03-17 18:45:27', '2013-03-17 17:45:27', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>\r\n\r\n<ul>\r\n<li>MyBlog info:\r\n    <ul>\r\n    <li><a href="<?php echo get_permalink(127); ?>">About MyBlog</a></li> </br>\r\n    <li><a href="<?php echo get_permalink(129); ?>">About the owner</a></li>\r\n    </ul>\r\n</li>\r\n</ul>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-18', '', '', '2013-03-17 18:45:27', '2013-03-17 17:45:27', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=153', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (154, 1, '2013-03-17 18:46:20', '2013-03-17 17:46:20', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>\r\n\r\n<ul>\r\n<?php echo get_permalink(); ?>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-19', '', '', '2013-03-17 18:46:20', '2013-03-17 17:46:20', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=154', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (155, 1, '2013-03-17 18:51:17', '2013-03-17 17:51:17', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-20', '', '', '2013-03-17 18:51:17', '2013-03-17 17:51:17', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=155', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (156, 1, '2013-03-17 18:53:28', '2013-03-17 17:53:28', '', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-21', '', '', '2013-03-17 18:53:28', '2013-03-17 17:53:28', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=156', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (158, 1, '2013-03-17 18:55:03', '2013-03-17 17:55:03', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-22', '', '', '2013-03-17 18:55:03', '2013-03-17 17:55:03', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=158', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (159, 1, '2013-03-17 19:34:19', '2013-03-17 18:34:19', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-23', '', '', '2013-03-17 19:34:19', '2013-03-17 18:34:19', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=159', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (160, 1, '2013-03-17 19:34:44', '2013-03-17 18:34:44', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-24', '', '', '2013-03-17 19:34:44', '2013-03-17 18:34:44', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=160', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (161, 1, '2013-03-17 19:35:13', '2013-03-17 18:35:13', '<a title="Ecrire à un encadrant" href="&lt;?php get_permalink(127); ?&gt;">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="&lt;?php get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="&lt;?php get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-25', '', '', '2013-03-17 19:35:13', '2013-03-17 18:35:13', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=161', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (164, 1, '2013-03-17 19:39:21', '2013-03-17 18:39:21', '<a title="Ecrire à un encadrant" href="<?php get_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="<?php get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="<?php get_permalink(129); ?>">Ecrire à tous les étudiants</a>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-26', '', '', '2013-03-17 19:39:21', '2013-03-17 18:39:21', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=164', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (165, 1, '2013-03-17 19:42:08', '2013-03-17 18:42:08', '<a title="Ecrire à un encadrant" href="<?php get_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a title="Ecrire aux étudiants sans groupe" href="<?php get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a title="Ecrire à tous les étudiants" href="<?php get_permalink(129); ?>">Ecrire à tous les étudiants</a>\r\n\r\nPermalink for this post:\r\n<?php echo get_permalink(); ?>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-27', '', '', '2013-03-17 19:42:08', '2013-03-17 18:42:08', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=165', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (166, 1, '2013-03-17 19:45:09', '2013-03-17 18:45:09', '<a href="<?php get_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a href="<?php get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a href="<?php get_permalink(129); ?>">Ecrire à tous les étudiants</a>\r\n\r\n', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-28', '', '', '2013-03-17 19:45:09', '2013-03-17 18:45:09', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=166', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (167, 1, '2013-03-17 19:57:29', '2013-03-17 18:57:29', '<a href="<?php get_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a href="<?php get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a href="<?php get_permalink(129); ?>">Ecrire à tous les étudiants</a>\r\n\r\n\r\n<?php echo post_permalink(); ?> \r\n', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-29', '', '', '2013-03-17 19:57:29', '2013-03-17 18:57:29', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=167', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (168, 1, '2013-03-17 19:58:22', '2013-03-17 18:58:22', '<a href="<?php get_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a href="<?php get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a href="<?php get_permalink(129); ?>">Ecrire à tous les étudiants</a>\r\n\r\n\r\n<?php echo post_permalink(131); ?> \r\n', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-30', '', '', '2013-03-17 19:58:22', '2013-03-17 18:58:22', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=168', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (173, 1, '2013-03-17 19:59:50', '2013-03-17 18:59:50', '<a href="<?php post_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a href="<?php post_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a href="<?php post_permalink(129); ?>">Ecrire à tous les étudiants</a>\r\n\r\n\r\n', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-31', '', '', '2013-03-17 19:59:50', '2013-03-17 18:59:50', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=173', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (174, 1, '2013-03-18 09:42:01', '2013-03-18 08:42:01', '<a href="<?php echo get_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a href="<?php echo get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a href="<?php echo get_permalink(129); ?>/">Ecrire à tous les étudiants</a>\r\n\r\n', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-32', '', '', '2013-03-18 09:42:01', '2013-03-18 08:42:01', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=174', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (175, 1, '2013-03-17 17:51:49', '2013-03-17 16:51:49', 'Inscrire les étudiants à partir d'' un fichier CSV\r\n\r\nAjouter un nouveau utilisateur\r\n\r\nGérer les téléchargements', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-11', '', '', '2013-03-17 17:51:49', '2013-03-17 16:51:49', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=175', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (183, 1, '2013-03-18 09:42:16', '2013-03-18 08:42:16', '<a href="<?php echo get_permalink(127); ?>">Ecrire à un encadrant </a>\r\n<a href="<?php echo get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a>\r\n<a href="<?php echo get_permalink(129); ?>">Ecrire à tous les étudiants</a>\r\n\r\n', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-33', '', '', '2013-03-18 09:42:16', '2013-03-18 08:42:16', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=183', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (184, 1, '2013-03-18 11:18:02', '2013-03-18 10:18:02', '<a href="<?php echo get_permalink(127); ?>">Ecrire à un encadrant </a> </br>\r\n<a href="<?php echo get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a> </br>\r\n<a href="<?php echo get_permalink(129); ?>">Ecrire à tous les étudiants</a>\r\n\r\n', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-34', '', '', '2013-03-18 11:18:02', '2013-03-18 10:18:02', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=184', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (185, 1, '2013-03-18 11:27:46', '2013-03-18 10:27:46', '<p style="text-align: center;">Bienvenue dans votre messagerie !!</p>\r\n<p style="text-align: center;"><a style="font-size: 13px; line-height: 19px;" href="&lt;?php echo get_permalink(127); ?&gt;">Ecrire à un encadrant </a></p>\r\n<p style="text-align: center;"><a href="&lt;?php echo get_permalink(131); ?&gt;">Ecrire aux étudiants sans groupe</a></p>\r\n<p style="text-align: center;"><a href="&lt;?php echo get_permalink(129); ?&gt;">Ecrire à tous les étudiants</a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-35', '', '', '2013-03-18 11:27:46', '2013-03-18 10:27:46', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=185', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (186, 1, '2013-03-18 11:29:32', '2013-03-18 10:29:32', '<p style="text-align: center;">Bienvenue dans votre messagerie !!</p></br>\r\n<p style="text-align: center;"><a style="font-size: 13px; line-height: 19px;" href="<?php echo get_permalink(127); >">Ecrire à un encadrant </a></p></br>\r\n<p style="text-align: center;"><a href="<?php echo get_permalink(131); >">Ecrire aux étudiants sans groupe</a></p></br>\r\n<p style="text-align: center;"><a href="<?php echo get_permalink(129); >">Ecrire à tous les étudiants</a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-36', '', '', '2013-03-18 11:29:32', '2013-03-18 10:29:32', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=186', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (187, 1, '2013-03-18 11:30:21', '2013-03-18 10:30:21', '<p style="text-align: center;">Bienvenue dans votre messagerie !!</p></br>\r\n<p style="text-align: center;"><a style="font-size: 13px; line-height: 19px;" href="<?php echo get_permalink(127); ?>">Ecrire à un encadrant </a></p></br>\r\n<p style="text-align: center;"><a href="<?php echo get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a></p></br>\r\n<p style="text-align: center;"><a href="<?php echo get_permalink(129); ?>">Ecrire à tous les étudiants</a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-37', '', '', '2013-03-18 11:30:21', '2013-03-18 10:30:21', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=187', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (188, 1, '2013-03-17 11:48:32', '2013-03-17 10:48:32', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-5', '', '', '2013-03-17 11:48:32', '2013-03-17 10:48:32', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=188', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (189, 1, '2013-03-18 12:15:44', '2013-03-18 11:15:44', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-6', '', '', '2013-03-18 12:15:44', '2013-03-18 11:15:44', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=189', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (190, 1, '2013-03-18 15:54:14', '2013-03-18 14:54:14', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-7', '', '', '2013-03-18 15:54:14', '2013-03-18 14:54:14', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=190', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (191, 1, '2013-03-17 11:49:14', '2013-03-17 10:49:14', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-6', '', '', '2013-03-17 11:49:14', '2013-03-17 10:49:14', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=191', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (192, 1, '2013-03-18 16:48:54', '2013-03-18 15:48:54', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-autosave', '', '', '2013-03-18 16:48:54', '2013-03-18 15:48:54', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=192', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (193, 1, '2013-03-18 16:44:42', '2013-03-18 15:44:42', '[wpuf-edit-user]', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-7', '', '', '2013-03-18 16:44:42', '2013-03-18 15:44:42', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=193', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (195, 1, '2013-03-18 10:04:16', '2013-03-18 09:04:16', 'Inscrire les étudiants à partir d'' un fichier CSV\r\n\r\nAjouter un nouveau utilisateur\r\n\r\nGérer les téléchargements\r\n\r\nSupprimer des utilisateurs', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-12', '', '', '2013-03-18 10:04:16', '2013-03-18 09:04:16', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=195', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (196, 1, '2013-03-18 17:25:29', '2013-03-18 16:25:29', 'Inscrire les étudiants à partir d''un fichier CSV \r\n\r\n<a href="<?php echo $_SERVER[''SERVER_NAME''] ?>/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-13', '', '', '2013-03-18 17:25:29', '2013-03-18 16:25:29', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=196', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (197, 1, '2013-03-18 17:26:41', '2013-03-18 16:26:41', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="<?php echo $_SERVER[''SERVER_NAME''] ?>/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-14', '', '', '2013-03-18 17:26:41', '2013-03-18 16:26:41', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=197', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (198, 1, '2013-03-18 17:28:18', '2013-03-18 16:28:18', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="<?php echo $_SERVER[''SERVER_NAME''] ?>/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-15', '', '', '2013-03-18 17:28:18', '2013-03-18 16:28:18', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=198', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (199, 1, '2013-03-18 17:29:27', '2013-03-18 16:29:27', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="<?php echo $_SERVER[''SERVER_NAME''] ?>/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs\r\n\r\n<?php echo $_SERVER[''SERVER_NAME''] ?>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-16', '', '', '2013-03-18 17:29:27', '2013-03-18 16:29:27', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=199', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (200, 1, '2013-03-18 17:30:05', '2013-03-18 16:30:05', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="<?php echo $_SERVER[''SERVER_NAME''] ?>/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs\r\n\r\n<?php echo $_SERVER[''SERVER_NAME''] ?>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-17', '', '', '2013-03-18 17:30:05', '2013-03-18 16:30:05', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=200', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (201, 1, '2013-03-18 17:32:04', '2013-03-18 16:32:04', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs\r\n\r\n<?php echo $_SERVER[''SERVER_NAME''] ?>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-18', '', '', '2013-03-18 17:32:04', '2013-03-18 16:32:04', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=201', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (202, 1, '2013-03-18 17:32:59', '2013-03-18 16:32:59', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs\r\n\r\n<?php echo $_SERVER[''SERVER_NAME''] ?>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-19', '', '', '2013-03-18 17:32:59', '2013-03-18 16:32:59', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=202', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (203, 1, '2013-03-18 17:34:12', '2013-03-18 16:34:12', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\nGérer le forum\r\n\r\nSupprimer des utilisateurs\r\n\r\n<?php echo $_SERVER[''SERVER_NAME''] ?>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-20', '', '', '2013-03-18 17:34:12', '2013-03-18 16:34:12', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=203', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (204, 1, '2013-03-18 17:37:21', '2013-03-18 16:37:21', 'Inscrire les étudiants à partir d''un fichier CSV\r\n\r\n<a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a>\r\n\r\nGérer les téléchargements\r\n\r\n<a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a>\r\n\r\n<a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a>\r\n', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-21', '', '', '2013-03-18 17:37:21', '2013-03-18 16:37:21', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=204', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (205, 1, '2013-03-18 17:38:42', '2013-03-18 16:38:42', '&nbsp;\r\n<p style="text-align: center;">Inscrire les étudiants à partir d''un fichier CSV</p> \r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\r\n<p style="text-align: center;">Gérer les téléchargements</p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-22', '', '', '2013-03-18 17:38:42', '2013-03-18 16:38:42', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=205', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (206, 1, '2013-03-18 17:39:19', '2013-03-18 16:39:19', '&nbsp;\r\n<p style="text-align: center;">Inscrire les étudiants à partir d''un fichier CSV</p> </br>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p> </br>\r\n<p style="text-align: center;">Gérer les téléchargements</p> </br>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p> </br>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-23', '', '', '2013-03-18 17:39:19', '2013-03-18 16:39:19', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=206', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (210, 1, '2013-03-18 16:46:51', '2013-03-18 15:46:51', '[wpuf-edit-users]', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-8', '', '', '2013-03-18 16:46:51', '2013-03-18 15:46:51', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=210', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (211, 1, '2013-03-18 11:32:09', '2013-03-18 10:32:09', '</br><p style="text-align: center;"><strong><em>Bienvenue dans votre messagerie !!</em></strong></p></br>\r\n<p style="text-align: center;"><a style="font-size: 13px; line-height: 19px;" href="<?php echo get_permalink(127); ?>">Ecrire à un encadrant </a></p></br>\r\n<p style="text-align: center;"><a href="<?php echo get_permalink(131); ?>">Ecrire aux étudiants sans groupe</a></p></br>\r\n<p style="text-align: center;"><a href="<?php echo get_permalink(129); ?>">Ecrire à tous les étudiants</a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-38', '', '', '2013-03-18 11:32:09', '2013-03-18 10:32:09', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=211', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (213, 1, '2013-03-18 17:51:08', '2013-03-18 16:51:08', '&nbsp;\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p> </br>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p> </br>\r\n<p style="text-align: center;">Gérer les téléchargements</p> </br>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p> </br>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-24', '', '', '2013-03-18 17:51:08', '2013-03-18 16:51:08', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=213', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (214, 1, '2013-03-25 23:59:34', '2013-03-25 22:59:34', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\r\n<p style="text-align: center;">Gérer les téléchargements</p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-25', '', '', '2013-03-25 23:59:34', '2013-03-25 22:59:34', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=214', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (215, 1, '2013-03-26 00:03:00', '2013-03-25 23:03:00', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Gérer les téléchargements</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>\r\n\r\n', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-26', '', '', '2013-03-26 00:03:00', '2013-03-25 23:03:00', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=215', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (216, 1, '2013-03-17 11:44:04', '2013-03-17 10:44:04', '[theme-my-login]', 'Login', '', 'inherit', 'open', 'open', '', '67-revision-2', '', '', '2013-03-17 11:44:04', '2013-03-17 10:44:04', '', 67, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=216', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (217, 1, '2013-03-26 01:15:26', '2013-03-26 00:15:26', 'Vus ^tes à preset decocté(e)', 'Login', '', 'inherit', 'open', 'open', '', '67-autosave', '', '', '2013-03-26 01:15:26', '2013-03-26 00:15:26', '', 67, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=217', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (218, 1, '2013-03-26 01:11:40', '2013-03-26 00:11:40', '', 'Login', '', 'inherit', 'open', 'open', '', '67-revision-3', '', '', '2013-03-26 01:11:40', '2013-03-26 00:11:40', '', 67, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=218', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (219, 1, '2013-03-17 18:01:49', '2013-03-17 17:01:49', '&nbsp;\r\n\r\n<img class="size-full wp-image-139 alignleft" title="img1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/img1.jpg" alt="" width="261" height="193" />\r\n<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-12', '', '', '2013-03-17 18:01:49', '2013-03-17 17:01:49', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=219', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (220, 1, '2013-03-26 01:18:24', '2013-03-26 00:18:24', '&nbsp;\r\n\r\n<img class="size-full wp-image-139 alignleft" title="img1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/img1.jpg" alt="" width="261" height="193" />\r\n<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-13', '', '', '2013-03-26 01:18:24', '2013-03-26 00:18:24', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=220', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (221, 1, '2013-03-26 01:18:35', '2013-03-26 00:18:35', '&nbsp;\r\n\r\n<img class="size-full wp-image-139 alignleft" title="img1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/img1.jpg" alt="" width="261" height="193" />\r\n<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-14', '', '', '2013-03-26 01:18:35', '2013-03-26 00:18:35', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=221', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (222, 1, '2013-03-26 01:58:26', '2013-03-26 00:58:26', '', 'campus2', '', 'inherit', 'open', 'open', '', 'campus2', '', '', '2013-03-26 01:58:26', '2013-03-26 00:58:26', '', 67, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/campus2.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` VALUES (223, 1, '2013-03-26 01:16:08', '2013-03-26 00:16:08', '<strong><em>Vous êtes à présent déconnecté(e)</em></strong>', 'Login', '', 'inherit', 'open', 'open', '', '67-revision-4', '', '', '2013-03-26 01:16:08', '2013-03-26 00:16:08', '', 67, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=223', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (224, 1, '2013-03-26 01:59:20', '2013-03-26 00:59:20', '<strong><em>Vous êtes à présent déconnecté(e)</em></strong>\r\n\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/campus2.jpg"><img class="aligncenter size-full wp-image-222" title="campus2" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/campus2.jpg" alt="" width="437" height="290" /></a>', 'Login', '', 'inherit', 'open', 'open', '', '67-revision-5', '', '', '2013-03-26 01:59:20', '2013-03-26 00:59:20', '', 67, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=224', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (225, 1, '2013-03-17 11:46:51', '2013-03-17 10:46:51', '[wpuf_editprofile]', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-13', '', '', '2013-03-17 11:46:51', '2013-03-17 10:46:51', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=225', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (226, 1, '2013-03-18 16:16:10', '2013-03-18 15:16:10', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-8', '', '', '2013-03-18 16:16:10', '2013-03-18 15:16:10', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=226', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (227, 1, '2013-03-25 10:54:10', '2013-03-25 09:54:10', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-9', '', '', '2013-03-25 10:54:10', '2013-03-25 09:54:10', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=227', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (229, 1, '2013-03-17 16:24:53', '2013-03-17 15:24:53', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-5', '', '', '2013-03-17 16:24:53', '2013-03-17 15:24:53', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=229', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (230, 1, '2013-03-25 10:58:18', '2013-03-25 09:58:18', '<em>Bienvenue dans votre messagerie !!!</em>\r\n\r\n<em></em><em>Glissez le curseur sur l''onglet messagerie pour voir les options qui vous sont offertes.</em>\r\n\r\n&nbsp;', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-39', '', '', '2013-03-25 10:58:18', '2013-03-25 09:58:18', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=230', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (231, 1, '2013-03-17 16:26:53', '2013-03-17 15:26:53', '<p style="text-align: left;">[wpdm_all_packages]</p>', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-15', '', '', '2013-03-17 16:26:53', '2013-03-17 15:26:53', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=231', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (232, 1, '2013-03-17 12:02:52', '2013-03-17 11:02:52', '', 'Forum', '', 'inherit', 'open', 'open', '', '100-revision-2', '', '', '2013-03-17 12:02:52', '2013-03-17 11:02:52', '', 100, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=232', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (233, 1, '2013-03-26 08:47:52', '2013-03-26 07:47:52', '[wp-members page="members-area"]', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-14', '', '', '2013-03-26 08:47:52', '2013-03-26 07:47:52', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=233', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (236, 1, '2013-03-26 09:25:54', '2013-03-26 08:25:54', '', 'Contacter les étudiants sans groupe', '', 'publish', 'open', 'open', '', 'contacter-les-etudiants-sans-groupe', '', '', '2013-03-26 21:08:07', '2013-03-26 20:08:07', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=236', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (237, 1, '2013-03-26 09:24:35', '2013-03-26 08:24:35', '', 'Contacter les étudiants sans groupe', '', 'inherit', 'open', 'open', '', '236-revision', '', '', '2013-03-26 09:24:35', '2013-03-26 08:24:35', '', 236, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=237', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (248, 1, '2013-03-26 09:25:54', '2013-03-26 08:25:54', '', 'Contacter les étudiants sans groupe', '', 'inherit', 'open', 'open', '', '236-revision-2', '', '', '2013-03-26 09:25:54', '2013-03-26 08:25:54', '', 236, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=248', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (249, 1, '2013-03-26 10:36:58', '2013-03-26 09:36:58', '', 'Contacter les étudiants sans groupe', '', 'inherit', 'open', 'open', '', '236-revision-3', '', '', '2013-03-26 10:36:58', '2013-03-26 09:36:58', '', 236, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=249', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (250, 1, '2013-03-26 10:37:18', '2013-03-26 09:37:18', '', 'Contacter les étudiants sans groupe', '', 'inherit', 'open', 'open', '', '236-revision-4', '', '', '2013-03-26 10:37:18', '2013-03-26 09:37:18', '', 236, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=250', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (258, 1, '2013-03-26 10:46:08', '2013-03-26 09:46:08', '', 'Contacter tous les etudiants', '', 'publish', 'open', 'open', '', 'contacter-tous-les-etudiants', '', '', '2013-03-26 19:33:14', '2013-03-26 18:33:14', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=258', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (259, 1, '2013-03-26 10:45:34', '2013-03-26 09:45:34', '', 'Ctacter tus les etudiats', '', 'inherit', 'open', 'open', '', '258-revision', '', '', '2013-03-26 10:45:34', '2013-03-26 09:45:34', '', 258, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=259', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (260, 1, '2013-03-26 10:49:02', '2013-03-26 09:49:02', '', 'Contacter un Encadrant', '', 'publish', 'open', 'open', '', 'contacter-un-encadrant', '', '', '2013-03-26 21:38:16', '2013-03-26 20:38:16', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=260', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (261, 1, '2013-03-26 10:48:37', '2013-03-26 09:48:37', '', 'Ctacter Ecadrat', '', 'inherit', 'open', 'open', '', '260-revision', '', '', '2013-03-26 10:48:37', '2013-03-26 09:48:37', '', 260, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=261', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (263, 1, '2013-03-26 10:46:09', '2013-03-26 09:46:09', '', 'Contacter tous les etudiants', '', 'inherit', 'open', 'open', '', '258-revision-2', '', '', '2013-03-26 10:46:09', '2013-03-26 09:46:09', '', 258, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=263', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (264, 1, '2013-03-26 10:49:02', '2013-03-26 09:49:02', '', 'Contacter un Encadrant', '', 'inherit', 'open', 'open', '', '260-revision-2', '', '', '2013-03-26 10:49:02', '2013-03-26 09:49:02', '', 260, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=264', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (265, 1, '2013-03-26 09:08:42', '2013-03-26 08:08:42', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-6', '', '', '2013-03-26 09:08:42', '2013-03-26 08:08:42', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=265', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (266, 1, '2013-03-26 11:17:01', '2013-03-26 10:17:01', ' ', '', '', 'publish', 'open', 'open', '', '266', '', '', '2013-04-24 18:56:47', '2013-04-24 17:56:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=266', 6, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (267, 1, '2013-03-26 11:17:02', '2013-03-26 10:17:02', ' ', '', '', 'publish', 'open', 'open', '', '267', '', '', '2013-04-24 18:56:47', '2013-04-24 17:56:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=267', 7, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (268, 1, '2013-03-26 11:17:02', '2013-03-26 10:17:02', ' ', '', '', 'publish', 'open', 'open', '', '268', '', '', '2013-04-24 18:56:47', '2013-04-24 17:56:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=268', 8, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (276, 1, '2013-03-26 10:37:39', '2013-03-26 09:37:39', '', 'Contacter les étudiants sans groupe', '', 'inherit', 'open', 'open', '', '236-revision-5', '', '', '2013-03-26 10:37:39', '2013-03-26 09:37:39', '', 236, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=276', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (277, 1, '2013-03-26 10:58:20', '2013-03-26 09:58:20', '', 'Contacter tous les etudiants', '', 'inherit', 'open', 'open', '', '258-revision-3', '', '', '2013-03-26 10:58:20', '2013-03-26 09:58:20', '', 258, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=277', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (278, 1, '2013-03-26 11:07:47', '2013-03-26 10:07:47', '', 'Contacter un Encadrant', '', 'inherit', 'open', 'open', '', '260-revision-3', '', '', '2013-03-26 11:07:47', '2013-03-26 10:07:47', '', 260, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=278', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (281, 1, '2013-03-26 11:49:40', '2013-03-26 10:49:40', '', 'Contacter responsable de l'' UE', '', 'publish', 'open', 'open', '', 'contacter-responsable-de-l-ue', '', '', '2013-04-24 18:37:30', '2013-04-24 17:37:30', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=281', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (282, 1, '2013-03-26 11:49:22', '2013-03-26 10:49:22', '', 'Ctacter responsable de l'' UE', '', 'inherit', 'open', 'open', '', '281-revision', '', '', '2013-03-26 11:49:22', '2013-03-26 10:49:22', '', 281, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=282', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (283, 1, '2013-03-26 11:50:23', '2013-03-26 10:50:23', '', 'Contacter responsable de l'' UE', '', 'publish', 'open', 'open', '', 'contacter-responsable-de-l-ue', '', '', '2013-04-24 18:56:49', '2013-04-24 17:56:49', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=283', 15, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (285, 1, '2013-03-26 11:33:07', '2013-03-26 10:33:07', '', 'Contacter tous les etudiants', '', 'inherit', 'open', 'open', '', '258-revision-4', '', '', '2013-03-26 11:33:07', '2013-03-26 10:33:07', '', 258, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=285', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (286, 1, '2013-03-26 11:32:46', '2013-03-26 10:32:46', '', 'Contacter les étudiants sans groupe', '', 'inherit', 'open', 'open', '', '236-revision-6', '', '', '2013-03-26 11:32:46', '2013-03-26 10:32:46', '', 236, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=286', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (287, 1, '2013-03-26 11:49:40', '2013-03-26 10:49:40', '', 'Contacter responsable de l'' UE', '', 'inherit', 'open', 'open', '', '281-revision-2', '', '', '2013-03-26 11:49:40', '2013-03-26 10:49:40', '', 281, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=287', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (288, 1, '2013-03-26 11:33:36', '2013-03-26 10:33:36', '', 'Contacter un Encadrant', '', 'inherit', 'open', 'open', '', '260-revision-4', '', '', '2013-03-26 11:33:36', '2013-03-26 10:33:36', '', 260, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=288', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (289, 1, '2013-03-26 09:07:14', '2013-03-26 08:07:14', '', 'Informations Etudiants', '', 'inherit', 'open', 'open', '', '4-revision-9', '', '', '2013-03-26 09:07:14', '2013-03-26 08:07:14', '', 4, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=289', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (290, 1, '2013-03-26 09:07:52', '2013-03-26 08:07:52', '', 'Informations Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-10', '', '', '2013-03-26 09:07:52', '2013-03-26 08:07:52', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=290', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (291, 1, '2013-03-26 00:28:26', '2013-03-25 23:28:26', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>\r\n', 'Mises à jour', '', 'inherit', 'open', 'open', '', '25-revision-27', '', '', '2013-03-26 00:28:26', '2013-03-25 23:28:26', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=291', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (292, 1, '2013-03-26 21:51:25', '2013-03-26 20:51:25', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>', 'Gestion des membres', '', 'inherit', 'open', 'open', '', '25-revision-28', '', '', '2013-03-26 21:51:25', '2013-03-26 20:51:25', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=292', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (293, 1, '2013-03-26 21:54:30', '2013-03-26 20:54:30', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=wpfilebase_files">Ajouter ou Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>', 'Gérer téléchargements et forum', '', 'publish', 'closed', 'closed', '', 'gestion-des-telechargements-et-du-forum', '', '', '2013-04-30 00:18:07', '2013-04-29 23:18:07', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=293', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (294, 1, '2013-03-26 21:54:08', '2013-03-26 20:54:08', '\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php"> Supprimer des utilisateurs </a></p>', 'Gestion des téléchargements et du forum', '', 'inherit', 'open', 'open', '', '293-revision', '', '', '2013-03-26 21:54:08', '2013-03-26 20:54:08', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=294', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (295, 1, '2013-03-26 21:54:30', '2013-03-26 20:54:30', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n', 'Gestion des téléchargements et du forum', '', 'inherit', 'open', 'open', '', '293-revision-2', '', '', '2013-03-26 21:54:30', '2013-03-26 20:54:30', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=295', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (296, 1, '2013-03-26 21:55:34', '2013-03-26 20:55:34', ' ', '', '', 'publish', 'open', 'open', '', '296', '', '', '2013-04-24 18:56:48', '2013-04-24 17:56:48', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=296', 11, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (300, 1, '2013-03-26 21:54:44', '2013-03-26 20:54:44', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n', 'Gestion des téléchargements et du forum', '', 'inherit', 'open', 'open', '', '293-revision-3', '', '', '2013-03-26 21:54:44', '2013-03-26 20:54:44', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=300', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (301, 1, '2013-03-26 23:18:07', '2013-03-26 22:18:07', '', 'gerer user', '', 'inherit', 'open', 'open', '', 'gerer-user', '', '', '2013-03-26 23:18:07', '2013-03-26 22:18:07', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` VALUES (302, 1, '2013-03-26 23:15:41', '2013-03-26 22:15:41', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>\r\n', 'Gestion des téléchargements et du forum', '', 'inherit', 'open', 'open', '', '293-revision-4', '', '', '2013-03-26 23:15:41', '2013-03-26 22:15:41', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=302', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (303, 1, '2013-03-26 21:52:51', '2013-03-26 20:52:51', '<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=amucsvimport">Inscrire les étudiants à partir d''un fichier CSV </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/user-new.php"> Ajouter un nouveau utilisateur </a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/users.php">Supprimer des utilisateurs</a></p>', 'Gestion des membres', '', 'inherit', 'open', 'open', '', '25-revision-29', '', '', '2013-03-26 21:52:51', '2013-03-26 20:52:51', '', 25, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=303', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (304, 1, '2013-03-26 09:10:36', '2013-03-26 08:10:36', '[wp-members page="members-area"]', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-15', '', '', '2013-03-26 09:10:36', '2013-03-26 08:10:36', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=304', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (305, 1, '2013-03-26 23:39:44', '2013-03-26 22:39:44', '<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a>[wp-members page="members-area"]', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-autosave', '', '', '2013-03-26 23:39:44', '2013-03-26 22:39:44', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=305', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (309, 1, '2013-03-26 01:19:00', '2013-03-26 00:19:00', '&nbsp;\r\n\r\n<img class="size-full wp-image-139 alignleft" title="img1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/img1.jpg" alt="" width="261" height="193" />\r\n<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-15', '', '', '2013-03-26 01:19:00', '2013-03-26 00:19:00', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=309', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (311, 1, '2013-03-27 00:43:07', '2013-03-26 23:43:07', '<p style="text-align: center;">\r\n\r\nVous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl.jpg"><img class="alignleft size-thumbnail wp-image-308" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl-150x120.jpg" alt="" width="150" height="120" /></a></p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-16', '', '', '2013-03-27 00:43:07', '2013-03-26 23:43:07', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=311', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (312, 1, '2013-03-27 17:23:56', '2013-03-27 16:23:56', ' ', '', '', 'publish', 'open', 'open', '', '312', '', '', '2013-04-24 18:56:50', '2013-04-24 17:56:50', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=312', 18, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (313, 1, '2013-03-26 09:09:07', '2013-03-26 08:09:07', '<em>Bienvenue dans votre messagerie !!!</em>\r\n\r\n<em></em><em>Glissez le curseur sur l''onglet messagerie pour voir les options qui vous sont offertes.</em>\r\n\r\n&nbsp;', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-40', '', '', '2013-03-26 09:09:07', '2013-03-26 08:09:07', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=313', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (314, 1, '2013-03-27 18:29:09', '2013-03-27 17:29:09', '<em>Bienvenue dans votre messagerie !!!</em>\r\n\r\n<em></em><em>Glissez le curseur sur l''onglet messagerie pour voir les options qui vous sont offertes.</em>\r\n\r\n&nbsp;\r\n\r\nhttp://www.gdnlteamtest.netsoro.net/wordpress/?page_id=236 Envoyer un message aux étudiants sans groupe\r\nhttp://www.gdnlteamtest.netsoro.net/wordpress/?page_id=258 Envoyer un message aux étudiants\r\nhttp://www.gdnlteamtest.netsoro.net/wordpress/?page_id=260 Envoyer un message à un encadrant', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-41', '', '', '2013-03-27 18:29:09', '2013-03-27 17:29:09', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=314', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (315, 1, '2013-03-27 18:37:58', '2013-03-27 17:37:58', '<p style="text-align: center;"><em>Bienvenue dans votre messagerie !!!</em>\r\n<a href="/wordpress/?page_id=236"> Envoyer un message aux étudiants sans groupe</a>\r\n<a href="/wordpress/?page_id=258 ">Envoyer un message aux étudiants</a>\r\n<a href="/wordpress/?page_id=260"> Envoyer un message à un encadrant</a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-42', '', '', '2013-03-27 18:37:58', '2013-03-27 17:37:58', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=315', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (316, 1, '2013-03-27 18:41:02', '2013-03-27 17:41:02', '', 'msg1', '', 'inherit', 'open', 'open', '', 'msg1', '', '', '2013-03-27 18:41:02', '2013-03-27 17:41:02', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` VALUES (317, 1, '2013-03-27 18:41:36', '2013-03-27 17:41:36', '', 'msg2', '', 'inherit', 'open', 'open', '', 'msg2', '', '', '2013-03-27 18:41:36', '2013-03-27 17:41:36', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` VALUES (318, 1, '2013-03-27 18:38:48', '2013-03-27 17:38:48', '<p style="text-align: center;">\r\n<a href="/wordpress/?page_id=236"> Envoyer un message aux étudiants sans groupe</a>\r\n<a href="/wordpress/?page_id=258 ">Envoyer un message aux étudiants</a>\r\n<a href="/wordpress/?page_id=260"> Envoyer un message à un encadrant</a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-43', '', '', '2013-03-27 18:38:48', '2013-03-27 17:38:48', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=318', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (319, 1, '2013-03-27 18:42:31', '2013-03-27 17:42:31', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg"><img class="alignleft size-full wp-image-316" title="msg1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg" alt="" width="222" height="227" /></a><a href="/wordpress/?page_id=236"> Envoyer un message aux étudiants sans groupe</a>\r\n<a href="/wordpress/?page_id=258 ">Envoyer un message aux étudiants</a>\r\n<a href="/wordpress/?page_id=260"> Envoyer un message à un encadrant</a><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg"><img class="alignright size-full wp-image-317" title="msg2" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg" alt="" width="200" height="200" /></a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-44', '', '', '2013-03-27 18:42:31', '2013-03-27 17:42:31', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=319', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (320, 1, '2013-03-26 23:38:34', '2013-03-26 22:38:34', '<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a>[wp-members page="members-area"]', 'Modifier Paramètres', '', 'inherit', 'open', 'open', '', '14-revision-16', '', '', '2013-03-26 23:38:34', '2013-03-26 22:38:34', '', 14, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=320', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (322, 1, '2013-03-26 11:11:37', '2013-03-26 10:11:37', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-7', '', '', '2013-03-26 11:11:37', '2013-03-26 10:11:37', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=322', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (323, 1, '2013-04-01 22:08:05', '2013-04-01 21:08:05', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-8', '', '', '2013-04-01 22:08:05', '2013-04-01 21:08:05', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=323', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (324, 1, '2013-04-01 22:08:26', '2013-04-01 21:08:26', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-9', '', '', '2013-04-01 22:08:26', '2013-04-01 21:08:26', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=324', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (325, 1, '2013-03-26 21:50:00', '2013-03-26 20:50:00', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-11', '', '', '2013-03-26 21:50:00', '2013-03-26 20:50:00', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=325', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (326, 1, '2013-04-01 22:11:51', '2013-04-01 21:11:51', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-12', '', '', '2013-04-01 22:11:51', '2013-04-01 21:11:51', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=326', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (327, 1, '2013-04-01 22:11:08', '2013-04-01 21:11:08', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-10', '', '', '2013-04-01 22:11:08', '2013-04-01 21:11:08', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=327', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (328, 1, '2013-04-02 01:00:56', '2013-04-02 00:00:56', '', 'Ajouter un sujet', '', 'inherit', 'open', 'open', '', '33-revision-11', '', '', '2013-04-02 01:00:56', '2013-04-02 00:00:56', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=328', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (329, 1, '2013-04-02 01:35:37', '2013-04-02 00:35:37', '', 'Choisir projet', '', 'inherit', 'open', 'open', '', '33-revision-12', '', '', '2013-04-02 01:35:37', '2013-04-02 00:35:37', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=329', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (331, 1, '2013-04-10 08:13:54', '2013-04-10 07:13:54', '', 'Contacter un étudiant', '', 'publish', 'open', 'open', '', 'contacter-un-etudiant-2', '', '', '2013-04-10 08:13:54', '2013-04-10 07:13:54', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=331', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (335, 1, '2013-04-10 08:07:20', '2013-04-10 07:07:20', '', 'Contacter un étudiant', '', 'inherit', 'open', 'open', '', '331-revision', '', '', '2013-04-10 08:07:20', '2013-04-10 07:07:20', '', 331, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=335', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (336, 1, '2013-04-10 08:14:37', '2013-04-10 07:14:37', ' ', '', '', 'publish', 'open', 'open', '', '336', '', '', '2013-04-24 18:56:47', '2013-04-24 17:56:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=336', 9, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (337, 1, '2013-03-27 18:44:23', '2013-03-27 17:44:23', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg"><img class="alignleft size-full wp-image-316" title="msg1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg" alt="" width="222" height="227" /></a><a href="/wordpress/?page_id=236"> Envoyer un message aux étudiants sans groupe</a>\r\n<a href="/wordpress/?page_id=258 ">Envoyer un message aux étudiants</a>\r\n<a href="/wordpress/?page_id=260"> Envoyer un message à un encadrant</a><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg"><img class="alignright size-full wp-image-317" title="msg2" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg" alt="" width="200" height="200" /></a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-45', '', '', '2013-03-27 18:44:23', '2013-03-27 17:44:23', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=337', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (339, 1, '2013-04-10 21:33:47', '2013-04-10 20:33:47', '', 'Calcul des charges', '', 'publish', 'open', 'open', '', 'calcul-des-charges', '', '', '2013-04-10 21:33:47', '2013-04-10 20:33:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=339', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (340, 1, '2013-04-10 21:33:32', '2013-04-10 20:33:32', '', 'Calcul des charges', '', 'inherit', 'open', 'open', '', '339-revision', '', '', '2013-04-10 21:33:32', '2013-04-10 20:33:32', '', 339, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=340', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (341, 1, '2013-04-10 21:34:56', '2013-04-10 20:34:56', ' ', '', '', 'publish', 'open', 'open', '', '341', '', '', '2013-04-24 18:56:49', '2013-04-24 17:56:49', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=341', 16, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (342, 1, '2013-04-01 22:12:08', '2013-04-01 21:12:08', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-13', '', '', '2013-04-01 22:12:08', '2013-04-01 21:12:08', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=342', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (343, 1, '2013-04-01 22:12:08', '2013-04-01 21:12:08', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-14', '', '', '2013-04-01 22:12:08', '2013-04-01 21:12:08', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=343', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (344, 1, '2013-04-11 11:58:34', '2013-04-11 10:58:34', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-15', '', '', '2013-04-11 11:58:34', '2013-04-11 10:58:34', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=344', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (345, 1, '2013-04-11 12:08:52', '2013-04-11 11:08:52', '', 'Ajout groupe', '', 'publish', 'open', 'open', '', 'ajout-groupe', '', '', '2013-04-24 18:34:58', '2013-04-24 17:34:58', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=345', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (346, 1, '2013-04-11 12:08:37', '2013-04-11 11:08:37', '', 'Ajout groupe', '', 'inherit', 'open', 'open', '', '345-revision', '', '', '2013-04-11 12:08:37', '2013-04-11 11:08:37', '', 345, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=346', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (347, 1, '2013-04-11 12:12:03', '2013-04-11 11:12:03', ' ', '', '', 'publish', 'open', 'open', '', '347', '', '', '2013-04-24 18:56:49', '2013-04-24 17:56:49', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=347', 17, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` VALUES (348, 1, '2013-04-11 12:06:57', '2013-04-11 11:06:57', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-16', '', '', '2013-04-11 12:06:57', '2013-04-11 11:06:57', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=348', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (349, 1, '2013-04-11 12:13:26', '2013-04-11 11:13:26', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-17', '', '', '2013-04-11 12:13:26', '2013-04-11 11:13:26', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=349', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (350, 1, '2013-04-11 12:25:41', '2013-04-11 11:25:41', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-18', '', '', '2013-04-11 12:25:41', '2013-04-11 11:25:41', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=350', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (351, 1, '2013-04-11 13:09:56', '2013-04-11 12:09:56', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-19', '', '', '2013-04-11 13:09:56', '2013-04-11 12:09:56', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=351', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (352, 1, '2013-04-02 02:30:04', '2013-04-02 01:30:04', '', 'Choisir projet', '', 'inherit', 'open', 'open', '', '33-revision-13', '', '', '2013-04-02 02:30:04', '2013-04-02 01:30:04', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=352', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (353, 1, '2013-04-11 12:08:52', '2013-04-11 11:08:52', '', 'Ajout groupe', '', 'inherit', 'open', 'open', '', '345-revision-2', '', '', '2013-04-11 12:08:52', '2013-04-11 11:08:52', '', 345, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=353', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (354, 1, '2013-04-11 13:29:08', '2013-04-11 12:29:08', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-20', '', '', '2013-04-11 13:29:08', '2013-04-11 12:29:08', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=354', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (355, 1, '2013-04-13 13:19:20', '2013-04-13 12:19:20', '', 'Ajout groupe', '', 'inherit', 'open', 'open', '', '345-revision-3', '', '', '2013-04-13 13:19:20', '2013-04-13 12:19:20', '', 345, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=355', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (357, 1, '2013-04-13 13:25:53', '2013-04-13 12:25:53', '', 'Ajout groupe', '', 'inherit', 'open', 'open', '', '345-revision-4', '', '', '2013-04-13 13:25:53', '2013-04-13 12:25:53', '', 345, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=357', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (358, 1, '2013-03-26 21:37:10', '2013-03-26 20:37:10', '', 'Contacter responsable de l'' UE', '', 'inherit', 'open', 'open', '', '281-revision-3', '', '', '2013-03-26 21:37:10', '2013-03-26 20:37:10', '', 281, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=358', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (359, 1, '2013-04-13 13:21:57', '2013-04-13 12:21:57', '', 'Espace Encadrants', '', 'inherit', 'open', 'open', '', '22-revision-21', '', '', '2013-04-13 13:21:57', '2013-04-13 12:21:57', '', 22, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=359', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (361, 1, '2013-04-13 12:59:54', '2013-04-13 11:59:54', '', 'Choisir projet', '', 'inherit', 'open', 'open', '', '33-revision-14', '', '', '2013-04-13 12:59:54', '2013-04-13 11:59:54', '', 33, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=361', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (362, 1, '2013-04-10 08:18:07', '2013-04-10 07:18:07', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg"><img class="alignleft size-full wp-image-316" title="msg1" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg1.jpg" alt="" width="222" height="227" /></a><a href="/wordpress/?page_id=236"> Envoyer un message aux étudiants sans groupe</a>\r\n<a href="/wordpress/?page_id=258 ">Envoyer un message aux étudiants</a>\r\n<a href="/wordpress/?page_id=260"> Envoyer un message à un encadrant</a>\r\n<a href="/wordpress/?page_id=331 ">Envoyer un message à un étudiant</a>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg"><img class="alignright size-full wp-image-317" title="msg2" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/msg2.jpg" alt="" width="200" height="200" /></a></p>', 'Messagerie', '', 'inherit', 'open', 'open', '', '29-revision-46', '', '', '2013-04-10 08:18:07', '2013-04-10 07:18:07', '', 29, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=362', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (364, 1, '2013-04-29 11:44:11', '2013-04-29 10:44:11', '', 'Message a un groupe', '', 'publish', 'closed', 'closed', '', 'message-a-un-groupe', '', '', '2013-04-29 13:03:02', '2013-04-29 12:03:02', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=364', 0, 'page', '', 0);
INSERT INTO `wp_posts` VALUES (365, 1, '2013-04-29 11:44:02', '2013-04-29 10:44:02', '', 'Message a un groupe', '', 'inherit', 'open', 'open', '', '364-revision', '', '', '2013-04-29 11:44:02', '2013-04-29 10:44:02', '', 364, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=365', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (366, 1, '2013-04-29 11:44:11', '2013-04-29 10:44:11', '', 'Message a un groupe', '', 'inherit', 'open', 'open', '', '364-revision-2', '', '', '2013-04-29 11:44:11', '2013-04-29 10:44:11', '', 364, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=366', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (367, 1, '2013-04-29 11:54:50', '2013-04-29 10:54:50', '', 'Message a un groupe', '', 'inherit', 'open', 'open', '', '364-revision-3', '', '', '2013-04-29 11:54:50', '2013-04-29 10:54:50', '', 364, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=367', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (368, 1, '2013-03-26 23:18:31', '2013-03-26 22:18:31', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>', 'Gestion des téléchargements et du forum', '', 'inherit', 'open', 'open', '', '293-revision-5', '', '', '2013-03-26 23:18:31', '2013-03-26 22:18:31', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=368', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (369, 1, '2013-04-29 18:15:31', '2013-04-29 17:15:31', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>', 'Gérer téléchargements et forum', '', 'inherit', 'open', 'open', '', '293-revision-6', '', '', '2013-04-29 18:15:31', '2013-04-29 17:15:31', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=369', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (370, 1, '2013-04-29 20:40:29', '2013-04-29 19:40:29', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>', 'Gérer téléchargements et forum', '', 'inherit', 'open', 'open', '', '293-revision-7', '', '', '2013-04-29 20:40:29', '2013-04-29 19:40:29', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=370', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (371, 1, '2013-03-26 09:09:40', '2013-03-26 08:09:40', '<p style="text-align: left;">[wpdm_all_packages]</p>', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-16', '', '', '2013-03-26 09:09:40', '2013-03-26 08:09:40', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=371', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (372, 1, '2013-04-29 23:57:27', '2013-04-29 22:57:27', '', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-17', '', '', '2013-04-29 23:57:27', '2013-04-29 22:57:27', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=372', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (373, 1, '2013-04-29 23:57:47', '2013-04-29 22:57:47', '[wpdm_all_packages]', 'Téléchargements', '', 'inherit', 'open', 'open', '', '31-revision-18', '', '', '2013-04-29 23:57:47', '2013-04-29 22:57:47', '', 31, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=373', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (374, 1, '2013-04-30 00:17:44', '2013-04-29 23:17:44', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=wpfilebase_manage"> supprimer un document à telecharger</a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=wpfilebase_files">Ajouter ou Supprimer un document du telechargement</a></p>\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>', 'Gérer téléchargements et forum', '', 'inherit', 'open', 'open', '', '293-autosave', '', '', '2013-04-30 00:17:44', '2013-04-29 23:17:44', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=374', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (375, 1, '2013-04-29 20:41:41', '2013-04-29 19:41:41', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=file-manager/add-new-file">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=file-manager">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>', 'Gérer téléchargements et forum', '', 'inherit', 'open', 'open', '', '293-revision-8', '', '', '2013-04-29 20:41:41', '2013-04-29 19:41:41', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=375', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (376, 1, '2013-04-30 00:08:04', '2013-04-29 23:08:04', '<p style="text-align: center;"><a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg"><img class="alignright size-full wp-image-301" title="gerer user" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/gerer-user.jpg" alt="" width="259" height="194" /></a><a href="/wordpress/wp-admin/admin.php?page=wpfilebase_manage">Ajouter un document à telecharger</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=wpfilebase_files">Supprimer un document du telechargement</a></p>\r\n<p style="text-align: center;"><a href="/wordpress/wp-admin/admin.php?page=simple-press/admin/panel-forums/spa-forums.php"> Gérer le forum </a></p>', 'Gérer téléchargements et forum', '', 'inherit', 'open', 'open', '', '293-revision-9', '', '', '2013-04-30 00:08:04', '2013-04-29 23:08:04', '', 293, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=376', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (377, 1, '2013-03-27 00:46:41', '2013-03-26 23:46:41', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-17', '', '', '2013-03-27 00:46:41', '2013-03-26 23:46:41', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=377', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (378, 1, '2013-04-30 00:57:47', '2013-04-29 23:57:47', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>\r\n<p style="text-align: center;"></p>\r\n<p style="text-align: center;"></p>\r\n<p style="text-align: center;">[book id=’1′ /]</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-18', '', '', '2013-04-30 00:57:47', '2013-04-29 23:57:47', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=378', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (379, 1, '2013-04-30 01:19:22', '2013-04-30 00:19:22', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>\r\n<p style="text-align: center;"> [nggallery id=x template="3dfluxsliderview"]</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-19', '', '', '2013-04-30 01:19:22', '2013-04-30 00:19:22', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=379', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (380, 1, '2013-04-30 01:23:12', '2013-04-30 00:23:12', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>\r\n<p style="text-align: center;"> [nggallery id=1 template="3dfluxsliderview"]</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-20', '', '', '2013-04-30 01:23:12', '2013-04-30 00:23:12', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=380', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (382, 1, '2013-04-30 01:23:37', '2013-04-30 00:23:37', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>\r\n<p style="text-align: center;"> [nggallery id=x template="3dfluxsliderview"]</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-21', '', '', '2013-04-30 01:23:37', '2013-04-30 00:23:37', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=382', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (383, 1, '2013-04-30 01:36:39', '2013-04-30 00:36:39', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>\r\n<p style="text-align: center;"></p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-22', '', '', '2013-04-30 01:36:39', '2013-04-30 00:36:39', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=383', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (384, 1, '2013-04-30 12:11:57', '2013-04-30 11:11:57', '<p style="text-align: center;">Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>\r\n<p style="text-align: center;">[flgallery id=1 /]</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-23', '', '', '2013-04-30 12:11:57', '2013-04-30 11:11:57', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=384', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (385, 1, '2013-04-30 12:14:10', '2013-04-30 11:14:10', '<p style="text-align: center;">[flgallery id=1 /]    Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif"><img class="alignright size-full wp-image-306" title="master-ihm" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/master-ihm.gif" alt="" width="127" height="71" /></a></p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg"><img class="size-full wp-image-310 alignleft" title="dl" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/dl1.jpg" alt="" width="280" height="120" /></a>Identifiez-vous et  trouvez le projet qui vous correspond.\r\n<p style="text-align: center;">Bon courage !        <a href="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis.png"><img class="alignright size-thumbnail wp-image-307" title="logoM2IMbis" src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/03/logoM2IMbis-150x150.png" alt="" width="150" height="150" /></a></p>\r\n<p style="text-align: center;"></p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-24', '', '', '2013-04-30 12:14:10', '2013-04-30 11:14:10', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=385', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (386, 1, '2013-04-30 12:22:48', '2013-04-30 11:22:48', '<p style="text-align: center;">[flgallery id=1 /]    Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-25', '', '', '2013-04-30 12:22:48', '2013-04-30 11:22:48', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=386', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (387, 1, '2013-04-30 18:39:20', '2013-04-30 17:39:20', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:blue;">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-26', '', '', '2013-04-30 18:39:20', '2013-04-30 17:39:20', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=387', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (388, 1, '2013-04-30 18:40:39', '2013-04-30 17:40:39', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:gray;">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-27', '', '', '2013-04-30 18:40:39', '2013-04-30 17:40:39', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=388', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (389, 1, '2013-04-30 18:41:57', '2013-04-30 17:41:57', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:gray; float:center;">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-28', '', '', '2013-04-30 18:41:57', '2013-04-30 17:41:57', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=389', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (390, 1, '2013-04-30 18:42:40', '2013-04-30 17:42:40', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:gray; float:left;">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-29', '', '', '2013-04-30 18:42:40', '2013-04-30 17:42:40', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=390', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (391, 1, '2013-04-30 18:43:39', '2013-04-30 17:43:39', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:gray; float:right;">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-30', '', '', '2013-04-30 18:43:39', '2013-04-30 17:43:39', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=391', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (392, 1, '2013-04-30 18:50:56', '2013-04-30 17:50:56', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:gray; float:right;\r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:    7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow:         7px 7px 5px rgba(81, 50, 50, 0.75);">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-31', '', '', '2013-04-30 18:50:56', '2013-04-30 17:50:56', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=392', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (393, 1, '2013-04-30 18:52:13', '2013-04-30 17:52:13', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:gray; float:right;\r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-32', '', '', '2013-04-30 18:52:13', '2013-04-30 17:52:13', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=393', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (394, 1, '2013-04-30 18:55:20', '2013-04-30 17:55:20', '<p style="text-align: center;">[flgallery id=1 /]  <div style="background:gray; float:right;\r\n\r\nbox-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);">  Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités</p>\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;">\r\n</div>\r\n</p>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-33', '', '', '2013-04-30 18:55:20', '2013-04-30 17:55:20', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=394', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (396, 1, '2013-05-01 21:40:50', '2013-05-01 20:40:50', '', 'dl', '', 'inherit', 'open', 'open', '', 'dl-3', '', '', '2013-05-01 21:40:50', '2013-05-01 20:40:50', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/dl.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` VALUES (401, 1, '2013-04-30 18:57:17', '2013-04-30 17:57:17', '<p style="text-align: center;">[flgallery id=1 /]</p>\r\n\r\n<div style="background: gray; float: right; \r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\r\n\r\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>\r\n\r\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-34', '', '', '2013-04-30 18:57:17', '2013-04-30 17:57:17', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=401', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (402, 1, '2013-05-01 21:48:40', '2013-05-01 20:48:40', '[easingslider]\r\n<p style="text-align: center;">[flgallery id=1 /]</p>\r\n\r\n<div style="background: gray; float: right; \r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\r\n\r\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>\r\n\r\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-35', '', '', '2013-05-01 21:48:40', '2013-05-01 20:48:40', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=402', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (403, 1, '2013-05-01 22:21:47', '2013-05-01 21:21:47', '', 'logo_ups_pres1', '', 'inherit', 'open', 'open', '', 'logo_ups_pres1', '', '', '2013-05-01 22:21:47', '2013-05-01 21:21:47', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/logo_ups_pres1.png', 0, 'attachment', 'image/png', 0);
INSERT INTO `wp_posts` VALUES (404, 1, '2013-05-01 22:22:36', '2013-05-01 21:22:36', '', 'logoM2IMbis', '', 'inherit', 'open', 'open', '', 'logom2imbis', '', '', '2013-05-01 22:22:36', '2013-05-01 21:22:36', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/logoM2IMbis.png', 0, 'attachment', 'image/png', 0);
INSERT INTO `wp_posts` VALUES (405, 1, '2013-05-01 22:23:17', '2013-05-01 21:23:17', '', 'master-ihm', '', 'inherit', 'open', 'open', '', 'master-ihm', '', '', '2013-05-01 22:23:17', '2013-05-01 21:23:17', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/master-ihm.gif', 0, 'attachment', 'image/gif', 0);
INSERT INTO `wp_posts` VALUES (406, 1, '2013-05-01 22:24:48', '2013-05-01 21:24:48', '', 'ups', '', 'inherit', 'open', 'open', '', 'ups', '', '', '2013-05-01 22:24:48', '2013-05-01 21:24:48', '', 0, 'http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/uploads/2013/05/ups.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` VALUES (407, 1, '2013-05-01 21:57:02', '2013-05-01 20:57:02', '<p style="text-align: center;">[easingslider]</p>\r\n\r\n<div style="background: gray; float: right; \r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\r\n\r\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>\r\n\r\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-36', '', '', '2013-05-01 21:57:02', '2013-05-01 20:57:02', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=407', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (409, 1, '2013-05-01 22:27:34', '2013-05-01 21:27:34', '<center> [easingslider] </center>\r\n<p style="text-align: center;"></p>\r\n\r\n<div style="background: gray; float: right; \r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\r\n\r\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>\r\n\r\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-37', '', '', '2013-05-01 22:27:34', '2013-05-01 21:27:34', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=409', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (411, 1, '2013-05-05 15:28:49', '2013-05-05 14:28:49', '<center> [easingslider] </center>\r\n<p style="text-align: center;"></p>\r\n\r\n<div style="background: gray; float: right; \r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\r\n\r\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>\r\n\r\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-38', '', '', '2013-05-05 15:28:49', '2013-05-05 14:28:49', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=411', 0, 'revision', '', 0);
INSERT INTO `wp_posts` VALUES (412, 1, '2013-05-18 21:55:24', '2013-05-18 20:55:24', '\r\n<p style="text-align: center;"></p>\r\n\r\n<div style="background: gray; float: right; \r\n-webkit-box-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);\r\n-moz-box-shadow:7px 7px 5px rgba(81, 50, 50, 0.75);\r\nbox-shadow: 7px 7px 5px rgba(81, 50, 50, 0.75);">\r\n\r\n Vous trouverez sur ce site toutes les offres de projet dans chacune des spécialités\r\n<p style="text-align: center;">( <em><strong>DL</strong></em>,<em><strong> IARF</strong></em>, <em><strong>IM</strong></em>,<strong><em> IHM</em></strong>, <strong><em>CAMSI </em></strong>) .</p>\r\n<p style="text-align: center;">Identifiez-vous et  trouvez le projet qui vous correspond.</p>\r\n<p style="text-align: center;">Bon courage !</p>\r\n<p style="text-align: center;"></p>\r\n\r\n</div>', 'Bienvenue sur le site de l''UE projet&nbsp;!', '', 'inherit', 'open', 'open', '', '1-revision-39', '', '', '2013-05-18 21:55:24', '2013-05-18 20:55:24', '', 1, 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=412', 0, 'revision', '', 0);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_private_messages`
-- 

CREATE TABLE `wp_private_messages` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `senderid` int(11) NOT NULL DEFAULT '0',
  `rcpid` int(11) NOT NULL DEFAULT '0',
  `sender` varchar(30) NOT NULL,
  `recipient` varchar(30) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `fromsee` tinyint(2) DEFAULT NULL,
  `tosee` tinyint(2) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(2) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_private_messages`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_role_scope_rs`
-- 

CREATE TABLE `wp_role_scope_rs` (
  `requirement_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) NOT NULL DEFAULT '',
  `role_type` enum('rs','wp','wp_cap') NOT NULL DEFAULT 'rs',
  `topic` enum('blog','term','object') NOT NULL,
  `src_or_tx_name` varchar(32) NOT NULL DEFAULT '',
  `obj_or_term_id` bigint(20) NOT NULL DEFAULT '0',
  `max_scope` enum('blog','term','object') NOT NULL,
  `require_for` enum('entity','children','both') NOT NULL DEFAULT 'entity',
  `inherited_from` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`requirement_id`),
  KEY `role_scope` (`max_scope`,`topic`,`require_for`,`role_type`,`role_name`,`src_or_tx_name`,`obj_or_term_id`),
  KEY `role_scope_assignments` (`max_scope`,`topic`,`require_for`,`role_type`,`role_name`,`src_or_tx_name`,`obj_or_term_id`,`inherited_from`,`requirement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_role_scope_rs`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfauthcats`
-- 

CREATE TABLE `wp_sfauthcats` (
  `authcat_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `authcat_name` varchar(50) NOT NULL,
  `authcat_slug` varchar(50) NOT NULL,
  `authcat_desc` tinytext,
  PRIMARY KEY (`authcat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- Contenu de la table `wp_sfauthcats`
-- 

INSERT INTO `wp_sfauthcats` VALUES (1, 'General', 'general', 'auth category for general auths');
INSERT INTO `wp_sfauthcats` VALUES (2, 'Viewing', 'viewing', 'auth category for viewing auths');
INSERT INTO `wp_sfauthcats` VALUES (3, 'Creating', 'creating', 'auth category for creating auths');
INSERT INTO `wp_sfauthcats` VALUES (4, 'Editing', 'editing', 'auth category for editing auths');
INSERT INTO `wp_sfauthcats` VALUES (5, 'Deleting', 'deleting', 'auth category for deleting auths');
INSERT INTO `wp_sfauthcats` VALUES (6, 'Moderation', 'moderation', 'auth category for moderation auths');
INSERT INTO `wp_sfauthcats` VALUES (7, 'Tools', 'tools', 'auth category for tools auths');
INSERT INTO `wp_sfauthcats` VALUES (8, 'Uploading', 'uploading', 'auth category for uploading auths');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfauths`
-- 

CREATE TABLE `wp_sfauths` (
  `auth_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auth_name` varchar(50) NOT NULL,
  `auth_desc` text,
  `active` smallint(1) NOT NULL DEFAULT '0',
  `ignored` smallint(1) NOT NULL DEFAULT '0',
  `enabling` smallint(1) NOT NULL DEFAULT '0',
  `admin_negate` smallint(1) NOT NULL DEFAULT '0',
  `auth_cat` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`auth_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

-- 
-- Contenu de la table `wp_sfauths`
-- 

INSERT INTO `wp_sfauths` VALUES (1, 'view_forum', 'Can view a forum', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (2, 'view_forum_lists', 'Can view a list of forums only', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (3, 'view_forum_topic_lists', 'Can view a list of forums and list of topics only', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (4, 'view_admin_posts', 'Can view posts by an administrator', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (5, 'view_own_admin_posts', 'Can view only own posts and admin/mod posts', 1, 0, 0, 1, 1);
INSERT INTO `wp_sfauths` VALUES (6, 'start_topics', 'Can start new topics in a forum', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (7, 'reply_topics', 'Can reply to existing topics in a forum', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (8, 'reply_own_topics', 'Can only reply to own topics', 1, 0, 0, 1, 1);
INSERT INTO `wp_sfauths` VALUES (9, 'edit_own_topic_titles', 'Can edit own topic titles', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (10, 'edit_any_topic_titles', 'Can edit any topic title', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (11, 'pin_topics', 'Can pin topics in a forum', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (12, 'move_topics', 'Can move topics from a forum', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (13, 'move_posts', 'Can move posts from a topic', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (14, 'lock_topics', 'Can lock topics in a forum', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (15, 'delete_topics', 'Can delete topics in forum', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (16, 'edit_own_posts_forever', 'Can edit own posts forever', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (17, 'edit_own_posts_reply', 'Can edit own posts until there has been a reply', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (18, 'edit_any_post', 'Can edit any post', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (19, 'delete_own_posts', 'Can delete own posts', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (20, 'delete_any_post', 'Can delete any post', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (21, 'pin_posts', 'Can pin posts within a topic', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (22, 'reassign_posts', 'Can reassign posts to a different user', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (23, 'view_email', 'Can view email and IP addresses of members', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (24, 'view_profiles', 'Can view profiles of members', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (25, 'view_members_list', 'Can view the members lists', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (26, 'bypass_math_question', 'Can bypass the math question', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (27, 'bypass_moderation', 'Can bypass all post moderation', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (28, 'bypass_moderation_once', 'Can bypass first post moderation', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (29, 'moderate_posts', 'Can moderate pending posts', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (30, 'use_spoilers', 'Can use spoilers in posts', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (31, 'view_links', 'Can view links within posts', 1, 0, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (32, 'use_signatures', 'Can attach a signature to posts', 1, 1, 0, 0, 1);
INSERT INTO `wp_sfauths` VALUES (33, 'upload_avatars', 'Can upload avatars', 1, 1, 1, 0, 1);
INSERT INTO `wp_sfauths` VALUES (34, 'create_links', 'Can create links in posts', 1, 0, 0, 0, 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfdefpermissions`
-- 

CREATE TABLE `wp_sfdefpermissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) NOT NULL DEFAULT '0',
  `usergroup_id` bigint(20) NOT NULL DEFAULT '0',
  `permission_role` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `group_idx` (`group_id`),
  KEY `usergroup_idx` (`usergroup_id`),
  KEY `perm_role_idx` (`permission_role`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Contenu de la table `wp_sfdefpermissions`
-- 

INSERT INTO `wp_sfdefpermissions` VALUES (1, 1, 1, 1);
INSERT INTO `wp_sfdefpermissions` VALUES (2, 1, 2, 5);
INSERT INTO `wp_sfdefpermissions` VALUES (3, 1, 3, 5);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sferrorlog`
-- 

CREATE TABLE `wp_sferrorlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `error_date` datetime NOT NULL,
  `error_type` varchar(10) NOT NULL,
  `error_text` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- Contenu de la table `wp_sferrorlog`
-- 

INSERT INTO `wp_sferrorlog` VALUES (1, '2013-03-17 12:12:39', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: closedir<br />Warning | closedir() expects parameter 1 to be resource, null given');
INSERT INTO `wp_sferrorlog` VALUES (2, '2013-03-17 12:12:40', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: Unavailable<br />Warning | closedir() expects parameter 1 to be resource, null given');
INSERT INTO `wp_sferrorlog` VALUES (3, '2013-03-17 12:30:16', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: closedir<br />Warning | closedir() expects parameter 1 to be resource, null given');
INSERT INTO `wp_sferrorlog` VALUES (4, '2013-03-17 12:30:18', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: Unavailable<br />Warning | closedir() expects parameter 1 to be resource, null given');
INSERT INTO `wp_sferrorlog` VALUES (5, '2013-03-17 12:30:24', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: closedir<br />Warning | closedir() expects parameter 1 to be resource, null given');
INSERT INTO `wp_sferrorlog` VALUES (6, '2013-03-17 12:30:25', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: Unavailable<br />Warning | closedir() expects parameter 1 to be resource, null given');
INSERT INTO `wp_sferrorlog` VALUES (7, '2013-05-08 20:50:56', 'database', 'file: /homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/simple-press/admin/panel-forums/support/spa-forums-save.php<br />line: 102<br />function: spdb_max<br />error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '''' at line 1<br /><br />SELECT MAX(forum_seq) FROM wp_sfforums WHERE group_id=');
INSERT INTO `wp_sferrorlog` VALUES (8, '2013-05-08 20:50:56', 'database', 'file: /homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/simple-press/admin/panel-forums/ahah/spa-ahah-forums-loader.php<br />line: 50<br />function: spa_save_forums_create_forum<br />error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' 0, 1, 0, '''', '''', '''', '''', 0, '''', '''')'' at line 1<br /><br />INSERT INTO wp_sfforums (forum_name, forum_slug, forum_desc, group_id, forum_status, forum_seq, forum_rss_private, forum_icon, forum_icon_new, topic_icon, topic_icon_new, parent, forum_message, keywords) VALUES (''Nouveau forum'', ''nouveau-forum'', '''', , 0, 1, 0, '''', '''', '''', '''', 0, '''', '''');');
INSERT INTO `wp_sferrorlog` VALUES (9, '2013-05-08 20:50:56', 'database', 'file: /homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/simple-press/admin/library/spa-support.php<br />line: 150<br />function: spdb_table<br />error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''AND usergroup_id=1'' at line 1<br /><br />SELECT  permission_role FROM wp_sfdefpermissions WHERE group_id= AND usergroup_id=1');
INSERT INTO `wp_sferrorlog` VALUES (10, '2013-05-08 20:50:56', 'database', 'file: /homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/simple-press/admin/library/spa-support.php<br />line: 150<br />function: spdb_table<br />error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''AND usergroup_id=2'' at line 1<br /><br />SELECT  permission_role FROM wp_sfdefpermissions WHERE group_id= AND usergroup_id=2');
INSERT INTO `wp_sferrorlog` VALUES (11, '2013-05-08 20:50:56', 'database', 'file: /homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/simple-press/admin/library/spa-support.php<br />line: 150<br />function: spdb_table<br />error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''AND usergroup_id=3'' at line 1<br /><br />SELECT  permission_role FROM wp_sfdefpermissions WHERE group_id= AND usergroup_id=3');
INSERT INTO `wp_sferrorlog` VALUES (12, '2013-05-08 20:50:56', 'database', 'file: /homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/simple-press/admin/library/spa-support.php<br />line: 16<br />function: spdb_table<br />error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''AND parent=0 ORDER BY forum_seq'' at line 1<br /><br />SELECT  * FROM wp_sfforums WHERE group_id= AND parent=0 ORDER BY forum_seq');
INSERT INTO `wp_sferrorlog` VALUES (13, '2013-05-08 21:07:19', 'database', 'file: /homepages/18/d454359170/htdocs/wordpress/wp-content/plugins/simple-press/admin/library/spa-support.php<br />line: 16<br />function: spdb_table<br />error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''AND parent=0 ORDER BY forum_seq'' at line 1<br /><br />SELECT  * FROM wp_sfforums WHERE group_id= AND parent=0 ORDER BY forum_seq');
INSERT INTO `wp_sferrorlog` VALUES (14, '2013-05-18 23:29:37', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: closedir<br />Warning | closedir(): supplied argument is not a valid Directory resource');
INSERT INTO `wp_sferrorlog` VALUES (15, '2013-09-27 14:11:05', 'php', 'file: /simple-press/sp-api/sp-api-plugins.php<br />line: 82<br />function: closedir<br />Warning | closedir(): supplied argument is not a valid Directory resource');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfforums`
-- 

CREATE TABLE `wp_sfforums` (
  `forum_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `forum_name` varchar(200) NOT NULL,
  `group_id` bigint(20) NOT NULL,
  `forum_seq` int(4) DEFAULT NULL,
  `forum_desc` text,
  `forum_status` int(4) NOT NULL DEFAULT '0',
  `forum_slug` varchar(200) NOT NULL,
  `forum_rss` text,
  `forum_icon` varchar(50) DEFAULT NULL,
  `forum_icon_new` varchar(50) DEFAULT NULL,
  `topic_icon` varchar(50) DEFAULT NULL,
  `topic_icon_new` varchar(50) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `post_id_held` bigint(20) DEFAULT NULL,
  `topic_count` mediumint(8) DEFAULT '0',
  `post_count` mediumint(8) DEFAULT '0',
  `post_count_held` mediumint(8) DEFAULT '0',
  `forum_rss_private` smallint(1) NOT NULL DEFAULT '0',
  `parent` bigint(20) NOT NULL DEFAULT '0',
  `children` text,
  `forum_message` text,
  `keywords` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`forum_id`),
  KEY `groupf_idx` (`group_id`),
  KEY `fslug_idx` (`forum_slug`),
  KEY `post_idx` (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Contenu de la table `wp_sfforums`
-- 

INSERT INTO `wp_sfforums` VALUES (1, 'Questions d''ordre général', 1, 1, 'recherche d''un groupe, recherche d''un nouveau membre pour son groupe ...', 0, 'questions-dordre-general', '', '', '', '', '', 14, 14, 4, 12, 12, 0, 0, '', '', '');
INSERT INTO `wp_sfforums` VALUES (2, 'Questions concernant un sujet', 1, 2, 'échanges d''idées sur un sujet', 0, 'questions-concernant-un-sujet', '', '', '', '', '', 3, 3, 1, 1, 1, 0, 0, '', '', '');
INSERT INTO `wp_sfforums` VALUES (3, 'Nouveau forum', 2, 1, '', 0, 'nouveau-forum', NULL, '', '', '', '', 15, 15, 1, 2, 2, 0, 0, '', '', '');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfgroups`
-- 

CREATE TABLE `wp_sfgroups` (
  `group_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_name` text,
  `group_seq` int(4) DEFAULT NULL,
  `group_desc` text,
  `group_rss` text,
  `group_icon` varchar(50) DEFAULT NULL,
  `group_message` text,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Contenu de la table `wp_sfgroups`
-- 

INSERT INTO `wp_sfgroups` VALUES (1, 'Entraide', 1, '', NULL, '', '');
INSERT INTO `wp_sfgroups` VALUES (2, 'Test', 2, '', NULL, '', '');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sflog`
-- 

CREATE TABLE `wp_sflog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `install_date` date NOT NULL,
  `release_type` varchar(20) DEFAULT NULL,
  `version` varchar(10) NOT NULL,
  `build` int(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Contenu de la table `wp_sflog`
-- 

INSERT INTO `wp_sflog` VALUES (1, 1, '2013-03-17', 'Released', '5.2.6', 9877);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sflogmeta`
-- 

CREATE TABLE `wp_sflogmeta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(10) DEFAULT NULL,
  `log_data` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_sflogmeta`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfmembers`
-- 

CREATE TABLE `wp_sfmembers` (
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `display_name` varchar(100) DEFAULT NULL,
  `moderator` smallint(1) NOT NULL DEFAULT '0',
  `avatar` longtext,
  `signature` text,
  `posts` int(4) DEFAULT NULL,
  `lastvisit` datetime DEFAULT NULL,
  `newposts` longtext,
  `checktime` datetime DEFAULT NULL,
  `admin` smallint(1) NOT NULL DEFAULT '0',
  `feedkey` varchar(36) DEFAULT NULL,
  `admin_options` longtext,
  `user_options` longtext,
  `auths` longtext,
  `memberships` longtext,
  `special_ranks` text,
  PRIMARY KEY (`user_id`),
  KEY `admin_idx` (`admin`),
  KEY `moderator_idx` (`moderator`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `wp_sfmembers`
-- 

INSERT INTO `wp_sfmembers` VALUES (1, 'admin', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 2, '2013-10-03 12:43:44', 'a:2:{s:6:"topics";a:5:{i:0;s:1:"6";i:1;s:1:"5";i:2;s:1:"4";i:3;s:1:"1";i:4;s:1:"2";}s:6:"forums";a:5:{i:0;s:1:"1";i:1;s:1:"3";i:2;s:1:"1";i:3;s:1:"1";i:4;s:1:"2";}}', '2013-10-03 12:22:38', 1, '27fe544f-d4d5-4534-a767-88df63c083bd', 'a:3:{s:8:"sfnotify";b:0;s:15:"sfstatusmsgtext";s:0:"";s:13:"notify-edited";b:1;}', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{i:1;a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}s:6:"global";a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}}', 'a:0:{}', NULL);
INSERT INTO `wp_sfmembers` VALUES (16, 'abdel', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 0, '2013-04-30 17:20:27', '', '2013-04-28 20:59:21', 0, '42ed2c46-def7-4571-b497-5bf1cc12c7c9', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (3, 'amel', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-28 17:46:57', '', '2013-04-28 12:35:52', 0, 'a2214802-6e06-4c1f-866a-cbb17b8ad770', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (4, 'ndeye mariane', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 1, '2013-04-29 23:24:10', 'a:2:{s:6:"topics";a:0:{}s:6:"forums";a:0:{}}', '2013-04-22 19:16:22', 0, '2eec90ec-0d62-4342-b108-35377d759844', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (5, 'mohamed amine', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-03-17 18:17:20', '', '2013-03-17 18:17:20', 0, '1fe505bd-d757-40b2-8213-d7b3a825034f', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (24, 'cherbonneau', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 0, '2013-10-03 11:42:51', 'a:2:{s:6:"topics";a:3:{i:0;s:1:"5";i:1;s:1:"1";i:2;s:1:"3";}s:6:"forums";a:3:{i:0;s:1:"3";i:1;s:1:"1";i:2;s:1:"1";}}', '2013-10-02 14:34:37', 1, '81b5a27d-6635-4fe4-9659-557a746590e9', 'a:2:{s:8:"sfnotify";b:0;s:15:"sfstatusmsgtext";s:0:"";}', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{i:1;a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}s:6:"global";a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;}}', 'a:0:{}', NULL);
INSERT INTO `wp_sfmembers` VALUES (7, 'encadrant', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-05-20 08:34:07', '', '2013-04-28 12:20:16', 0, 'c897097b-a84c-4309-917a-6186ae3cc31b', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (8, 'abdd.diallo25', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-03-26 11:27:31', '', '2013-03-26 11:27:31', 0, 'f689ebdf-1b62-40ab-9d27-93e3706d9ee4', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (9, 'admin5', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 02:26:57', '', '2013-04-14 10:10:13', 0, '6d76cff6-375c-4c49-a03d-9ca3f5152325', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (10, 'diallo5', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-25 08:42:57', '', '2013-04-25 08:42:57', 0, 'aeab092d-11a3-415e-8e33-d3775c299898', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (17, 'netsoro', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 02:26:17', '', '2013-04-28 21:43:42', 0, '50e6d4c1-b8a6-4690-9fc5-fb644c513afb', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (15, 'etu', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 2, '2013-05-20 08:24:37', 'a:2:{s:6:"topics";a:0:{}s:6:"forums";a:0:{}}', '2013-05-20 08:23:52', 0, '0e602cdf-ffc4-4ec0-9cf0-cc0b31d51886', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (13, 'dial', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-28 18:15:14', '', '2013-04-28 18:15:14', 0, '0fdf7d51-369d-432d-a43c-5a5dfe0956d2', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (14, 'cool1', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-28 23:55:27', '', '2013-04-28 18:38:48', 0, '679e997d-0da3-48cf-ad03-833076b81b06', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (18, 'testt', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 00:58:56', '', '2013-04-29 00:58:56', 0, 'e76ef184-34b8-449e-8976-36625885f632', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (19, 'test12', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 00:02:23', '', '2013-04-29 00:02:23', 0, 'b103b05b-495c-48cf-aab1-f255f4b7adbd', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (20, 'diallo252', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 02:29:07', '', '2013-04-29 02:29:07', 0, '89ac295a-623a-47af-b6b2-b9a5dad3f7a0', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (21, 'dada', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 03:07:53', '', '2013-04-29 03:07:53', 0, 'e1b828cc-d6be-46ac-a6bf-bc2cf5cffcf0', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (22, 'Etu1', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 08:19:34', '', '2013-04-29 08:19:34', 0, 'be0ef443-59e5-4ad2-a671-ceff79ecce98', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (23, 'ups', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-04-29 11:06:01', '', '2013-04-29 11:06:01', 0, '43e7dc0a-3ebc-48e9-bb53-85eaf39ec278', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (25, 'louhidi', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-05-19 18:18:22', '', '2013-05-19 18:17:48', 0, '5644343f-cb7e-4882-afff-1427eb9b2b20', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (26, 'louhidi2', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-05-20 08:15:52', '', '2013-05-19 18:29:05', 0, 'fd9893a4-30a8-42b9-9676-096757212e69', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (27, 'etu2', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-05-20 08:27:27', '', '2013-05-20 08:17:40', 0, 'e2e2fc6f-ecff-4c9a-b91d-5c4c95c651a9', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (28, 'duijj', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-05-20 09:36:46', '', '2013-05-20 09:36:46', 0, '902c64b6-ec5a-4bd3-95d4-e6ac997b0e82', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (29, 'Kevin', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 0, '2013-10-02 14:59:51', 'a:2:{s:6:"topics";a:2:{i:0;s:1:"5";i:1;s:1:"6";}s:6:"forums";a:2:{i:0;s:1:"3";i:1;s:1:"1";}}', '2013-10-03 16:18:40', 0, '2a98ee3d-4031-4cde-ade1-c2cc10fa628c', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (30, 'Damien', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:34:47', '', '2013-09-27 11:34:47', 0, '89cb1508-458c-4000-9e1b-b89a945def1e', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (66, 'frank', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 0, '2013-10-03 12:43:44', 'a:2:{s:6:"topics";a:2:{i:0;s:1:"5";i:1;s:1:"6";}s:6:"forums";a:2:{i:0;s:1:"3";i:1;s:1:"1";}}', '2013-10-03 12:43:44', 0, 'fd70de36-d3f8-4722-b984-30a410624f6c', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (32, 'Benjamin', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-10-03 12:16:36', '', '2013-10-03 12:07:45', 0, '4bbcc683-5c7b-43e4-9fae-3af448d997a0', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (33, 'Julien', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 0, '2013-10-03 12:36:25', 'a:2:{s:6:"topics";a:4:{i:0;s:1:"6";i:1;s:1:"5";i:2;s:1:"4";i:3;s:1:"1";}s:6:"forums";a:4:{i:0;s:1:"1";i:1;s:1:"3";i:2;s:1:"1";i:3;s:1:"1";}}', '2013-10-03 12:36:25', 0, 'cec09ba8-1c44-4e84-9384-93c47a6db049', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (34, 'Remi', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 12:11:09', '', '2013-09-27 12:11:09', 0, '32cb843d-340e-4591-8390-f2a817e58eb0', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (35, 'Nathanael', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:34:51', '', '2013-09-27 11:34:51', 0, 'a171cb70-7937-4e9f-93fb-30e0efd162a1', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (36, 'Mehdi', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 0, '2013-10-03 12:28:53', 'a:2:{s:6:"topics";a:4:{i:0;s:1:"6";i:1;s:1:"5";i:2;s:1:"4";i:3;s:1:"1";}s:6:"forums";a:4:{i:0;s:1:"1";i:1;s:1:"3";i:2;s:1:"1";i:3;s:1:"1";}}', '2013-10-03 12:21:41', 0, 'ad5e2e18-d70a-4826-b362-a5744da69329', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (37, 'Alexandru', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 1, '2013-10-03 16:18:40', 'a:2:{s:6:"topics";a:2:{i:0;s:1:"5";i:1;s:1:"4";}s:6:"forums";a:2:{i:0;s:1:"3";i:1;s:1:"1";}}', '2013-10-03 12:36:52', 0, 'a3d3fa79-f353-41d3-8cd6-ba23ee6e3ca2', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (38, 'Robin', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:34:55', '', '2013-09-27 11:34:55', 0, '6c20645a-2def-4c18-9a9c-a659ec3bbbe1', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (39, 'Vincent', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:34:56', '', '2013-09-27 11:34:56', 0, '1259a651-f679-4dd6-aa59-64a73e70173c', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (40, 'Virgil', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-10-02 14:25:23', '', '2013-09-27 12:34:24', 0, 'bb6caad3-fa3b-441d-98f6-580db010dbb2', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (41, 'Florian', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 1, '2013-10-03 16:18:40', 'a:2:{s:6:"topics";a:3:{i:0;s:1:"6";i:1;s:1:"4";i:2;s:1:"1";}s:6:"forums";a:3:{i:0;s:1:"1";i:1;s:1:"1";i:2;s:1:"1";}}', '2013-10-03 16:18:40', 0, '739ba5bc-db82-4d8c-bcf3-59fea0383934', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (42, 'Loic', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 4, '2013-10-03 11:42:51', 'a:2:{s:6:"topics";a:3:{i:0;s:1:"5";i:1;s:1:"4";i:2;s:1:"1";}s:6:"forums";a:3:{i:0;s:1:"3";i:1;s:1:"1";i:2;s:1:"1";}}', '2013-10-02 14:22:23', 0, '2dd1aeab-25a6-4e29-a984-f4f4e2abaa07', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (43, 'Jordan', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 2, '2013-10-02 14:11:07', 'a:2:{s:6:"topics";a:3:{i:0;s:1:"5";i:1;s:1:"4";i:2;s:1:"1";}s:6:"forums";a:3:{i:0;s:1:"3";i:1;s:1:"1";i:2;s:1:"1";}}', '2013-09-27 12:44:30', 0, '78346143-57f2-4ebc-8694-50a56bd5862b', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (44, 'Alexandra', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:04', '', '2013-09-27 11:35:04', 0, 'eb956892-8eb1-4924-946d-a963e2d5fdde', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (45, 'Oudom', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 1, '2013-10-03 16:18:40', 'a:2:{s:6:"topics";a:4:{i:0;s:1:"5";i:1;s:1:"6";i:2;s:1:"4";i:3;s:1:"1";}s:6:"forums";a:4:{i:0;s:1:"3";i:1;s:1:"1";i:2;s:1:"1";i:3;s:1:"1";}}', '2013-10-03 12:55:49', 0, '83d85cc2-865c-4d00-ab86-f5f54446a378', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (46, 'Florent', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 1, '2013-09-27 12:51:41', 'a:2:{s:6:"topics";a:1:{i:0;s:1:"1";}s:6:"forums";a:1:{i:0;s:1:"1";}}', '2013-09-27 12:51:41', 0, 'd016f9ca-2960-43ab-b1f7-42f337234bc7', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (47, 'Mohammed akram', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:06', '', '2013-09-27 11:35:06', 0, '872d8d17-7cb2-452f-89a7-bc36be52ab9d', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (48, 'Axel', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:07', '', '2013-09-27 11:35:07', 0, '57be48bc-4aea-4982-a435-649285d45b2c', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (49, 'Dorian', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:07', '', '2013-09-27 11:35:07', 0, '6fb8d625-7f8d-4660-8745-8f282b140b72', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (50, 'Vivian', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:08', '', '2013-09-27 11:35:08', 0, '0c217a10-7639-41aa-be8c-55c5c37ce482', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (51, 'Ismail', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:09', '', '2013-09-27 11:35:09', 0, 'abb65b0f-af06-43f4-bfce-e944e180f0d7', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (52, 'Jeremy', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:09', '', '2013-09-27 11:35:09', 0, '8e4e0d77-5b59-4878-a452-32edc58af0dc', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (53, 'Andrea', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 12:34:42', '', '2013-09-27 12:34:42', 0, '0f18800d-2e24-4a63-9f75-f0148b2d2a18', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (54, 'Xavier', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:35:11', '', '2013-09-27 11:35:11', 0, '28134811-2066-4a19-9060-ddcfb85d294c', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (55, 'Laurent', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-10-03 12:03:35', '', '2013-10-02 14:59:51', 0, '9b8c9ffe-110c-492b-a5d6-e5c316b3061a', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (56, 'group1', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 13:13:53', '', '2013-09-27 13:13:53', 0, 'd309f08e-de73-4737-9a54-07a2a0a63dd0', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (57, 'group2', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:53:44', '', '2013-09-27 11:53:44', 0, '9896fd29-e880-43e6-b5d2-86d3c793ff54', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (58, 'group3', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:55:30', '', '2013-09-27 11:55:30', 0, 'f161df8f-b65d-4afb-bc92-f5c0da28de49', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (59, 'group4', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 12:01:14', '', '2013-09-27 12:01:14', 0, 'e7e1df46-4421-4c43-b9d4-b05b7432acb2', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (60, 'group5', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 12:02:24', '', '2013-09-27 12:02:24', 0, '7322873e-b1cb-4ff8-8514-b738ad0e93d6', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (61, 'SecondLoic', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-09-27 11:45:26', '', '2013-09-27 11:43:32', 0, 'a7d3f619-dcbe-4114-a86b-ab92d6441262', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (63, 'vincent', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', 0, '2013-10-03 12:01:49', 'a:2:{s:6:"topics";a:2:{i:0;s:1:"1";i:1;s:1:"4";}s:6:"forums";a:2:{i:0;s:1:"1";i:1;s:1:"1";}}', '2013-10-02 14:11:07', 0, 'da46f150-1660-43ae-bb30-3eb878879d08', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";i:0;s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', 'a:4:{s:6:"global";a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:1;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:2;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}i:3;a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}}', 'a:1:{i:0;a:5:{s:12:"usergroup_id";s:1:"2";s:14:"usergroup_name";s:7:"Members";s:14:"usergroup_desc";s:51:"Default Usergroup for registered users of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";}}', NULL);
INSERT INTO `wp_sfmembers` VALUES (64, 'kevinS', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-10-02 15:17:08', '', '2013-10-02 15:17:08', 0, '3bf7d1c7-c2ea-4ff8-a3f0-1a78632a184d', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);
INSERT INTO `wp_sfmembers` VALUES (65, 'nouveau', 0, 'a:1:{s:8:"uploaded";s:0:"";}', '', -1, '2013-10-02 15:28:10', '', '2013-10-02 15:28:10', 0, '56a99dea-bdd7-4275-8290-c54e0c39f18c', '', 'a:6:{s:10:"hidestatus";i:0;s:8:"timezone";s:1:"1";s:15:"timezone_string";s:3:"UTC";s:6:"editor";i:1;s:8:"namesync";i:1;s:11:"unreadposts";i:50;}', '', '', NULL);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfmemberships`
-- 

CREATE TABLE `wp_sfmemberships` (
  `membership_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `usergroup_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`membership_id`),
  KEY `user_idx` (`user_id`),
  KEY `usergroup_idx` (`usergroup_id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

-- 
-- Contenu de la table `wp_sfmemberships`
-- 

INSERT INTO `wp_sfmemberships` VALUES (16, 16, 2);
INSERT INTO `wp_sfmemberships` VALUES (3, 3, 2);
INSERT INTO `wp_sfmemberships` VALUES (4, 4, 2);
INSERT INTO `wp_sfmemberships` VALUES (5, 5, 2);
INSERT INTO `wp_sfmemberships` VALUES (7, 7, 2);
INSERT INTO `wp_sfmemberships` VALUES (8, 8, 2);
INSERT INTO `wp_sfmemberships` VALUES (9, 9, 2);
INSERT INTO `wp_sfmemberships` VALUES (10, 10, 2);
INSERT INTO `wp_sfmemberships` VALUES (17, 17, 2);
INSERT INTO `wp_sfmemberships` VALUES (15, 15, 2);
INSERT INTO `wp_sfmemberships` VALUES (13, 13, 2);
INSERT INTO `wp_sfmemberships` VALUES (14, 14, 2);
INSERT INTO `wp_sfmemberships` VALUES (18, 18, 2);
INSERT INTO `wp_sfmemberships` VALUES (19, 19, 2);
INSERT INTO `wp_sfmemberships` VALUES (20, 20, 2);
INSERT INTO `wp_sfmemberships` VALUES (21, 21, 2);
INSERT INTO `wp_sfmemberships` VALUES (22, 22, 2);
INSERT INTO `wp_sfmemberships` VALUES (23, 23, 2);
INSERT INTO `wp_sfmemberships` VALUES (27, 25, 2);
INSERT INTO `wp_sfmemberships` VALUES (28, 26, 2);
INSERT INTO `wp_sfmemberships` VALUES (29, 27, 2);
INSERT INTO `wp_sfmemberships` VALUES (30, 28, 2);
INSERT INTO `wp_sfmemberships` VALUES (32, 29, 2);
INSERT INTO `wp_sfmemberships` VALUES (33, 30, 2);
INSERT INTO `wp_sfmemberships` VALUES (69, 66, 2);
INSERT INTO `wp_sfmemberships` VALUES (35, 32, 2);
INSERT INTO `wp_sfmemberships` VALUES (36, 33, 2);
INSERT INTO `wp_sfmemberships` VALUES (37, 34, 2);
INSERT INTO `wp_sfmemberships` VALUES (38, 35, 2);
INSERT INTO `wp_sfmemberships` VALUES (39, 36, 2);
INSERT INTO `wp_sfmemberships` VALUES (40, 37, 2);
INSERT INTO `wp_sfmemberships` VALUES (41, 38, 2);
INSERT INTO `wp_sfmemberships` VALUES (42, 39, 2);
INSERT INTO `wp_sfmemberships` VALUES (43, 40, 2);
INSERT INTO `wp_sfmemberships` VALUES (44, 41, 2);
INSERT INTO `wp_sfmemberships` VALUES (45, 42, 2);
INSERT INTO `wp_sfmemberships` VALUES (46, 43, 2);
INSERT INTO `wp_sfmemberships` VALUES (47, 44, 2);
INSERT INTO `wp_sfmemberships` VALUES (48, 45, 2);
INSERT INTO `wp_sfmemberships` VALUES (49, 46, 2);
INSERT INTO `wp_sfmemberships` VALUES (50, 47, 2);
INSERT INTO `wp_sfmemberships` VALUES (51, 48, 2);
INSERT INTO `wp_sfmemberships` VALUES (52, 49, 2);
INSERT INTO `wp_sfmemberships` VALUES (53, 50, 2);
INSERT INTO `wp_sfmemberships` VALUES (54, 51, 2);
INSERT INTO `wp_sfmemberships` VALUES (55, 52, 2);
INSERT INTO `wp_sfmemberships` VALUES (56, 53, 2);
INSERT INTO `wp_sfmemberships` VALUES (57, 54, 2);
INSERT INTO `wp_sfmemberships` VALUES (58, 55, 2);
INSERT INTO `wp_sfmemberships` VALUES (59, 56, 2);
INSERT INTO `wp_sfmemberships` VALUES (60, 57, 2);
INSERT INTO `wp_sfmemberships` VALUES (61, 58, 2);
INSERT INTO `wp_sfmemberships` VALUES (62, 59, 2);
INSERT INTO `wp_sfmemberships` VALUES (63, 60, 2);
INSERT INTO `wp_sfmemberships` VALUES (64, 61, 2);
INSERT INTO `wp_sfmemberships` VALUES (66, 63, 2);
INSERT INTO `wp_sfmemberships` VALUES (67, 64, 2);
INSERT INTO `wp_sfmemberships` VALUES (68, 65, 2);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfmeta`
-- 

CREATE TABLE `wp_sfmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `meta_type` varchar(20) NOT NULL,
  `meta_key` varchar(100) DEFAULT NULL,
  `meta_value` longtext,
  `autoload` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`meta_id`),
  KEY `meta_type_idx` (`meta_type`),
  KEY `autoload_idx` (`autoload`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- 
-- Contenu de la table `wp_sfmeta`
-- 

INSERT INTO `wp_sfmeta` VALUES (1, 'default usergroup', 'sfguests', '1', 0);
INSERT INTO `wp_sfmeta` VALUES (2, 'default usergroup', 'sfmembers', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (3, 'default usergroup', 'administrator', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (4, 'default usergroup', 'editor', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (5, 'default usergroup', 'author', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (6, 'default usergroup', 'contributor', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (7, 'default usergroup', 'subscriber', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (8, 'default usergroup', 'etudiant', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (9, 'default usergroup', 'encadrant', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (10, 'default usergroup', 'responsableue', '2', 0);
INSERT INTO `wp_sfmeta` VALUES (11, 'forum_rank', 'New Member', 'a:3:{s:5:"posts";i:2;s:9:"usergroup";s:4:"none";s:5:"image";s:4:"none";}', 1);
INSERT INTO `wp_sfmeta` VALUES (12, 'forum_rank', 'Member', 'a:3:{s:5:"posts";i:1000;s:9:"usergroup";s:4:"none";s:5:"image";s:4:"none";}', 1);
INSERT INTO `wp_sfmeta` VALUES (13, 'sort_order', 'forum', '', 1);
INSERT INTO `wp_sfmeta` VALUES (14, 'sort_order', 'topic', '', 1);
INSERT INTO `wp_sfmeta` VALUES (15, 'autoupdate', 'user', 'a:2:{i:0;s:13:"spjUserUpdate";i:1;s:78:"http://www.gdnlteamtest.netsoro.net/wordpress/index.php?sp_ahah=autoupdate&amp;sfnonce=142d8b8870";}', 0);
INSERT INTO `wp_sfmeta` VALUES (16, 'smileys', 'smileys', 'a:11:{s:8:"Confused";a:5:{i:0;s:15:"sf-confused.gif";i:1;s:5:":???:";i:2;i:1;i:3;i:0;i:4;i:0;}s:4:"Cool";a:5:{i:0;s:11:"sf-cool.gif";i:1;s:6:":cool:";i:2;i:1;i:3;i:1;i:4;i:0;}s:3:"Cry";a:5:{i:0;s:10:"sf-cry.gif";i:1;s:5:":cry:";i:2;i:1;i:3;i:2;i:4;i:0;}s:10:"Embarassed";a:5:{i:0;s:17:"sf-embarassed.gif";i:1;s:6:":oops:";i:2;i:1;i:3;i:3;i:4;i:0;}s:5:"Frown";a:5:{i:0;s:12:"sf-frown.gif";i:1;s:7:":frown:";i:2;i:1;i:3;i:4;i:4;i:0;}s:4:"Kiss";a:5:{i:0;s:11:"sf-kiss.gif";i:1;s:6:":kiss:";i:2;i:1;i:3;i:5;i:4;i:0;}s:5:"Laugh";a:5:{i:0;s:12:"sf-laugh.gif";i:1;s:5:":lol:";i:2;i:1;i:3;i:6;i:4;i:0;}s:5:"Smile";a:5:{i:0;s:12:"sf-smile.gif";i:1;s:7:":smile:";i:2;i:1;i:3;i:7;i:4;i:0;}s:9:"Surprised";a:5:{i:0;s:16:"sf-surprised.gif";i:1;s:5:":eek:";i:2;i:1;i:3;i:8;i:4;i:0;}s:4:"Wink";a:5:{i:0;s:11:"sf-wink.gif";i:1;s:6:":wink:";i:2;i:1;i:3;i:9;i:4;i:0;}s:4:"Yell";a:5:{i:0;s:11:"sf-yell.gif";i:1;s:6:":yell:";i:2;i:1;i:3;i:10;i:4;i:0;}}', 1);
INSERT INTO `wp_sfmeta` VALUES (17, 'profile', 'tabs', 'a:4:{i:0;a:5:{s:4:"name";s:7:"Profile";s:4:"slug";s:7:"profile";s:7:"display";i:1;s:4:"auth";s:0:"";s:5:"menus";a:7:{i:0;a:5:{s:4:"name";s:8:"Overview";s:4:"slug";s:8:"overview";s:4:"form";s:94:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-overview.php";s:7:"display";i:1;s:4:"auth";s:0:"";}i:1;a:5:{s:4:"name";s:12:"Edit Profile";s:4:"slug";s:12:"edit-profile";s:4:"form";s:93:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-profile.php";s:7:"display";i:1;s:4:"auth";s:0:"";}i:2;a:5:{s:4:"name";s:15:"Edit Identities";s:4:"slug";s:15:"edit-identities";s:4:"form";s:96:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-identities.php";s:7:"display";i:1;s:4:"auth";s:0:"";}i:3;a:5:{s:4:"name";s:11:"Edit Avatar";s:4:"slug";s:11:"edit-avatar";s:4:"form";s:92:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-avatar.php";s:7:"display";i:1;s:4:"auth";s:0:"";}i:4;a:5:{s:4:"name";s:14:"Edit Signature";s:4:"slug";s:14:"edit-signature";s:4:"form";s:95:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-signature.php";s:7:"display";i:1;s:4:"auth";s:14:"use_signatures";}i:5;a:5:{s:4:"name";s:11:"Edit Photos";s:4:"slug";s:11:"edit-photos";s:4:"form";s:92:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-photos.php";s:7:"display";i:1;s:4:"auth";s:0:"";}i:6;a:5:{s:4:"name";s:16:"Account Settings";s:4:"slug";s:16:"account-settings";s:4:"form";s:93:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-account.php";s:7:"display";i:1;s:4:"auth";s:0:"";}}}i:1;a:5:{s:4:"name";s:7:"Options";s:4:"slug";s:7:"options";s:7:"display";i:1;s:4:"auth";s:0:"";s:5:"menus";a:3:{i:0;a:5:{s:4:"name";s:19:"Edit Global Options";s:4:"slug";s:19:"edit-global-options";s:4:"form";s:100:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-global-options.php";s:7:"display";i:1;s:4:"auth";s:0:"";}i:1;a:5:{s:4:"name";s:20:"Edit Posting Options";s:4:"slug";s:20:"edit-posting-options";s:4:"form";s:101:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-posting-options.php";s:7:"display";i:1;s:4:"auth";s:0:"";}i:2;a:5:{s:4:"name";s:20:"Edit Display Options";s:4:"slug";s:20:"edit-display-options";s:4:"form";s:101:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-display-options.php";s:7:"display";i:1;s:4:"auth";s:0:"";}}}i:2;a:5:{s:4:"name";s:10:"Usergroups";s:4:"slug";s:10:"usergroups";s:7:"display";i:1;s:4:"auth";s:0:"";s:5:"menus";a:1:{i:0;a:5:{s:4:"name";s:16:"Show Memberships";s:4:"slug";s:16:"show-memberships";s:4:"form";s:97:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-memberships.php";s:7:"display";i:1;s:4:"auth";s:0:"";}}}i:3;a:5:{s:4:"name";s:11:"Permissions";s:4:"slug";s:11:"permissions";s:7:"display";i:1;s:4:"auth";s:0:"";s:5:"menus";a:1:{i:0;a:5:{s:4:"name";s:16:"Show Permissions";s:4:"slug";s:16:"show-permissions";s:4:"form";s:97:"C:/wamp/www/wordpress/wp-content/plugins/simple-press/forum/profile/forms/sp-form-permissions.php";s:7:"display";i:1;s:4:"auth";s:0:"";}}}}', 0);
INSERT INTO `wp_sfmeta` VALUES (18, 'news', 'news', 'a:3:{s:2:"id";s:2:"13";s:4:"show";i:1;s:4:"news";s:572:"\n        \n        <h4><b>Announcing Release of a New Plugin</b></h4>\n        <p>Now available to download - the following new plugin is now released and available for use on your Simple:Press forum. Thd plugin does require Version 5.3.4 of Simple Press.</p>\n        <p><b>Warnings and Suspensions</b>: Allows for for warning, susupending and banning users</p>\n        <p>Just download, install, activate and add any necessary template display tags to your theme. Available on our Plugins Download Page:  http://simple-press.com/download-plugins/</a>.</p>\n        \n        ";}', 0);
INSERT INTO `wp_sfmeta` VALUES (19, 'mysql', 'search', 'a:2:{s:3:"min";s:1:"4";s:3:"max";s:2:"84";}', 1);
INSERT INTO `wp_sfmeta` VALUES (20, 'forum_moderators', 'users', 'a:3:{i:1;a:0:{}i:2;a:0:{}i:3;a:0:{}}', 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfnotices`
-- 

CREATE TABLE `wp_sfnotices` (
  `notice_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `guest_email` varchar(50) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_text` varchar(200) DEFAULT NULL,
  `message` varchar(255) NOT NULL DEFAULT '',
  `expires` int(4) DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_sfnotices`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfoptions`
-- 

CREATE TABLE `wp_sfoptions` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  PRIMARY KEY (`option_name`),
  KEY `option_id` (`option_id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

-- 
-- Contenu de la table `wp_sfoptions`
-- 

INSERT INTO `wp_sfoptions` VALUES (1, 'installed_tables', 'a:20:{i:0;s:11:"wp_sfforums";i:1;s:11:"wp_sfgroups";i:2;s:12:"wp_sfmembers";i:3;s:12:"wp_sfoptions";i:4;s:16:"wp_sfmemberships";i:5;s:9:"wp_sfmeta";i:6;s:16:"wp_sfpermissions";i:7;s:19:"wp_sfdefpermissions";i:8;s:10:"wp_sfposts";i:9;s:10:"wp_sfauths";i:10;s:13:"wp_sfauthcats";i:11;s:10:"wp_sfroles";i:12;s:11:"wp_sftopics";i:13;s:10:"wp_sftrack";i:14;s:15:"wp_sfusergroups";i:15;s:12:"wp_sfwaiting";i:16;s:8:"wp_sflog";i:17;s:12:"wp_sflogmeta";i:18;s:13:"wp_sferrorlog";i:19;s:12:"wp_sfnotices";}');
INSERT INTO `wp_sfoptions` VALUES (2, 'sf_guest_auths', 'a:4:{s:6:"global";a:34:{i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:0;i:25;i:0;i:26;i:0;i:27;i:0;i:28;i:0;i:32;i:0;i:33;i:0;i:30;i:0;i:31;i:0;i:29;i:0;i:34;i:0;}i:1;a:34:{i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:0;i:25;i:0;i:26;i:0;i:27;i:0;i:28;i:0;i:32;i:0;i:33;i:0;i:30;i:0;i:31;i:0;i:29;i:0;i:34;i:0;}i:2;a:34:{i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:0;i:25;i:0;i:26;i:0;i:27;i:0;i:28;i:0;i:32;i:0;i:33;i:0;i:30;i:0;i:31;i:0;i:29;i:0;i:34;i:0;}i:3;a:34:{i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:0;i:25;i:0;i:26;i:0;i:27;i:0;i:28;i:0;i:32;i:0;i:33;i:0;i:30;i:0;i:31;i:0;i:29;i:0;i:34;i:0;}}');
INSERT INTO `wp_sfoptions` VALUES (3, 'sfslug', '?page_id=100');
INSERT INTO `wp_sfoptions` VALUES (4, 'sfpage', '100');
INSERT INTO `wp_sfoptions` VALUES (5, 'sfuninstall', '');
INSERT INTO `wp_sfoptions` VALUES (6, 'sfdates', 'j F Y');
INSERT INTO `wp_sfoptions` VALUES (7, 'sftimes', 'G \\h i \\m\\i\\n');
INSERT INTO `wp_sfoptions` VALUES (8, 'sfpermalink', 'http://www.gdnlteamtest.netsoro.net/wordpress?page_id=100');
INSERT INTO `wp_sfoptions` VALUES (9, 'sflockdown', '');
INSERT INTO `wp_sfoptions` VALUES (10, 'sfimage', 'a:6:{s:7:"enlarge";b:1;s:7:"process";b:1;s:9:"thumbsize";i:100;s:5:"style";s:4:"left";s:9:"constrain";b:1;s:10:"forceclear";b:0;}');
INSERT INTO `wp_sfoptions` VALUES (11, 'sfbadwords', '');
INSERT INTO `wp_sfoptions` VALUES (12, 'sfreplacementwords', '');
INSERT INTO `wp_sfoptions` VALUES (13, 'sfeditormsg', '');
INSERT INTO `wp_sfoptions` VALUES (14, 'sfmail', 'a:4:{s:12:"sfmailsender";s:34:"Site UE Projet M1 Informatique UPS";s:10:"sfmailfrom";s:8:"gdnlteam";s:12:"sfmaildomain";s:9:"gmail.com";s:9:"sfmailuse";b:1;}');
INSERT INTO `wp_sfoptions` VALUES (15, 'sfnewusermail', 'a:3:{s:11:"sfusespfreg";b:1;s:16:"sfnewusersubject";s:21:"Welcome to %BLOGNAME%";s:13:"sfnewusertext";s:159:"Welcome %USERNAME% to %BLOGNAME% %NEWLINE%Please find below your login details: %NEWLINE%Username: %USERNAME% %NEWLINE%Password: %PASSWORD% %NEWLINE%%LOGINURL%";}');
INSERT INTO `wp_sfoptions` VALUES (16, 'sfpostmsg', 'a:3:{s:13:"sfpostmsgtext";s:0:"";s:14:"sfpostmsgtopic";b:0;s:13:"sfpostmsgpost";b:0;}');
INSERT INTO `wp_sfoptions` VALUES (17, 'sflogin', 'a:6:{s:9:"sfregmath";b:1;s:10:"sfloginurl";s:39:"http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=100";s:11:"sflogouturl";s:39:"http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=100";s:13:"sfregisterurl";s:0:"";s:15:"sfloginemailurl";s:51:"http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=67&action=login";s:9:"sptimeout";i:20;}');
INSERT INTO `wp_sfoptions` VALUES (18, 'sfadminsettings', 'a:5:{s:16:"sfdashboardstats";b:0;s:14:"sfadminapprove";b:0;s:14:"sfmoderapprove";b:0;s:10:"editnotice";b:1;s:10:"movenotice";b:1;}');
INSERT INTO `wp_sfoptions` VALUES (19, 'sfauto', 'a:2:{s:12:"sfautoupdate";b:0;s:10:"sfautotime";i:300;}');
INSERT INTO `wp_sfoptions` VALUES (20, 'sffilters', 'a:8:{s:10:"sfnofollow";b:0;s:8:"sftarget";b:1;s:10:"sfurlchars";i:40;s:11:"sffilterpre";b:0;s:10:"sfmaxlinks";i:0;s:12:"sfnolinksmsg";s:55:"<b>** you don''t have permission to see this link **</b>";s:12:"sfdupemember";i:0;s:11:"sfdupeguest";i:0;}');
INSERT INTO `wp_sfoptions` VALUES (21, 'sfsmileys', '1');
INSERT INTO `wp_sfoptions` VALUES (22, 'sfseo', 'a:8:{s:15:"sfseo_overwrite";b:0;s:14:"sfseo_blogname";b:0;s:14:"sfseo_pagename";b:0;s:11:"sfseo_topic";b:1;s:11:"sfseo_forum";b:1;s:13:"sfseo_noforum";b:0;s:10:"sfseo_page";b:1;s:9:"sfseo_sep";s:1:"|";}');
INSERT INTO `wp_sfoptions` VALUES (23, 'sfsigimagesize', 'a:2:{s:10:"sfsigwidth";i:0;s:11:"sfsigheight";i:0;}');
INSERT INTO `wp_sfoptions` VALUES (24, 'sfmemberopts', 'a:3:{s:16:"sfcheckformember";b:1;s:18:"sfsinglemembership";b:0;s:12:"sfhidestatus";b:1;}');
INSERT INTO `wp_sfoptions` VALUES (25, 'sfcontrols', 'a:6:{s:9:"fourofour";b:0;s:12:"showtopcount";i:10;s:12:"shownewcount";i:10;s:16:"sfdefunreadposts";i:50;s:13:"sfusersunread";b:0;s:16:"sfmaxunreadposts";i:50;}');
INSERT INTO `wp_sfoptions` VALUES (26, 'sfblockadmin', 'a:3:{s:10:"blockadmin";b:0;s:10:"blockroles";s:13:"administrator";s:13:"blockredirect";s:39:"http://www.gdnlteamtest.netsoro.net/wordpress/?page_id=100";}');
INSERT INTO `wp_sfoptions` VALUES (27, 'sfmetatags', 'a:4:{s:7:"sfdescr";s:0:"";s:10:"sfdescruse";i:1;s:13:"sfusekeywords";i:2;s:8:"keywords";s:5:"forum";}');
INSERT INTO `wp_sfoptions` VALUES (28, 'sfdisplay', 'a:4:{s:9:"pagetitle";a:2:{s:7:"notitle";b:0;s:6:"banner";s:0:"";}s:6:"forums";a:1:{s:11:"singleforum";b:0;}s:6:"topics";a:2:{s:7:"perpage";i:12;s:10:"sortnewtop";b:1;}s:5:"posts";a:2:{s:7:"perpage";i:20;s:8:"sortdesc";b:0;}}');
INSERT INTO `wp_sfoptions` VALUES (29, 'sfguests', 'a:2:{s:8:"reqemail";b:1;s:11:"storecookie";b:1;}');
INSERT INTO `wp_sfoptions` VALUES (30, 'sfprofile', 'a:17:{s:10:"nameformat";b:1;s:18:"fixeddisplayformat";i:0;s:11:"profilelink";i:3;s:7:"weblink";i:3;s:11:"displaymode";i:1;s:11:"displaypage";s:0:"";s:12:"displayquery";s:0:"";s:8:"formmode";i:1;s:8:"formpage";s:0:"";s:9:"formquery";s:0:"";s:9:"photosmax";i:0;s:11:"photoswidth";i:0;s:12:"photosheight";i:0;s:10:"firstvisit";b:1;s:7:"forcepw";b:0;s:14:"profileinstats";b:1;s:13:"sfprofiletext";s:162:"Welcome to the User Profile Overview Panel. From here you can view and update your profile and options as well as view your Usergroup Memberships and Permissions.";}');
INSERT INTO `wp_sfoptions` VALUES (31, 'sfavatars', 'a:10:{s:13:"sfshowavatars";b:1;s:15:"sfavataruploads";b:1;s:12:"sfavatarpool";b:0;s:14:"sfavatarremote";b:0;s:12:"sfgmaxrating";i:1;s:12:"sfavatarsize";i:50;s:14:"sfavatarresize";b:1;s:21:"sfavatarresizequality";i:90;s:16:"sfavatarfilesize";i:10240;s:16:"sfavatarpriority";a:6:{i:0;i:0;i:1;i:2;i:2;i:3;i:3;i:1;i:4;i:4;i:5;i:5;}}');
INSERT INTO `wp_sfoptions` VALUES (32, 'sfrss', 'a:4:{s:10:"sfrsscount";i:15;s:10:"sfrsswords";i:0;s:14:"sfrsstopicname";b:0;s:12:"sfrssfeedkey";b:1;}');
INSERT INTO `wp_sfoptions` VALUES (33, 'sffiltershortcodes', '1');
INSERT INTO `wp_sfoptions` VALUES (34, 'sfpostwrap', 'a:2:{s:8:"postwrap";b:0;s:9:"postwidth";i:0;}');
INSERT INTO `wp_sfoptions` VALUES (35, 'sfwplistpages', '1');
INSERT INTO `wp_sfoptions` VALUES (36, 'sfscriptfoot', '');
INSERT INTO `wp_sfoptions` VALUES (37, 'sfinloop', '');
INSERT INTO `wp_sfoptions` VALUES (38, 'sfmultiplecontent', '1');
INSERT INTO `wp_sfoptions` VALUES (39, 'sfwpheadbypass', '');
INSERT INTO `wp_sfoptions` VALUES (40, 'spukey', 'a28fa4d0f9');
INSERT INTO `wp_sfoptions` VALUES (41, 'sp_current_theme', 'a:3:{s:5:"theme";s:7:"default";s:5:"style";s:11:"default.php";s:5:"color";s:6:"silver";}');
INSERT INTO `wp_sfoptions` VALUES (42, 'sp_mobile_theme', 'a:4:{s:6:"active";b:0;s:5:"theme";s:7:"default";s:5:"style";s:11:"default.php";s:5:"color";s:6:"silver";}');
INSERT INTO `wp_sfoptions` VALUES (43, 'account-name', '');
INSERT INTO `wp_sfoptions` VALUES (44, 'display-name', '');
INSERT INTO `wp_sfoptions` VALUES (45, 'guest-name', '');
INSERT INTO `wp_sfoptions` VALUES (46, 'sp_stats_interval', '3600');
INSERT INTO `wp_sfoptions` VALUES (47, 'poststamp', '2013-10-03 13:17:11');
INSERT INTO `wp_sfoptions` VALUES (48, 'combinecss', '');
INSERT INTO `wp_sfoptions` VALUES (49, 'combinejs', '');
INSERT INTO `wp_sfoptions` VALUES (69, 'sf_guest_memberships', 'a:1:{i:0;a:6:{s:12:"usergroup_id";s:1:"1";s:14:"usergroup_name";s:6:"Guests";s:14:"usergroup_desc";s:41:"Default Usergroup for guests of the forum";s:15:"usergroup_badge";s:0:"";s:14:"usergroup_join";s:1:"0";s:22:"usergroup_is_moderator";s:1:"0";}}');
INSERT INTO `wp_sfoptions` VALUES (54, 'sfconfig', 'a:10:{s:7:"avatars";s:26:"sp-resources/forum-avatars";s:11:"avatar-pool";s:30:"sp-resources/forum-avatar-pool";s:7:"smileys";s:26:"sp-resources/forum-smileys";s:5:"ranks";s:25:"sp-resources/forum-badges";s:12:"custom-icons";s:31:"sp-resources/forum-custom-icons";s:11:"language-sp";s:40:"sp-resources/forum-language/simple-press";s:19:"language-sp-plugins";s:38:"sp-resources/forum-language/sp-plugins";s:18:"language-sp-themes";s:37:"sp-resources/forum-language/sp-themes";s:7:"plugins";s:26:"sp-resources/forum-plugins";s:6:"themes";s:25:"sp-resources/forum-themes";}');
INSERT INTO `wp_sfoptions` VALUES (55, 'spForumStats', 'O:8:"stdClass":4:{s:6:"groups";i:2;s:6:"forums";i:3;s:6:"topics";i:6;s:5:"posts";i:15;}');
INSERT INTO `wp_sfoptions` VALUES (56, 'spMembershipStats', 'a:4:{s:6:"admins";s:1:"2";s:4:"mods";s:1:"0";s:7:"members";i:58;s:6:"guests";s:1:"0";}');
INSERT INTO `wp_sfoptions` VALUES (57, 'spPosterStats', 'a:10:{i:0;O:8:"stdClass":5:{s:7:"user_id";s:2:"42";s:12:"display_name";s:4:"Loic";s:5:"posts";s:1:"4";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:1;O:8:"stdClass":5:{s:7:"user_id";s:2:"15";s:12:"display_name";s:3:"etu";s:5:"posts";s:1:"2";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:2;O:8:"stdClass":5:{s:7:"user_id";s:2:"43";s:12:"display_name";s:6:"Jordan";s:5:"posts";s:1:"2";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:3;O:8:"stdClass":5:{s:7:"user_id";s:2:"37";s:12:"display_name";s:9:"Alexandru";s:5:"posts";s:1:"1";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:4;O:8:"stdClass":5:{s:7:"user_id";s:1:"4";s:12:"display_name";s:13:"ndeye mariane";s:5:"posts";s:1:"1";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:5;O:8:"stdClass":5:{s:7:"user_id";s:2:"46";s:12:"display_name";s:7:"Florent";s:5:"posts";s:1:"1";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:6;O:8:"stdClass":5:{s:7:"user_id";s:2:"45";s:12:"display_name";s:5:"Oudom";s:5:"posts";s:1:"1";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:7;O:8:"stdClass":5:{s:7:"user_id";s:2:"41";s:12:"display_name";s:7:"Florian";s:5:"posts";s:1:"1";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:8;O:8:"stdClass":5:{s:7:"user_id";s:2:"16";s:12:"display_name";s:5:"abdel";s:5:"posts";s:1:"0";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}i:9;O:8:"stdClass":5:{s:7:"user_id";s:2:"36";s:12:"display_name";s:5:"Mehdi";s:5:"posts";s:1:"0";s:5:"admin";s:1:"0";s:9:"moderator";s:1:"0";}}');
INSERT INTO `wp_sfoptions` VALUES (58, 'spModStats', 'a:0:{}');
INSERT INTO `wp_sfoptions` VALUES (59, 'spAdminStats', 'a:2:{i:0;a:4:{s:7:"user_id";s:1:"1";s:12:"display_name";s:5:"admin";s:5:"posts";s:1:"2";s:5:"admin";s:1:"1";}i:1;a:4:{s:7:"user_id";s:2:"24";s:12:"display_name";s:11:"cherbonneau";s:5:"posts";s:1:"0";s:5:"admin";s:1:"1";}}');
INSERT INTO `wp_sfoptions` VALUES (68, 'sp_active_plugins', 'a:0:{}');
INSERT INTO `wp_sfoptions` VALUES (67, 'spMostOnline', '7');
INSERT INTO `wp_sfoptions` VALUES (64, 'spRecentMembers', 'a:10:{i:0;a:2:{s:2:"id";s:2:"66";s:4:"name";s:5:"frank";}i:1;a:2:{s:2:"id";s:2:"65";s:4:"name";s:7:"nouveau";}i:2;a:2:{s:2:"id";s:2:"64";s:4:"name";s:6:"kevinS";}i:3;a:2:{s:2:"id";s:2:"63";s:4:"name";s:7:"vincent";}i:4;a:2:{s:2:"id";s:2:"61";s:4:"name";s:10:"SecondLoic";}i:5;a:2:{s:2:"id";s:2:"60";s:4:"name";s:6:"group5";}i:6;a:2:{s:2:"id";s:2:"59";s:4:"name";s:6:"group4";}i:7;a:2:{s:2:"id";s:2:"58";s:4:"name";s:6:"group3";}i:8;a:2:{s:2:"id";s:2:"57";s:4:"name";s:6:"group2";}i:9;a:2:{s:2:"id";s:2:"56";s:4:"name";s:6:"group1";}}');
INSERT INTO `wp_sfoptions` VALUES (65, 'sfversion', '5.2.6');
INSERT INTO `wp_sfoptions` VALUES (66, 'sfbuild', '9877');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfpermissions`
-- 

CREATE TABLE `wp_sfpermissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `forum_id` bigint(20) NOT NULL DEFAULT '0',
  `usergroup_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `permission_role` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `forum_idx` (`forum_id`),
  KEY `usergroup_idx` (`usergroup_id`),
  KEY `perm_role_idx` (`permission_role`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- Contenu de la table `wp_sfpermissions`
-- 

INSERT INTO `wp_sfpermissions` VALUES (1, 1, 1, 1);
INSERT INTO `wp_sfpermissions` VALUES (2, 1, 2, 5);
INSERT INTO `wp_sfpermissions` VALUES (3, 1, 3, 6);
INSERT INTO `wp_sfpermissions` VALUES (4, 2, 1, 1);
INSERT INTO `wp_sfpermissions` VALUES (5, 2, 2, 5);
INSERT INTO `wp_sfpermissions` VALUES (6, 2, 3, 6);
INSERT INTO `wp_sfpermissions` VALUES (7, 3, 1, 1);
INSERT INTO `wp_sfpermissions` VALUES (8, 3, 2, 5);
INSERT INTO `wp_sfpermissions` VALUES (9, 3, 3, 6);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfposts`
-- 

CREATE TABLE `wp_sfposts` (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_content` longtext,
  `post_date` datetime NOT NULL,
  `topic_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `forum_id` bigint(20) NOT NULL,
  `guest_name` varchar(20) DEFAULT NULL,
  `guest_email` varchar(50) DEFAULT NULL,
  `post_status` int(4) NOT NULL DEFAULT '0',
  `post_pinned` smallint(1) NOT NULL DEFAULT '0',
  `post_index` mediumint(8) DEFAULT '0',
  `post_edit` mediumtext,
  `poster_ip` varchar(39) NOT NULL DEFAULT '0.0.0.0',
  `comment_id` bigint(20) DEFAULT NULL,
  `source` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`),
  KEY `topicp_idx` (`topic_id`),
  KEY `forump_idx` (`forum_id`),
  KEY `user_idx` (`user_id`),
  KEY `guest_name_idx` (`guest_name`),
  KEY `comment_idx` (`comment_id`),
  KEY `post_date_idx` (`post_date`),
  FULLTEXT KEY `post_content` (`post_content`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- Contenu de la table `wp_sfposts`
-- 

INSERT INTO `wp_sfposts` VALUES (1, 'Ceci est un juste un test<img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-laugh.gif" alt="Laugh" />', '2013-03-26 00:09:06', 1, 1, 1, '', '', 0, 0, 1, NULL, '80.14.171.23', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (2, 'D''accord', '2013-03-26 00:09:45', 1, 1, 1, '', '', 0, 0, 2, NULL, '80.14.171.23', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (3, 'Ceci est juste un test<img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-wink.gif" alt="Wink" />', '2013-04-22 20:15:49', 2, 4, 2, '', '', 0, 0, 1, NULL, '80.14.78.52', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (4, 'bcbdb cdhbs cdsb', '2013-05-20 09:23:15', 3, 15, 1, '', '', 0, 0, 1, NULL, '130.120.211.102', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (5, 'Lequi pe Gdlteam', '2013-05-20 09:23:51', 3, 15, 1, '', '', 0, 0, 2, NULL, '130.120.211.102', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (6, 'tototest', '2013-09-27 12:31:24', 1, 42, 1, '', '', 0, 0, 3, NULL, '130.120.209.26', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (7, 'toto retest', '2013-09-27 12:31:55', 1, 42, 1, '', '', 0, 0, 4, NULL, '130.120.209.26', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (8, 'toto test encore', '2013-09-27 12:32:26', 1, 42, 1, '', '', 0, 0, 5, NULL, '130.120.209.26', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (9, 'un dernier test avant de dire que faudrait empêcher le multi post <img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-includes/images/smilies/icon_surprised.gif" alt=":o" class="spSmiley" />', '2013-09-27 12:32:58', 1, 42, 1, '', '', 0, 0, 6, NULL, '130.120.209.26', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (10, 'Test\r\n\r\n<strong>Test bbcode</strong>\r\n\r\n<b>Test html</b>\r\n\r\n<img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-cool.gif" alt="Cool" />', '2013-09-27 12:59:12', 1, 43, 1, '', '', 0, 0, 7, NULL, '130.120.208.224', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (11, 'alert(''Trololol'');', '2013-09-27 13:09:31', 1, 43, 1, '', '', 0, 0, 8, NULL, '130.120.210.42', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (12, 'C''est plus la peine de tester "admin" "admin" Amel a modifier le mots de passe admin...\r\n\r\nNouveau défi .... connexion en tant qu''admin ! <img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-wink.gif" alt="Wink" />', '2013-09-27 13:27:30', 4, 46, 1, '', '', 0, 0, 1, NULL, '130.120.246.121', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (13, '<img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-cool.gif" alt="Cool" />', '2013-09-27 13:38:51', 5, 45, 3, '', '', 0, 0, 1, NULL, '130.120.240.198', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (14, 'balbasdfasdf<img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-yell.gif" alt="Yell" /><img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-yell.gif" alt="Yell" /><img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-surprised.gif" alt="Surprised" /><img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-surprised.gif" alt="Surprised" /><img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-surprised.gif" alt="Surprised" />', '2013-10-03 13:06:06', 6, 37, 1, '', '', 0, 0, 1, NULL, '130.120.247.83', NULL, 0);
INSERT INTO `wp_sfposts` VALUES (15, 'TEST <img src="http://www.gdnlteamtest.netsoro.net/wordpress/wp-content/sp-resources/forum-smileys/sf-laugh.gif" alt="Laugh" />', '2013-10-03 13:17:11', 5, 41, 3, '', '', 0, 0, 2, NULL, '130.120.211.74', NULL, 0);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfroles`
-- 

CREATE TABLE `wp_sfroles` (
  `role_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL DEFAULT '',
  `role_desc` varchar(150) NOT NULL DEFAULT '',
  `role_auths` longtext NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Contenu de la table `wp_sfroles`
-- 

INSERT INTO `wp_sfroles` VALUES (1, 'No Access', 'Permission with no access to any Forum features', 'a:34:{i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:0;i:25;i:0;i:26;i:0;i:27;i:0;i:28;i:0;i:32;i:0;i:33;i:0;i:30;i:0;i:31;i:0;i:29;i:0;i:34;i:0;}');
INSERT INTO `wp_sfroles` VALUES (2, 'Read Only Access', 'Permission with access to only view the Forum', 'a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:0;i:25;i:0;i:26;i:0;i:27;i:0;i:28;i:0;i:32;i:0;i:33;i:0;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:0;}');
INSERT INTO `wp_sfroles` VALUES (3, 'Limited Access', 'Permission with access to reply and start topics but with limited features', 'a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:0;i:27;i:0;i:28;i:0;i:32;i:0;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}');
INSERT INTO `wp_sfroles` VALUES (4, 'Standard Access', 'Permission with access to reply and start topics with advanced features such as signatures', 'a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:0;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:0;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}');
INSERT INTO `wp_sfroles` VALUES (5, 'Full Access', 'Permission with Standard Access features and math question bypass', 'a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:9;i:1;i:10;i:0;i:11;i:0;i:12;i:0;i:13;i:0;i:14;i:0;i:15;i:0;i:16;i:1;i:17;i:1;i:18;i:0;i:19;i:0;i:20;i:0;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:0;i:34;i:1;}');
INSERT INTO `wp_sfroles` VALUES (6, 'Moderator Access', 'Permission with access to all Forum features', 'a:34:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;i:6;i:1;i:7;i:1;i:8;i:0;i:10;i:1;i:9;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:1;i:16;i:1;i:17;i:1;i:18;i:1;i:19;i:0;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:32;i:1;i:33;i:1;i:30;i:1;i:31;i:1;i:29;i:1;i:34;i:1;}');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sftopics`
-- 

CREATE TABLE `wp_sftopics` (
  `topic_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `topic_name` varchar(200) NOT NULL,
  `topic_date` datetime NOT NULL,
  `topic_status` int(4) NOT NULL DEFAULT '0',
  `forum_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `topic_pinned` smallint(1) NOT NULL DEFAULT '0',
  `topic_opened` bigint(20) NOT NULL DEFAULT '0',
  `topic_slug` varchar(200) NOT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `post_id_held` bigint(20) DEFAULT NULL,
  `post_count` mediumint(8) DEFAULT '0',
  `post_count_held` mediumint(8) DEFAULT '0',
  PRIMARY KEY (`topic_id`),
  KEY `forumt_idx` (`forum_id`),
  KEY `tslug_idx` (`topic_slug`),
  KEY `user_idx` (`user_id`),
  KEY `post_idx` (`post_id`),
  FULLTEXT KEY `topic_name_idx` (`topic_name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Contenu de la table `wp_sftopics`
-- 

INSERT INTO `wp_sftopics` VALUES (1, 'Test Forum', '2013-03-26 00:09:06', 0, 1, 1, 0, 21, 'test-forum', 11, 11, 8, 8);
INSERT INTO `wp_sftopics` VALUES (2, 'Test', '2013-04-22 20:15:49', 0, 2, 4, 0, 3, 'test', 3, 3, 1, 1);
INSERT INTO `wp_sftopics` VALUES (3, 'Ue projet', '2013-05-20 09:23:15', 0, 1, 15, 0, 4, 'ue-projet', 5, 5, 2, 2);
INSERT INTO `wp_sftopics` VALUES (4, '&#091;Résolu&#093; Connexion en tant que administrateur', '2013-09-27 13:27:30', 0, 1, 46, 0, 6, 'resolu-connexion-en-tant-que-administrateur', 12, 12, 1, 1);
INSERT INTO `wp_sftopics` VALUES (5, 'Testing', '2013-09-27 13:38:51', 0, 3, 45, 0, 3, 'testing', 15, 15, 2, 2);
INSERT INTO `wp_sftopics` VALUES (6, 'asdfasd;lkfjasdf', '2013-10-03 13:06:06', 0, 1, 37, 0, 3, 'asdfasdlkfjasdf', 14, 14, 1, 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sftrack`
-- 

CREATE TABLE `wp_sftrack` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `trackuserid` bigint(20) DEFAULT '0',
  `trackname` varchar(50) NOT NULL,
  `trackdate` datetime NOT NULL,
  `forum_id` bigint(20) DEFAULT NULL,
  `topic_id` bigint(20) DEFAULT NULL,
  `pageview` varchar(50) NOT NULL,
  `notification` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`trackuserid`),
  KEY `forum_idx` (`forum_id`),
  KEY `topic_idx` (`topic_id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

-- 
-- Contenu de la table `wp_sftrack`
-- 

INSERT INTO `wp_sftrack` VALUES (61, 29, 'Kevin', '2013-10-03 17:18:40', 0, 0, 'group', NULL);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfusergroups`
-- 

CREATE TABLE `wp_sfusergroups` (
  `usergroup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `usergroup_name` text NOT NULL,
  `usergroup_desc` text,
  `usergroup_badge` varchar(50) DEFAULT NULL,
  `usergroup_join` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `usergroup_is_moderator` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`usergroup_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Contenu de la table `wp_sfusergroups`
-- 

INSERT INTO `wp_sfusergroups` VALUES (1, 'Guests', 'Default Usergroup for guests of the forum', '', 0, 0);
INSERT INTO `wp_sfusergroups` VALUES (2, 'Members', 'Default Usergroup for registered users of the forum', '', 0, 0);
INSERT INTO `wp_sfusergroups` VALUES (3, 'Moderators', 'Default Usergroup for moderators of the forum', '', 0, 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sfwaiting`
-- 

CREATE TABLE `wp_sfwaiting` (
  `topic_id` bigint(20) NOT NULL,
  `forum_id` bigint(20) NOT NULL,
  `post_count` int(4) NOT NULL,
  `post_id` bigint(20) NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `wp_sfwaiting`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_sujets`
-- 

CREATE TABLE `wp_sujets` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(300) CHARACTER SET utf8 NOT NULL,
  `auteur` varchar(30) CHARACTER SET utf8 NOT NULL,
  `nature` varchar(30) CHARACTER SET utf8 NOT NULL,
  `theme` text CHARACTER SET utf8 NOT NULL,
  `tailleEquipe` varchar(20) CHARACTER SET utf8 NOT NULL,
  `moduleConcerne` varchar(20) CHARACTER SET utf8 NOT NULL,
  `langage` varchar(60) CHARACTER SET utf8 NOT NULL,
  `choisi?` tinyint(1) NOT NULL,
  `affecterA` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Contenu de la table `wp_sujets`
-- 

INSERT INTO `wp_sujets` VALUES (1, 'Cours de cours', 'Diallo Abdou', 'Developpement', 'L''acteur français Gérard Depardieu, qui vit désormais en Russie, passe encore beaucoup de temps à Paris. Et comme à son habitude, il se déplace en scooter dans les rues de la capitale. Mais ce dimanche, l''interprète d''Obélix s''est fait voler son deux-roues', '12', '8', 'Java', 0, NULL);
INSERT INTO `wp_sujets` VALUES (2, 'Cours de cours', 'Diallo Abdou', 'Developpement', 'La Corée du Nord a franchi mardi une nouvelle étape dans son escalade verbale et guerrière contre les Etats-Unis. Cette fois, Kim Jong-un, le président nord-coréen, a demandé à ses troupes de "se placer en alerte", en mode "prêtes au combat".', '12', '8', 'Java', 0, NULL);
INSERT INTO `wp_sujets` VALUES (3, 'Cours de cours', 'Diallo Abdou', 'Developpement', 'The WordPress Posts automatically ', '12', '8', 'Java', 0, NULL);
INSERT INTO `wp_sujets` VALUES (4, 'titre', 'auteur', 'nature', 'Nick D''Aloisio, un adolescent britannique de 17 ans, est devenu lundi 25 mars l''un des plus jeunes millionnaires de la planète. Une prouesse réalisée non pas en chantant ou en faisant du cinéma, mais en produisant des lignes de code. Nick vient en effet de', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (5, 'titre', 'auteur', 'nature', 'La présidente brésilienne Dilma Rousseff se rend le 27 mars à Durban, en Afrique du Sud, dans le cadre du sommet des Brics. Au programme de sa visite, le rapprochement avec l''Afrique. Courrier international |; 26 mars 2013; | 0; Réagir. Imprimer; Envoyer', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (6, 'titre', 'auteur', 'nature', 'La présidente brésilienne Dilma Rousseff se rend le 27 mars à Durban, en Afrique du Sud, dans le cadre du sommet des Brics. Au programme de sa visite, le rapprochement avec l''Afrique. Courrier international |; 26 mars 2013; | 0; Réagir. Imprimer; Envoyer', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (7, 'titre', 'auteur', 'nature', 'La présidente brésilienne Dilma Rousseff se rend le 27 mars à Durban, en Afrique du Sud, dans le cadre du sommet des Brics. Au programme de sa visite, le rapprochement avec l''Afrique. Courrier international |; 26 mars 2013; | 0; Réagir. Imprimer; Envoyer', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (8, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (9, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (10, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (11, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (12, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (13, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (14, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (15, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);
INSERT INTO `wp_sujets` VALUES (16, 'titre', 'auteur', 'nature', 'theme', 'tailleEquipe', 'moduleConcerne', 'langage', 0, NULL);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_cats`
-- 

CREATE TABLE `wp_symposium_cats` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `listorder` int(11) NOT NULL DEFAULT '0',
  `allow_new` varchar(2) NOT NULL DEFAULT 'on',
  `defaultcat` varchar(2) NOT NULL DEFAULT '',
  `cat_parent` int(11) NOT NULL DEFAULT '0',
  `cat_desc` varchar(256) DEFAULT '',
  `level` varchar(256) DEFAULT 's:60:"Everyone,Administrator,Editor,Author,Contributor,Subscriber,";',
  `stub` varchar(256) DEFAULT '',
  `min_rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_cats`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_chat`
-- 

CREATE TABLE `wp_symposium_chat` (
  `chid` int(11) NOT NULL AUTO_INCREMENT,
  `chat_from` int(11) NOT NULL,
  `chat_to` int(11) NOT NULL,
  `chat_message` text NOT NULL,
  `chat_timestamp` datetime DEFAULT NULL,
  `chat_room` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`chid`),
  KEY `chat_from_index` (`chat_from`),
  KEY `chat_to_index` (`chat_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_chat`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_comments`
-- 

CREATE TABLE `wp_symposium_comments` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `subject_uid` int(11) NOT NULL,
  `author_uid` int(11) NOT NULL,
  `comment_parent` int(11) NOT NULL,
  `comment_timestamp` datetime DEFAULT NULL,
  `comment` text,
  `is_group` varchar(2) NOT NULL DEFAULT '',
  `type` varchar(16) NOT NULL DEFAULT 'post',
  PRIMARY KEY (`cid`),
  KEY `subject_uid_index` (`subject_uid`),
  KEY `author_uid_index` (`author_uid`),
  KEY `comment_parent_index` (`comment_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_comments`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_extended`
-- 

CREATE TABLE `wp_symposium_extended` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `extended_name` varchar(256) NOT NULL DEFAULT 'New field',
  `extended_type` varchar(16) NOT NULL DEFAULT 'Text',
  `extended_default` text,
  `extended_order` int(11) NOT NULL DEFAULT '0',
  `extended_slug` varchar(64) NOT NULL,
  `wp_usermeta` varchar(256) DEFAULT NULL,
  `readonly` varchar(2) DEFAULT '',
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_extended`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_friends`
-- 

CREATE TABLE `wp_symposium_friends` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `friend_from` int(11) NOT NULL,
  `friend_to` int(11) NOT NULL,
  `friend_accepted` varchar(2) NOT NULL,
  `friend_message` text NOT NULL,
  `friend_timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `friend_from_index` (`friend_from`),
  KEY `friend_to_index` (`friend_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_friends`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_likes`
-- 

CREATE TABLE `wp_symposium_likes` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(16) NOT NULL,
  `cid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `liked_date` datetime NOT NULL,
  PRIMARY KEY (`vid`),
  KEY `cid_index` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_likes`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_mail`
-- 

CREATE TABLE `wp_symposium_mail` (
  `mail_mid` int(11) NOT NULL AUTO_INCREMENT,
  `mail_from` int(11) DEFAULT NULL,
  `mail_to` int(11) DEFAULT NULL,
  `mail_read` varchar(2) NOT NULL DEFAULT '',
  `mail_sent` datetime DEFAULT NULL,
  `mail_subject` varchar(256) NOT NULL,
  `mail_in_deleted` varchar(2) NOT NULL DEFAULT '',
  `mail_sent_deleted` varchar(2) NOT NULL DEFAULT '',
  `mail_message` text,
  PRIMARY KEY (`mail_mid`),
  KEY `mail_to_index` (`mail_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_mail`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_styles`
-- 

CREATE TABLE `wp_symposium_styles` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL,
  `__wps__categories_background` varchar(12) NOT NULL,
  `categories_color` varchar(12) NOT NULL,
  `bigbutton_background` varchar(12) NOT NULL,
  `bigbutton_color` varchar(12) NOT NULL,
  `bigbutton_background_hover` varchar(12) NOT NULL,
  `bigbutton_color_hover` varchar(12) NOT NULL,
  `bg_color_1` varchar(12) NOT NULL,
  `bg_color_2` varchar(12) NOT NULL,
  `bg_color_3` varchar(12) NOT NULL,
  `text_color` varchar(12) NOT NULL,
  `table_rollover` varchar(12) NOT NULL,
  `link` varchar(12) NOT NULL,
  `link_hover` varchar(12) NOT NULL,
  `table_border` varchar(2) NOT NULL,
  `replies_border_size` varchar(2) NOT NULL,
  `text_color_2` varchar(12) NOT NULL,
  `row_border_style` varchar(7) NOT NULL,
  `row_border_size` varchar(2) NOT NULL,
  `border_radius` varchar(2) NOT NULL,
  `label` varchar(12) NOT NULL,
  `underline` varchar(2) NOT NULL DEFAULT 'on',
  `main_background` varchar(12) NOT NULL DEFAULT '#fff',
  `closed_opacity` varchar(6) NOT NULL DEFAULT '1.0',
  `fontfamily` varchar(128) NOT NULL DEFAULT 'Georgia,Times',
  `fontsize` varchar(8) NOT NULL DEFAULT '13',
  `headingsfamily` varchar(128) NOT NULL DEFAULT 'Georgia,Times',
  `headingssize` varchar(8) NOT NULL DEFAULT '20',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_styles`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_subs`
-- 

CREATE TABLE `wp_symposium_subs` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`sid`),
  KEY `uid_index` (`uid`),
  KEY `tid_index` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_subs`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_topics`
-- 

CREATE TABLE `wp_symposium_topics` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `topic_group` int(11) NOT NULL DEFAULT '0',
  `topic_category` int(11) NOT NULL DEFAULT '0',
  `topic_subject` varchar(256) NOT NULL,
  `topic_post` text NOT NULL,
  `topic_owner` int(11) NOT NULL,
  `topic_date` datetime NOT NULL,
  `topic_parent` int(11) NOT NULL,
  `topic_views` int(11) NOT NULL,
  `topic_started` datetime NOT NULL,
  `topic_sticky` int(11) NOT NULL DEFAULT '0',
  `allow_replies` varchar(2) NOT NULL DEFAULT 'on',
  `topic_approved` varchar(2) NOT NULL DEFAULT 'on',
  `topic_answer` varchar(2) DEFAULT '',
  `for_info` varchar(2) DEFAULT '',
  `stub` varchar(256) DEFAULT '',
  `remote_addr` varchar(32) DEFAULT '',
  `http_x_forwarded_for` varchar(32) DEFAULT '',
  PRIMARY KEY (`tid`),
  KEY `topic_owner_index` (`topic_owner`),
  KEY `topic_parent_index` (`topic_parent`),
  KEY `topic_category_index` (`topic_category`),
  KEY `topic_date_index` (`topic_date`),
  KEY `topic_started_index` (`topic_started`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_topics`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_topics_images`
-- 

CREATE TABLE `wp_symposium_topics_images` (
  `tmpid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `tid` int(11) DEFAULT '0',
  `filename` varchar(256) NOT NULL,
  `upload` mediumblob,
  PRIMARY KEY (`tmpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_topics_images`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_topics_scores`
-- 

CREATE TABLE `wp_symposium_topics_scores` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `topic_date` datetime NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_topics_scores`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_symposium_usermeta`
-- 

CREATE TABLE `wp_symposium_usermeta` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `profile_avatar` mediumblob,
  PRIMARY KEY (`mid`),
  UNIQUE KEY `uid_index` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_symposium_usermeta`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_tab_sujets`
-- 

CREATE TABLE `wp_tab_sujets` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `titre` varchar(150) CHARACTER SET utf8 NOT NULL,
  `tailleEq` varchar(20) CHARACTER SET utf8 NOT NULL,
  `specialite` varchar(10) CHARACTER SET utf8 NOT NULL,
  `langage` varchar(50) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `idEncadrant` int(11) NOT NULL,
  `choisiPar` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `affecteAuGroupe` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

-- 
-- Contenu de la table `wp_tab_sujets`
-- 

INSERT INTO `wp_tab_sujets` VALUES (1, 'Developpement', '4', 'DL/IHM', 'JAVA', 'Software development (also known as application development, software design, designing software, software application development, enterprise application development, or platform development)[1] is the development of a software product. The term "software development" may be used to refer to the activity of computer programming, which is the process of writing and maintaining the source code.', 1, NULL, 'GDNLTEAM');
INSERT INTO `wp_tab_sujets` VALUES (12, 'Recherche/developpement', '4', '1', '1', 'Vous pouvez indiquer n''importe lequel de vos noms de domaine en tant qu''hÃ´te pour Ã©tablir une connexion FTP. cool.', 1, NULL, 'Arrangement Btn ajout');
INSERT INTO `wp_tab_sujets` VALUES (14, 'test2', '1', 'im', 'tr', 'test 2', 7, NULL, 'MyTest');
INSERT INTO `wp_tab_sujets` VALUES (17, 'Developpement', '3', '8', '1', 'Stage de developp', 1, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (25, 'AAA', '1', '1', '1', 'dddd', 1, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (26, 'Dl', '4', '7', '3', 'hdqshcqsd', 7, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (27, 'conception', '4', '1', '1', 'projet de conception ', 1, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (28, 'projet BC', '4', '1', '1', 'ce projet a pour but de...', 24, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (29, 'deuxieme projet', '3', '3', '1', '', 24, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (30, 'troisieme projet', '1', '1', '1', '', 24, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (31, 'autre projet', '1', '1', '1', '', 24, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (35, 'dev', '1', '1', '1', '', 29, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (37, 'Test Ajouter Projet', '4', '9', '4', '123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890', 40, NULL, 'MyTest');
INSERT INTO `wp_tab_sujets` VALUES (39, 'Test Ajouter Projet2', '5', '10', '1', '1234567890', 40, NULL, NULL);
INSERT INTO `wp_tab_sujets` VALUES (40, 'Description', '1', '1', '1', '12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890', 40, NULL, 'MyTest');
INSERT INTO `wp_tab_sujets` VALUES (41, 'WeLoveCaml', '5', '9', '7', 'Sujet de caml', 63, NULL, 'VerieTest');
INSERT INTO `wp_tab_sujets` VALUES (42, 'WeLoveCaml', '5', '1', '7', 'Trop cool', 63, NULL, 'Toto');
INSERT INTO `wp_tab_sujets` VALUES (43, 'projet web docForWeb', '5', '1', '1', 'sujet test', 1, NULL, 'lamray9iya');
INSERT INTO `wp_tab_sujets` VALUES (44, 'lmar9a', '1', '1', '1', 'blgar3a', 36, NULL, 'G2 M2DL');
INSERT INTO `wp_tab_sujets` VALUES (45, 'la sauce', '1', '1', '2', 'bzitoune', 36, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_term_relationships`
-- 

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `wp_term_relationships`
-- 

INSERT INTO `wp_term_relationships` VALUES (1, 1, 0);
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0);
INSERT INTO `wp_term_relationships` VALUES (1, 5, 0);
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0);
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0);
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0);
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0);
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0);
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0);
INSERT INTO `wp_term_relationships` VALUES (35, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (36, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (38, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (39, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (40, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (41, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (42, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (103, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (142, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (266, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (267, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (268, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (283, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (296, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (312, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (336, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (341, 3, 0);
INSERT INTO `wp_term_relationships` VALUES (347, 3, 0);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_term_taxonomy`
-- 

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Contenu de la table `wp_term_taxonomy`
-- 

INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1);
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'link_category', '', 0, 7);
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'nav_menu', '', 0, 18);
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'post_format', '', 0, 0);
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'post_format', '', 0, 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_terms`
-- 

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Contenu de la table `wp_terms`
-- 

INSERT INTO `wp_terms` VALUES (1, 'Non classé', 'non-classe', 0);
INSERT INTO `wp_terms` VALUES (2, 'Liens', 'liens', 0);
INSERT INTO `wp_terms` VALUES (3, 'Menu', 'menu', 0);
INSERT INTO `wp_terms` VALUES (4, 'post-format-gallery', 'post-format-gallery', 0);
INSERT INTO `wp_terms` VALUES (5, 'post-format-aside', 'post-format-aside', 0);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_uam_accessgroup_to_object`
-- 

CREATE TABLE `wp_uam_accessgroup_to_object` (
  `object_id` varchar(11) NOT NULL,
  `object_type` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`object_id`,`object_type`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `wp_uam_accessgroup_to_object`
-- 

INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('100', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('100', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('127', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('129', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('131', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('14', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('14', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('14', 'page', 3);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('22', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('22', 'page', 3);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('236', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('236', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('24', 'user', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('240', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('244', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('25', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('258', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('258', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('260', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('260', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('27', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('27', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('281', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('281', 'page', 3);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('29', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('29', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('29', 'page', 3);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('29', 'user', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('29', 'user', 3);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('293', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('31', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('31', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('33', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('331', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('331', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('332', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('332', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('339', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('345', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('364', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('364', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('364', 'page', 3);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('4', 'page', 1);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('4', 'page', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('encadrant', 'role', 3);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('etudiant', 'role', 2);
INSERT INTO `wp_uam_accessgroup_to_object` VALUES ('responsable', 'role', 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_uam_accessgroups`
-- 

CREATE TABLE `wp_uam_accessgroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` tinytext NOT NULL,
  `groupdesc` text NOT NULL,
  `read_access` tinytext NOT NULL,
  `write_access` tinytext NOT NULL,
  `ip_range` mediumtext,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Contenu de la table `wp_uam_accessgroups`
-- 

INSERT INTO `wp_uam_accessgroups` VALUES (1, 'ResponsableUe', '', 'group', 'group', '');
INSERT INTO `wp_uam_accessgroups` VALUES (2, 'LesEtudiants', '', 'group', 'group', '');
INSERT INTO `wp_uam_accessgroups` VALUES (3, 'LesEncadrants', '', 'group', 'group', '');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_um_message`
-- 

CREATE TABLE `wp_um_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `subject` text NOT NULL,
  `content` text NOT NULL,
  `author_id` bigint(20) NOT NULL,
  `owner_id` bigint(20) NOT NULL,
  `recipient_ids` text NOT NULL,
  `timestamp_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `folder_id` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_um_message`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_um_notification`
-- 

CREATE TABLE `wp_um_notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` text NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `message_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_um_notification`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_user2group_rs`
-- 

CREATE TABLE `wp_user2group_rs` (
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `assigner_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `status` enum('active','recommended','requested') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`user_id`,`group_id`),
  KEY `status_key` (`status`,`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `wp_user2group_rs`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_user2role2object_rs`
-- 

CREATE TABLE `wp_user2role2object_rs` (
  `assignment_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` bigint(20) unsigned DEFAULT NULL,
  `role_name` varchar(64) NOT NULL DEFAULT '',
  `role_type` enum('rs','wp','wp_cap') NOT NULL DEFAULT 'rs',
  `scope` enum('blog','term','object') NOT NULL,
  `src_or_tx_name` varchar(32) NOT NULL DEFAULT '',
  `obj_or_term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `assign_for` enum('entity','children','both') NOT NULL DEFAULT 'entity',
  `inherited_from` bigint(20) unsigned NOT NULL DEFAULT '0',
  `assigner_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_limited` tinyint(2) NOT NULL DEFAULT '0',
  `start_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date_gmt` datetime NOT NULL DEFAULT '2035-01-01 00:00:00',
  `content_date_limited` tinyint(2) NOT NULL DEFAULT '0',
  `content_min_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `content_max_date_gmt` datetime NOT NULL DEFAULT '2035-01-01 00:00:00',
  PRIMARY KEY (`assignment_id`),
  KEY `role2obj` (`scope`,`assign_for`,`role_type`,`role_name`,`src_or_tx_name`,`obj_or_term_id`),
  KEY `role2agent` (`assign_for`,`scope`,`role_type`,`role_name`,`group_id`,`user_id`),
  KEY `role_rs` (`date_limited`,`role_type`,`role_name`,`scope`,`assign_for`,`src_or_tx_name`,`group_id`,`user_id`,`obj_or_term_id`),
  KEY `role_assignments` (`role_name`,`role_type`,`scope`,`assign_for`,`src_or_tx_name`,`group_id`,`user_id`,`obj_or_term_id`,`inherited_from`,`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_user2role2object_rs`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_usermeta`
-- 

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=962 DEFAULT CHARSET=utf8 AUTO_INCREMENT=962 ;

-- 
-- Contenu de la table `wp_usermeta`
-- 

INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin');
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '');
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'false');
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:12:{s:13:"administrator";s:1:"1";s:18:"SPF Manage Options";s:1:"1";s:17:"SPF Manage Forums";s:1:"1";s:22:"SPF Manage User Groups";s:1:"1";s:22:"SPF Manage Permissions";s:1:"1";s:21:"SPF Manage Components";s:1:"1";s:17:"SPF Manage Admins";s:1:"1";s:16:"SPF Manage Users";s:1:"1";s:19:"SPF Manage Profiles";s:1:"1";s:18:"SPF Manage Toolbox";s:1:"1";s:18:"SPF Manage Plugins";s:1:"1";s:17:"SPF Manage Themes";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10');
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1');
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '416');
INSERT INTO `wp_usermeta` VALUES (15, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}');
INSERT INTO `wp_usermeta` VALUES (16, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}');
INSERT INTO `wp_usermeta` VALUES (17, 1, 'nav_menu_recently_edited', '3');
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_user-settings', 'editor=html&tml1=1&align=right&hidetb=0&imgsize=full&wpfb_adv_uploader=1');
INSERT INTO `wp_usermeta` VALUES (19, 1, 'wp_user-settings-time', '1367343562');
INSERT INTO `wp_usermeta` VALUES (20, 1, 'email_users_accept_notifications', 'true');
INSERT INTO `wp_usermeta` VALUES (21, 1, 'email_users_accept_mass_emails', 'true');
INSERT INTO `wp_usermeta` VALUES (37, 3, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (38, 3, 'last_name', 'grim');
INSERT INTO `wp_usermeta` VALUES (39, 3, 'nickname', 'amel');
INSERT INTO `wp_usermeta` VALUES (40, 3, 'description', '');
INSERT INTO `wp_usermeta` VALUES (41, 3, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (42, 3, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (43, 3, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (44, 3, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (45, 3, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (46, 3, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (47, 3, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (48, 3, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (49, 3, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (50, 3, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (51, 3, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (52, 4, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (53, 4, 'last_name', 'ndiaye');
INSERT INTO `wp_usermeta` VALUES (54, 4, 'nickname', 'ndeye mariane');
INSERT INTO `wp_usermeta` VALUES (55, 4, 'description', '');
INSERT INTO `wp_usermeta` VALUES (56, 4, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (57, 4, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (58, 4, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (59, 4, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (60, 4, 'show_admin_bar_front', 'false');
INSERT INTO `wp_usermeta` VALUES (61, 4, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (62, 4, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (63, 4, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (64, 4, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (65, 4, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (66, 4, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (67, 5, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (68, 5, 'last_name', 'louhidi');
INSERT INTO `wp_usermeta` VALUES (69, 5, 'nickname', 'mohamed amine');
INSERT INTO `wp_usermeta` VALUES (70, 5, 'description', '');
INSERT INTO `wp_usermeta` VALUES (71, 5, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (72, 5, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (73, 5, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (74, 5, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (75, 5, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (76, 5, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (77, 5, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (78, 5, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (79, 5, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (80, 5, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (81, 5, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (94, 7, 'first_name', 'Encadrant1');
INSERT INTO `wp_usermeta` VALUES (95, 7, 'last_name', 'Encadrant1');
INSERT INTO `wp_usermeta` VALUES (96, 7, 'nickname', 'encadrant');
INSERT INTO `wp_usermeta` VALUES (97, 7, 'description', '');
INSERT INTO `wp_usermeta` VALUES (98, 7, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (99, 7, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (100, 7, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (101, 7, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (102, 7, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (103, 7, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (104, 7, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (105, 7, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (106, 1, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (107, 1, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (108, 1, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (114, 1, 'closedpostboxes_post', 'a:1:{i:0;s:11:"categorydiv";}');
INSERT INTO `wp_usermeta` VALUES (115, 1, 'metaboxhidden_post', 'a:8:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:11:"commentsdiv";i:5;s:7:"slugdiv";i:6;s:9:"authordiv";i:7;s:12:"revisionsdiv";}');
INSERT INTO `wp_usermeta` VALUES (116, 1, 'closedpostboxes_page', 'a:0:{}');
INSERT INTO `wp_usermeta` VALUES (117, 1, 'metaboxhidden_page', 'a:6:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";i:5;s:12:"revisionsdiv";}');
INSERT INTO `wp_usermeta` VALUES (118, 8, 'first_name', 'Abdoul');
INSERT INTO `wp_usermeta` VALUES (119, 8, 'last_name', 'Diallo');
INSERT INTO `wp_usermeta` VALUES (120, 8, 'nickname', 'abdd.diallo25');
INSERT INTO `wp_usermeta` VALUES (121, 8, 'description', '');
INSERT INTO `wp_usermeta` VALUES (122, 8, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (123, 8, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (124, 8, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (125, 8, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (126, 8, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (127, 8, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (128, 8, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (129, 8, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (130, 9, 'first_name', 'abdoul');
INSERT INTO `wp_usermeta` VALUES (131, 9, 'last_name', 'dia');
INSERT INTO `wp_usermeta` VALUES (132, 9, 'nickname', 'admin5');
INSERT INTO `wp_usermeta` VALUES (133, 9, 'description', '');
INSERT INTO `wp_usermeta` VALUES (134, 9, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (135, 9, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (136, 9, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (137, 9, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (138, 9, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (139, 9, 'wp_capabilities', 'a:0:{}');
INSERT INTO `wp_usermeta` VALUES (140, 9, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (141, 9, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (142, 10, 'first_name', 'Diallo');
INSERT INTO `wp_usermeta` VALUES (143, 10, 'last_name', 'Abdourahamane');
INSERT INTO `wp_usermeta` VALUES (144, 10, 'nickname', 'diallo5');
INSERT INTO `wp_usermeta` VALUES (145, 10, 'description', '');
INSERT INTO `wp_usermeta` VALUES (146, 10, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (147, 10, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (148, 10, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (149, 10, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (150, 10, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (151, 10, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (152, 10, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (153, 10, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (181, 13, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (182, 13, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (183, 13, 'nickname', 'dial');
INSERT INTO `wp_usermeta` VALUES (184, 13, 'description', '');
INSERT INTO `wp_usermeta` VALUES (185, 13, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (186, 13, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (187, 13, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (188, 13, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (189, 13, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (190, 13, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (191, 13, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (192, 13, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (193, 14, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (194, 14, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (195, 14, 'nickname', 'cool1');
INSERT INTO `wp_usermeta` VALUES (196, 14, 'description', '');
INSERT INTO `wp_usermeta` VALUES (197, 14, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (198, 14, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (199, 14, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (200, 14, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (201, 14, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (202, 14, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (203, 14, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (204, 14, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (205, 15, 'first_name', 'etu');
INSERT INTO `wp_usermeta` VALUES (206, 15, 'last_name', 'etu');
INSERT INTO `wp_usermeta` VALUES (207, 15, 'nickname', 'etu');
INSERT INTO `wp_usermeta` VALUES (208, 15, 'description', '');
INSERT INTO `wp_usermeta` VALUES (209, 15, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (210, 15, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (211, 15, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (212, 15, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (213, 15, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (214, 15, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (215, 15, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (216, 15, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (217, 15, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (218, 15, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (219, 15, 'jabber', 'admin');
INSERT INTO `wp_usermeta` VALUES (220, 16, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (221, 16, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (222, 16, 'nickname', 'abdel');
INSERT INTO `wp_usermeta` VALUES (223, 16, 'description', '');
INSERT INTO `wp_usermeta` VALUES (224, 16, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (225, 16, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (226, 16, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (227, 16, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (228, 16, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (229, 16, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (230, 16, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (231, 16, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (232, 17, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (233, 17, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (234, 17, 'nickname', 'netsoro');
INSERT INTO `wp_usermeta` VALUES (235, 17, 'description', '');
INSERT INTO `wp_usermeta` VALUES (236, 17, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (237, 17, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (238, 17, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (239, 17, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (240, 17, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (241, 17, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (242, 17, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (243, 17, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (244, 18, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (245, 18, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (246, 18, 'nickname', 'testt');
INSERT INTO `wp_usermeta` VALUES (247, 18, 'description', '');
INSERT INTO `wp_usermeta` VALUES (248, 18, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (249, 18, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (250, 18, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (251, 18, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (252, 18, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (253, 18, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (254, 18, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (255, 18, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (256, 19, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (257, 19, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (258, 19, 'nickname', 'test12');
INSERT INTO `wp_usermeta` VALUES (259, 19, 'description', '');
INSERT INTO `wp_usermeta` VALUES (260, 19, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (261, 19, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (262, 19, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (263, 19, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (264, 19, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (265, 19, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (266, 19, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (267, 19, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (268, 20, 'first_name', 'Diallo');
INSERT INTO `wp_usermeta` VALUES (269, 20, 'last_name', 'Abdourahamane');
INSERT INTO `wp_usermeta` VALUES (270, 20, 'nickname', 'diallo252');
INSERT INTO `wp_usermeta` VALUES (271, 20, 'description', '');
INSERT INTO `wp_usermeta` VALUES (272, 20, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (273, 20, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (274, 20, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (275, 20, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (276, 20, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (277, 20, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (278, 20, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (279, 20, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (280, 21, 'first_name', 'Diallo');
INSERT INTO `wp_usermeta` VALUES (281, 21, 'last_name', 'Abdourahamane');
INSERT INTO `wp_usermeta` VALUES (282, 21, 'nickname', 'dada');
INSERT INTO `wp_usermeta` VALUES (283, 21, 'description', '');
INSERT INTO `wp_usermeta` VALUES (284, 21, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (285, 21, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (286, 21, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (287, 21, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (288, 21, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (289, 21, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (290, 21, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (291, 21, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (292, 22, 'first_name', 'Diallo');
INSERT INTO `wp_usermeta` VALUES (293, 22, 'last_name', 'Abdourahamane');
INSERT INTO `wp_usermeta` VALUES (294, 22, 'nickname', 'Etu1');
INSERT INTO `wp_usermeta` VALUES (295, 22, 'description', '');
INSERT INTO `wp_usermeta` VALUES (296, 22, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (297, 22, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (298, 22, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (299, 22, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (300, 22, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (301, 22, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (302, 22, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (303, 22, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (304, 23, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (305, 23, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (306, 23, 'nickname', 'ups');
INSERT INTO `wp_usermeta` VALUES (307, 23, 'description', '');
INSERT INTO `wp_usermeta` VALUES (308, 23, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (309, 23, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (310, 23, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (311, 23, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (312, 23, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (313, 23, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (314, 23, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (315, 23, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (319, 24, 'first_name', 'Bernard');
INSERT INTO `wp_usermeta` VALUES (320, 24, 'last_name', 'Cherbonneau');
INSERT INTO `wp_usermeta` VALUES (321, 24, 'nickname', 'cherbonneau');
INSERT INTO `wp_usermeta` VALUES (322, 24, 'description', '');
INSERT INTO `wp_usermeta` VALUES (323, 24, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (324, 24, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (325, 24, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (326, 24, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (327, 24, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (328, 24, 'wp_capabilities', 'a:2:{s:13:"responsableue";s:1:"1";s:17:"SPF Manage Forums";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (329, 24, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (330, 24, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (343, 24, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (344, 24, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (345, 24, 'jabber', 'admin');
INSERT INTO `wp_usermeta` VALUES (361, 24, 'closedpostboxes_dashboard', 'a:0:{}');
INSERT INTO `wp_usermeta` VALUES (362, 24, 'metaboxhidden_dashboard', 'a:0:{}');
INSERT INTO `wp_usermeta` VALUES (363, 24, 'wp_user-settings', 'wpfb_adv_uploader=1');
INSERT INTO `wp_usermeta` VALUES (364, 24, 'wp_user-settings-time', '1367277120');
INSERT INTO `wp_usermeta` VALUES (365, 25, 'first_name', 'amine');
INSERT INTO `wp_usermeta` VALUES (366, 25, 'last_name', 'louhidi');
INSERT INTO `wp_usermeta` VALUES (367, 25, 'nickname', 'louhidi');
INSERT INTO `wp_usermeta` VALUES (368, 25, 'description', '');
INSERT INTO `wp_usermeta` VALUES (369, 25, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (370, 25, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (371, 25, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (372, 25, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (373, 25, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (374, 25, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (375, 25, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (376, 25, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (377, 26, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (378, 26, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (379, 26, 'nickname', 'louhidi2');
INSERT INTO `wp_usermeta` VALUES (380, 26, 'description', '');
INSERT INTO `wp_usermeta` VALUES (381, 26, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (382, 26, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (383, 26, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (384, 26, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (385, 26, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (386, 26, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (387, 26, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (388, 26, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (389, 27, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (390, 27, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (391, 27, 'nickname', 'etu2');
INSERT INTO `wp_usermeta` VALUES (392, 27, 'description', '');
INSERT INTO `wp_usermeta` VALUES (393, 27, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (394, 27, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (395, 27, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (396, 27, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (397, 27, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (398, 27, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (399, 27, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (400, 27, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (401, 28, 'first_name', 'Diallo');
INSERT INTO `wp_usermeta` VALUES (402, 28, 'last_name', 'Abdourahamane');
INSERT INTO `wp_usermeta` VALUES (403, 28, 'nickname', 'duijj');
INSERT INTO `wp_usermeta` VALUES (404, 28, 'description', '');
INSERT INTO `wp_usermeta` VALUES (405, 28, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (406, 28, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (407, 28, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (408, 28, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (409, 28, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (410, 28, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (411, 28, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (412, 28, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (413, 29, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (414, 29, 'last_name', 'ANATOLE');
INSERT INTO `wp_usermeta` VALUES (415, 29, 'nickname', 'Kevin');
INSERT INTO `wp_usermeta` VALUES (416, 29, 'description', '');
INSERT INTO `wp_usermeta` VALUES (417, 29, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (418, 29, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (419, 29, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (420, 29, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (421, 29, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (422, 29, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (423, 29, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (424, 29, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (425, 29, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (426, 29, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (427, 29, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (428, 30, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (429, 30, 'last_name', 'ARONDEL');
INSERT INTO `wp_usermeta` VALUES (430, 30, 'nickname', 'Damien');
INSERT INTO `wp_usermeta` VALUES (431, 30, 'description', '');
INSERT INTO `wp_usermeta` VALUES (432, 30, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (433, 30, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (434, 30, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (435, 30, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (436, 30, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (437, 30, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (438, 30, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (439, 30, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (440, 30, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (441, 30, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (442, 30, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (458, 32, 'first_name', 'Benjamin');
INSERT INTO `wp_usermeta` VALUES (459, 32, 'last_name', 'BABIC');
INSERT INTO `wp_usermeta` VALUES (460, 32, 'nickname', 'Benjamin');
INSERT INTO `wp_usermeta` VALUES (461, 32, 'description', '');
INSERT INTO `wp_usermeta` VALUES (462, 32, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (463, 32, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (464, 32, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (465, 32, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (466, 32, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (467, 32, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (468, 32, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (469, 32, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (470, 32, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (471, 32, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (472, 32, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (473, 33, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (474, 33, 'last_name', 'BARREAU');
INSERT INTO `wp_usermeta` VALUES (475, 33, 'nickname', 'Julien');
INSERT INTO `wp_usermeta` VALUES (476, 33, 'description', '');
INSERT INTO `wp_usermeta` VALUES (477, 33, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (478, 33, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (479, 33, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (480, 33, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (481, 33, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (482, 33, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (483, 33, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (484, 33, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (485, 33, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (486, 33, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (487, 33, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (488, 34, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (489, 34, 'last_name', 'BENOIT');
INSERT INTO `wp_usermeta` VALUES (490, 34, 'nickname', 'Remi');
INSERT INTO `wp_usermeta` VALUES (491, 34, 'description', '');
INSERT INTO `wp_usermeta` VALUES (492, 34, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (493, 34, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (494, 34, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (495, 34, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (496, 34, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (497, 34, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (498, 34, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (499, 34, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (500, 34, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (501, 34, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (502, 34, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (503, 35, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (504, 35, 'last_name', 'BERTRAND');
INSERT INTO `wp_usermeta` VALUES (505, 35, 'nickname', 'Nathanael');
INSERT INTO `wp_usermeta` VALUES (506, 35, 'description', '');
INSERT INTO `wp_usermeta` VALUES (507, 35, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (508, 35, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (509, 35, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (510, 35, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (511, 35, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (512, 35, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (513, 35, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (514, 35, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (515, 35, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (516, 35, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (517, 35, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (518, 36, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (519, 36, 'last_name', 'BOUTCHICHE');
INSERT INTO `wp_usermeta` VALUES (520, 36, 'nickname', 'Mehdi');
INSERT INTO `wp_usermeta` VALUES (521, 36, 'description', '');
INSERT INTO `wp_usermeta` VALUES (522, 36, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (523, 36, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (524, 36, 'admin_color', 'classic');
INSERT INTO `wp_usermeta` VALUES (525, 36, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (526, 36, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (527, 36, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (528, 36, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (529, 36, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (530, 36, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (531, 36, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (532, 36, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (533, 37, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (534, 37, 'last_name', 'BURLACU');
INSERT INTO `wp_usermeta` VALUES (535, 37, 'nickname', 'Alexandru');
INSERT INTO `wp_usermeta` VALUES (536, 37, 'description', '');
INSERT INTO `wp_usermeta` VALUES (537, 37, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (538, 37, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (539, 37, 'admin_color', 'classic');
INSERT INTO `wp_usermeta` VALUES (540, 37, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (541, 37, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (542, 37, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (543, 37, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (544, 37, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (545, 37, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (546, 37, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (547, 37, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (548, 38, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (549, 38, 'last_name', 'BUSSENOT');
INSERT INTO `wp_usermeta` VALUES (550, 38, 'nickname', 'Robin');
INSERT INTO `wp_usermeta` VALUES (551, 38, 'description', '');
INSERT INTO `wp_usermeta` VALUES (552, 38, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (553, 38, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (554, 38, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (555, 38, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (556, 38, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (557, 38, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (558, 38, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (559, 38, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (560, 38, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (561, 38, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (562, 38, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (563, 39, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (564, 39, 'last_name', 'CARASSUS');
INSERT INTO `wp_usermeta` VALUES (565, 39, 'nickname', 'Vincent');
INSERT INTO `wp_usermeta` VALUES (566, 39, 'description', '');
INSERT INTO `wp_usermeta` VALUES (567, 39, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (568, 39, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (569, 39, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (570, 39, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (571, 39, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (572, 39, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (573, 39, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (574, 39, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (575, 39, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (576, 39, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (577, 39, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (578, 40, 'first_name', 'Virgil');
INSERT INTO `wp_usermeta` VALUES (579, 40, 'last_name', 'CERVICESCU');
INSERT INTO `wp_usermeta` VALUES (580, 40, 'nickname', 'Virgil');
INSERT INTO `wp_usermeta` VALUES (581, 40, 'description', '');
INSERT INTO `wp_usermeta` VALUES (582, 40, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (583, 40, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (584, 40, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (585, 40, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (586, 40, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (587, 40, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (588, 40, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (589, 40, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (590, 40, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (591, 40, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (592, 40, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (593, 41, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (594, 41, 'last_name', 'CLAVEL');
INSERT INTO `wp_usermeta` VALUES (595, 41, 'nickname', 'Florian');
INSERT INTO `wp_usermeta` VALUES (596, 41, 'description', '');
INSERT INTO `wp_usermeta` VALUES (597, 41, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (598, 41, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (599, 41, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (600, 41, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (601, 41, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (602, 41, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (603, 41, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (604, 41, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (605, 41, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (606, 41, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (607, 41, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (608, 42, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (609, 42, 'last_name', 'FAVIER');
INSERT INTO `wp_usermeta` VALUES (610, 42, 'nickname', 'Loic');
INSERT INTO `wp_usermeta` VALUES (611, 42, 'description', '');
INSERT INTO `wp_usermeta` VALUES (612, 42, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (613, 42, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (614, 42, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (615, 42, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (616, 42, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (617, 42, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (618, 42, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (619, 42, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (620, 42, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (621, 42, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (622, 42, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (623, 43, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (624, 43, 'last_name', 'GUILLEUX');
INSERT INTO `wp_usermeta` VALUES (625, 43, 'nickname', 'Jordan');
INSERT INTO `wp_usermeta` VALUES (626, 43, 'description', '');
INSERT INTO `wp_usermeta` VALUES (627, 43, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (628, 43, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (629, 43, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (630, 43, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (631, 43, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (632, 43, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (633, 43, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (634, 43, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (635, 43, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (636, 43, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (637, 43, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (638, 44, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (639, 44, 'last_name', 'HALCHIN');
INSERT INTO `wp_usermeta` VALUES (640, 44, 'nickname', 'Alexandra');
INSERT INTO `wp_usermeta` VALUES (641, 44, 'description', '');
INSERT INTO `wp_usermeta` VALUES (642, 44, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (643, 44, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (644, 44, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (645, 44, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (646, 44, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (647, 44, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (648, 44, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (649, 44, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (650, 44, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (651, 44, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (652, 44, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (653, 45, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (654, 45, 'last_name', 'KEM');
INSERT INTO `wp_usermeta` VALUES (655, 45, 'nickname', 'Oudom');
INSERT INTO `wp_usermeta` VALUES (656, 45, 'description', '');
INSERT INTO `wp_usermeta` VALUES (657, 45, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (658, 45, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (659, 45, 'admin_color', 'classic');
INSERT INTO `wp_usermeta` VALUES (660, 45, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (661, 45, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (662, 45, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (663, 45, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (664, 45, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (665, 45, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (666, 45, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (667, 45, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (668, 46, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (669, 46, 'last_name', 'MOUYSSET');
INSERT INTO `wp_usermeta` VALUES (670, 46, 'nickname', 'Florent');
INSERT INTO `wp_usermeta` VALUES (671, 46, 'description', '');
INSERT INTO `wp_usermeta` VALUES (672, 46, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (673, 46, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (674, 46, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (675, 46, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (676, 46, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (677, 46, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (678, 46, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (679, 46, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (680, 46, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (681, 46, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (682, 46, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (683, 47, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (684, 47, 'last_name', 'RHAFRANE');
INSERT INTO `wp_usermeta` VALUES (685, 47, 'nickname', 'Mohammed akram');
INSERT INTO `wp_usermeta` VALUES (686, 47, 'description', '');
INSERT INTO `wp_usermeta` VALUES (687, 47, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (688, 47, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (689, 47, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (690, 47, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (691, 47, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (692, 47, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (693, 47, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (694, 47, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (695, 47, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (696, 47, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (697, 47, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (698, 48, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (699, 48, 'last_name', 'ROBERT');
INSERT INTO `wp_usermeta` VALUES (700, 48, 'nickname', 'Axel');
INSERT INTO `wp_usermeta` VALUES (701, 48, 'description', '');
INSERT INTO `wp_usermeta` VALUES (702, 48, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (703, 48, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (704, 48, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (705, 48, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (706, 48, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (707, 48, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (708, 48, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (709, 48, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (710, 48, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (711, 48, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (712, 48, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (713, 49, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (714, 49, 'last_name', 'RODDE');
INSERT INTO `wp_usermeta` VALUES (715, 49, 'nickname', 'Dorian');
INSERT INTO `wp_usermeta` VALUES (716, 49, 'description', '');
INSERT INTO `wp_usermeta` VALUES (717, 49, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (718, 49, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (719, 49, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (720, 49, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (721, 49, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (722, 49, 'wp_capabilities', 'a:0:{}');
INSERT INTO `wp_usermeta` VALUES (723, 49, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (724, 49, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (725, 49, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (726, 49, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (727, 49, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (728, 50, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (729, 50, 'last_name', 'RODDE');
INSERT INTO `wp_usermeta` VALUES (730, 50, 'nickname', 'Vivian');
INSERT INTO `wp_usermeta` VALUES (731, 50, 'description', '');
INSERT INTO `wp_usermeta` VALUES (732, 50, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (733, 50, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (734, 50, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (735, 50, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (736, 50, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (737, 50, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (738, 50, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (739, 50, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (740, 50, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (741, 50, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (742, 50, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (743, 51, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (744, 51, 'last_name', 'SENHAJI');
INSERT INTO `wp_usermeta` VALUES (745, 51, 'nickname', 'Ismail');
INSERT INTO `wp_usermeta` VALUES (746, 51, 'description', '');
INSERT INTO `wp_usermeta` VALUES (747, 51, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (748, 51, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (749, 51, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (750, 51, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (751, 51, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (752, 51, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (753, 51, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (754, 51, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (755, 51, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (756, 51, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (757, 51, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (758, 52, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (759, 52, 'last_name', 'SIMAR');
INSERT INTO `wp_usermeta` VALUES (760, 52, 'nickname', 'Jeremy');
INSERT INTO `wp_usermeta` VALUES (761, 52, 'description', '');
INSERT INTO `wp_usermeta` VALUES (762, 52, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (763, 52, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (764, 52, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (765, 52, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (766, 52, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (767, 52, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (768, 52, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (769, 52, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (770, 52, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (771, 52, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (772, 52, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (773, 53, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (774, 53, 'last_name', 'SOARE');
INSERT INTO `wp_usermeta` VALUES (775, 53, 'nickname', 'Andrea');
INSERT INTO `wp_usermeta` VALUES (776, 53, 'description', '');
INSERT INTO `wp_usermeta` VALUES (777, 53, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (778, 53, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (779, 53, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (780, 53, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (781, 53, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (782, 53, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (783, 53, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (784, 53, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (785, 53, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (786, 53, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (787, 53, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (788, 54, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (789, 54, 'last_name', 'VARLEZ');
INSERT INTO `wp_usermeta` VALUES (790, 54, 'nickname', 'Xavier');
INSERT INTO `wp_usermeta` VALUES (791, 54, 'description', '');
INSERT INTO `wp_usermeta` VALUES (792, 54, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (793, 54, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (794, 54, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (795, 54, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (796, 54, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (797, 54, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (798, 54, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (799, 54, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (800, 54, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (801, 54, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (802, 54, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (803, 55, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (804, 55, 'last_name', 'WARIN');
INSERT INTO `wp_usermeta` VALUES (805, 55, 'nickname', 'Laurent');
INSERT INTO `wp_usermeta` VALUES (806, 55, 'description', '');
INSERT INTO `wp_usermeta` VALUES (807, 55, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (808, 55, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (809, 55, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (810, 55, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (811, 55, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (812, 55, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (813, 55, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (814, 55, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (815, 55, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (816, 55, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (817, 55, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (818, 56, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (819, 56, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (820, 56, 'nickname', 'group1');
INSERT INTO `wp_usermeta` VALUES (821, 56, 'description', '');
INSERT INTO `wp_usermeta` VALUES (822, 56, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (823, 56, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (824, 56, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (825, 56, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (826, 56, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (827, 56, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (828, 56, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (829, 56, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (830, 57, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (831, 57, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (832, 57, 'nickname', 'group2');
INSERT INTO `wp_usermeta` VALUES (833, 57, 'description', '');
INSERT INTO `wp_usermeta` VALUES (834, 57, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (835, 57, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (836, 57, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (837, 57, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (838, 57, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (839, 57, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (840, 57, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (841, 57, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (842, 58, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (843, 58, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (844, 58, 'nickname', 'group3');
INSERT INTO `wp_usermeta` VALUES (845, 58, 'description', '');
INSERT INTO `wp_usermeta` VALUES (846, 58, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (847, 58, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (848, 58, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (849, 58, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (850, 58, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (851, 58, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (852, 58, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (853, 58, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (854, 59, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (855, 59, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (856, 59, 'nickname', 'group4');
INSERT INTO `wp_usermeta` VALUES (857, 59, 'description', '');
INSERT INTO `wp_usermeta` VALUES (858, 59, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (859, 59, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (860, 59, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (861, 59, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (862, 59, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (863, 59, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (864, 59, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (865, 59, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (866, 60, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (867, 60, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (868, 60, 'nickname', 'group5');
INSERT INTO `wp_usermeta` VALUES (869, 60, 'description', '');
INSERT INTO `wp_usermeta` VALUES (870, 60, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (871, 60, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (872, 60, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (873, 60, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (874, 60, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (875, 60, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (876, 60, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (877, 60, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (878, 61, 'first_name', '');
INSERT INTO `wp_usermeta` VALUES (879, 61, 'last_name', '');
INSERT INTO `wp_usermeta` VALUES (880, 61, 'nickname', 'SecondLoic');
INSERT INTO `wp_usermeta` VALUES (881, 61, 'description', '');
INSERT INTO `wp_usermeta` VALUES (882, 61, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (883, 61, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (884, 61, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (885, 61, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (886, 61, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (887, 61, 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (888, 61, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (889, 61, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (890, 61, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (891, 61, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (892, 61, 'wpmem_reg_ip', '130.120.209.26');
INSERT INTO `wp_usermeta` VALUES (893, 61, 'wpmem_reg_url', 'http://www.gdnlteamtest.netsoro.net/wordpress/?p=1');
INSERT INTO `wp_usermeta` VALUES (907, 63, 'first_name', 'Vincent');
INSERT INTO `wp_usermeta` VALUES (908, 63, 'last_name', 'Tertre');
INSERT INTO `wp_usermeta` VALUES (909, 63, 'nickname', 'Vincent');
INSERT INTO `wp_usermeta` VALUES (910, 63, 'description', '');
INSERT INTO `wp_usermeta` VALUES (911, 63, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (912, 63, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (913, 63, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (914, 63, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (915, 63, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (916, 63, 'wp_capabilities', 'a:1:{s:9:"encadrant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (917, 63, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (918, 63, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (919, 63, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (920, 63, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (921, 63, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (922, 9, 'aim', '');
INSERT INTO `wp_usermeta` VALUES (923, 9, 'yim', '');
INSERT INTO `wp_usermeta` VALUES (924, 9, 'jabber', '');
INSERT INTO `wp_usermeta` VALUES (925, 64, 'first_name', 'kevin');
INSERT INTO `wp_usermeta` VALUES (926, 64, 'last_name', 'serin');
INSERT INTO `wp_usermeta` VALUES (927, 64, 'nickname', 'kevinS');
INSERT INTO `wp_usermeta` VALUES (928, 64, 'description', '');
INSERT INTO `wp_usermeta` VALUES (929, 64, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (930, 64, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (931, 64, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (932, 64, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (933, 64, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (934, 64, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (935, 64, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (936, 64, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (937, 65, 'first_name', 'Bernard');
INSERT INTO `wp_usermeta` VALUES (938, 65, 'last_name', 'Cherbonneau');
INSERT INTO `wp_usermeta` VALUES (939, 65, 'nickname', 'nouveau');
INSERT INTO `wp_usermeta` VALUES (940, 65, 'description', '');
INSERT INTO `wp_usermeta` VALUES (941, 65, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (942, 65, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (943, 65, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (944, 65, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (945, 65, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (946, 65, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (947, 65, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (948, 65, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');
INSERT INTO `wp_usermeta` VALUES (949, 5, 'tos', 'agree');
INSERT INTO `wp_usermeta` VALUES (950, 66, 'first_name', 'frank');
INSERT INTO `wp_usermeta` VALUES (951, 66, 'last_name', 'Arrecot');
INSERT INTO `wp_usermeta` VALUES (952, 66, 'nickname', 'frank');
INSERT INTO `wp_usermeta` VALUES (953, 66, 'description', '');
INSERT INTO `wp_usermeta` VALUES (954, 66, 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES (955, 66, 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES (956, 66, 'admin_color', 'fresh');
INSERT INTO `wp_usermeta` VALUES (957, 66, 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES (958, 66, 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES (959, 66, 'wp_capabilities', 'a:1:{s:8:"etudiant";s:1:"1";}');
INSERT INTO `wp_usermeta` VALUES (960, 66, 'wp_user_level', '0');
INSERT INTO `wp_usermeta` VALUES (961, 66, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_users`
-- 

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 AUTO_INCREMENT=67 ;

-- 
-- Contenu de la table `wp_users`
-- 

INSERT INTO `wp_users` VALUES (1, 'admin', '$P$Bt1PbIT0GR0AcZiIYvSk19DN3rP2Rc.', 'admin', 'gdnlteam@gmail.com', '', '2013-03-14 10:47:53', '', 0, 'admin');
INSERT INTO `wp_users` VALUES (3, 'amel', '$P$BIpeMCmW/tQ25G9DnBB1J5B.x2rJk5.', 'amel', 'amelgrim@gmail.com', '', '2013-03-17 17:17:14', '', 0, 'amel');
INSERT INTO `wp_users` VALUES (4, 'ndeye mariane', '$P$BQc1KoiJ6WFtnIu/mYbF/LUN6d1Ama0', 'ndeye-mariane', 'ndmariane@gmail.com', '', '2013-03-17 17:17:17', '', 0, 'ndeye mariane');
INSERT INTO `wp_users` VALUES (5, 'mohamed amine', '$P$B29dVYX1huzDqJRjhH7.e9aQl7NebR0', 'mohamed-amine', 'a.louhidi@hotmail.fr', '', '2013-03-17 17:17:19', '', 0, 'mohamed amine');
INSERT INTO `wp_users` VALUES (7, 'encadrant', '$P$BZ33Z1mvio37/WJAeGcvcI.WjTnzil1', 'encadrant', 'encadrant@astuce.com', '', '2013-03-18 09:20:25', '', 0, 'encadrant');
INSERT INTO `wp_users` VALUES (8, 'abdd.diallo25', '$P$Bk3lA7N4Gt.vDAqFrr3BjFJNnpl0/E/', 'abdd-diallo25', 'abdd.diallo31@hotmail.com', '', '2013-03-26 11:25:17', '', 0, 'abdd.diallo25');
INSERT INTO `wp_users` VALUES (9, 'admin5', '$P$BnwTYYFJYf/OYENepAg4EhGRZhR/fU.', 'admin5', 'abdd.diallo31@hotmail.fr', 'http://admin5', '2013-04-14 10:06:25', '', 0, 'admin5');
INSERT INTO `wp_users` VALUES (10, 'diallo5', '$P$Bjx23lQnRwoIFRVG4NqtPW3ba7VHIN1', 'diallo5', 'abdd.diallo25@gmail.com', '', '2013-04-25 08:39:53', '', 0, 'diallo5');
INSERT INTO `wp_users` VALUES (13, 'dial', '$P$BSrnDgKoJaDY9DcT5uhskNEX52UIS6.', 'dial', 'abdd.djjjiallo@gmail.com', 'http://admin', '2013-04-28 18:09:17', '', 0, 'dial');
INSERT INTO `wp_users` VALUES (14, 'cool1', '$P$BwOYfA1GBQUWl5q0CmE5W/gZ3syE6x/', 'cool1', 'abdd.dia14llo@gmail.com', 'http://admin', '2013-04-28 18:16:16', '', 0, 'cool1');
INSERT INTO `wp_users` VALUES (15, 'etu', '$P$B.VEdlmtGj0bZ9TsMLMjwR2ft4gG.N/', 'etu', 'etu@etu.fr', 'http://admin', '2013-04-28 18:23:45', '', 0, 'etu');
INSERT INTO `wp_users` VALUES (16, 'abdel', '$P$BqGYvvywFckChwCVAHUnEP57w3Wd9w/', 'abdel', 'abdd.diallo@gmail.com', '', '2013-04-28 18:45:27', '', 0, 'abdel');
INSERT INTO `wp_users` VALUES (17, 'netsoro', '$P$Bz25uHS.v74Ew3V/.IWnOfrF.FVr9l.', 'netsoro', 'abdd.diajdjjdjllo@gmail.com', 'http://admin', '2013-04-28 21:28:17', '', 0, 'netsoro');
INSERT INTO `wp_users` VALUES (18, 'testt', '$P$BEpRD9BpOS6xc0XYllH6oxld4cKLYL.', 'testt', 'abdd.dialltesto@gmail.com', 'http://admin', '2013-04-28 23:58:56', '', 0, 'testt');
INSERT INTO `wp_users` VALUES (19, 'test12', '$P$B56Iigzm8vsx0LR7x4F2mI0NuXAeWl1', 'test12', 'abdd.dial1ltesto@gmail.com', 'http://admin', '2013-04-29 00:00:03', '', 0, 'test12');
INSERT INTO `wp_users` VALUES (20, 'diallo252', '$P$BsoJCAxijtSh6oZJwcU.xzSazuzzp30', 'diallo252', 'abdd.diallo252@gmail.com', '', '2013-04-29 02:28:02', '', 0, 'diallo252');
INSERT INTO `wp_users` VALUES (21, 'dada', '$P$BP0t1fB5lNh6T3gz.wTWaI2KSX1LJk.', 'dada', 'abdd.diallodada@gmail.com', '', '2013-04-29 03:07:09', '', 0, 'dada');
INSERT INTO `wp_users` VALUES (22, 'Etu1', '$P$BUHk.mbjpjbPMP1hmMgsNFwkWapttX0', 'etu1', 'abdd.dialloetu1@gmail.com', '', '2013-04-29 08:18:13', '', 0, 'Etu1');
INSERT INTO `wp_users` VALUES (23, 'ups', '$P$BGNZJn1JemDocdYvpfdXwrVahkZo551', 'ups', 'ups@gmail.com', '', '2013-04-29 11:03:52', '', 0, 'ups');
INSERT INTO `wp_users` VALUES (24, 'cherbonneau', '$P$BjFFM.Qs9/0mSbyrz6a05/9UPOe2/6/', 'cherbonneau', 'bernard.cherbonneau@irit.fr', '', '2013-04-29 18:49:13', '', 0, 'cherbonneau');
INSERT INTO `wp_users` VALUES (25, 'louhidi', '$P$BJpn0w/1YmmIzfy0WdV9hgYI4OgGAh/', 'louhidi', 'a.louhidi+1@hotmail.fr', '', '2013-05-19 18:15:28', '', 0, 'louhidi');
INSERT INTO `wp_users` VALUES (26, 'louhidi2', '$P$BUT2CtUvadw12i2hM6rIm6Uky4Jiwf/', 'louhidi2', 'a.louhidi+2@hotmail.fr', '', '2013-05-19 18:19:40', '', 0, 'louhidi2');
INSERT INTO `wp_users` VALUES (27, 'etu2', '$P$BkGaTlt4r0hTxQ1fObleOBaDw.gsu41', 'etu2', 'a.louhidi+3@hotmail.fr', '', '2013-05-20 08:16:54', '', 0, 'etu2');
INSERT INTO `wp_users` VALUES (28, 'duijj', '$P$B6zKGGeY9yZRB9NW9JNaHU7Dy1WI.91', 'duijj', 'abdd.diallo366@gmail.com', '', '2013-05-20 08:36:46', '', 0, 'duijj');
INSERT INTO `wp_users` VALUES (29, 'Kevin', '$P$B3tyAn3ZwurUpHF.xv.9ENl81zq1dB1', 'kevin', 'kevinanatole@yahoo.fr', '', '2013-09-27 10:34:46', '', 0, 'Kevin');
INSERT INTO `wp_users` VALUES (30, 'Damien', '$P$BK0HRWqpO3AI96Gi9uWnqU.bTVpIQf.', 'damien', 'damien.arondel@gmail.com', '', '2013-09-27 10:34:47', '', 0, 'Damien');
INSERT INTO `wp_users` VALUES (32, 'Benjamin', '$P$BO4It.1BGpr0F3hqckahofWjXXSJ6Q.', 'benjamin', 'benjamin.babic@hotmail.fr', '', '2013-09-27 10:34:48', '', 0, 'Benjamin');
INSERT INTO `wp_users` VALUES (33, 'Julien', '$P$ByB.sU5lzje9CEaVHvshwa.VTCK2/k1', 'julien', 'julien.barreau@laposte.net', '', '2013-09-27 10:34:49', '', 0, 'Julien');
INSERT INTO `wp_users` VALUES (34, 'Remi', '$P$B2s6RfO62jhmpEJ12VegRGXnhHpY.8/', 'remi', 'r3m1.benoit@gmail.com', '', '2013-09-27 10:34:50', '', 0, 'Remi');
INSERT INTO `wp_users` VALUES (35, 'Nathanael', '$P$BEKsx.gOwr1Enj2m5pKxf8fXH54MCP/', 'nathanael', 'nathanael.bertrand@gmail.com', '', '2013-09-27 10:34:50', '', 0, 'Nathanael');
INSERT INTO `wp_users` VALUES (36, 'Mehdi', '$P$B80CnnKGOfqogJAGaBpJwgi2tpCyt6.', 'mehdi', 'mehdi-but@hotmail.fr', '', '2013-09-27 10:34:51', '', 0, 'Mehdi');
INSERT INTO `wp_users` VALUES (37, 'Alexandru', '$P$BD4J3NNw5t969U6XHo7zlszkv8vz6a0', 'alexandru', 'alexandru.burlacu11@gmail.com', '', '2013-09-27 10:34:51', '', 0, 'Alexandru');
INSERT INTO `wp_users` VALUES (38, 'Robin', '$P$B6PrDNrpk3ewdagaPbb56.O8n6utyK.', 'robin', 'bussenot.robin@gmail.com', '', '2013-09-27 10:34:55', '', 0, 'Robin');
INSERT INTO `wp_users` VALUES (39, 'Vincent', '$P$BJY3al57QLadH13/vMgQpt2cDyBJJ71', 'vincent', 'vincentcarassus@gmail.com', '', '2013-09-27 10:34:55', '', 0, 'Vincent');
INSERT INTO `wp_users` VALUES (40, 'Virgil', '$P$Bpjj8PkeEQ8.CanukPbtVLHbQiEe4N1', 'virgil', 'cer.virgil@gmail.com', '', '2013-09-27 10:34:56', '', 0, 'Virgil');
INSERT INTO `wp_users` VALUES (41, 'Florian', '$P$BN/eOE/mYR9Mm20oDnEjwZFrTAtPC7/', 'florian', 'florian.clavel@live.fr', '', '2013-09-27 10:34:56', '', 0, 'Florian');
INSERT INTO `wp_users` VALUES (42, 'Loic', '$P$B/7dorBWogMSFuhkOfOc3tLYnXdV2W1', 'loic', 'favier.loic.31@gmail.com', '', '2013-09-27 10:35:00', '', 0, 'Loic');
INSERT INTO `wp_users` VALUES (43, 'Jordan', '$P$BzLj82UhU01TJP1Naw6EPrj3eDM1ao0', 'jordan', 'jordan.guilleux@univ-tlse3.fr', '', '2013-09-27 10:35:00', '', 0, 'Jordan');
INSERT INTO `wp_users` VALUES (44, 'Alexandra', '$P$BSBzcWFvNQXCPQAVzxSRIi8go.sMJF0', 'alexandra', 'halchin.alexandra@gmail.com', '', '2013-09-27 10:35:04', '', 0, 'Alexandra');
INSERT INTO `wp_users` VALUES (45, 'Oudom', '$P$BZDQwqDA4FrbOUeGwk7XYJ5j26p3eL1', 'oudom', 'kemoudom.scholar@gmail.com', '', '2013-09-27 10:35:04', '', 0, 'Oudom');
INSERT INTO `wp_users` VALUES (46, 'Florent', '$P$BjSj18RVH.flJ2.lmgD6xjF9sWdQz80', 'florent', 'mouysset.florent@gmail.com', '', '2013-09-27 10:35:05', '', 0, 'Florent');
INSERT INTO `wp_users` VALUES (47, 'Mohammed akram', '$P$BZZgJo6YYbNqNcNCK87iWhmF8pDPVi0', 'mohammed-akram', '20contact12@gmail.com', '', '2013-09-27 10:35:06', '', 0, 'Mohammed akram');
INSERT INTO `wp_users` VALUES (48, 'Axel', '$P$BO.C68A2GkY.btT/6TwQmsfn6jUmEl1', 'axel', 'robert-axel@hotmail.fr', '', '2013-09-27 10:35:07', '', 0, 'Axel');
INSERT INTO `wp_users` VALUES (49, 'Dorian', '$P$BHkSB2f09xddWn5ZBHDudkEt1l3s41.', 'dorian', 'dorian.rodde@gmail.com', '', '2013-09-27 10:35:07', '', 0, 'Dorian');
INSERT INTO `wp_users` VALUES (50, 'Vivian', '$P$BsyMe9DVze6vQZVLYyj/K3xkqAQXEm1', 'vivian', 'vivian.rodde@laposte.net', '', '2013-09-27 10:35:08', '', 0, 'Vivian');
INSERT INTO `wp_users` VALUES (51, 'Ismail', '$P$BzYfzHeaYlsF1TJWKDAhVUG9WddNiK0', 'ismail', 'senhaji91@hotmail.fr', '', '2013-09-27 10:35:09', '', 0, 'Ismail');
INSERT INTO `wp_users` VALUES (52, 'Jeremy', '$P$BjYUVw3IAbzBCzAB06oHfQ2Tau.fGu/', 'jeremy', 'simar.jeremy@live.fr', '', '2013-09-27 10:35:09', '', 0, 'Jeremy');
INSERT INTO `wp_users` VALUES (53, 'Andrea', '$P$BB42sghuHs6JKlCddnM9H57vQ028LF1', 'andrea', 'soare.andreea.georgiana@gmail.com', '', '2013-09-27 10:35:10', '', 0, 'Andrea');
INSERT INTO `wp_users` VALUES (54, 'Xavier', '$P$BMzCe2l1Q8vgGAkvfm8yLSaKedTfAS1', 'xavier', 'xvarlez@gmail.com', '', '2013-09-27 10:35:11', '', 0, 'Xavier');
INSERT INTO `wp_users` VALUES (55, 'Laurent', '$P$ByQG.BYl1nbnmX5kgF6loiuWOmdrm6.', 'laurent', 'laurent.warin@sfr.fr', '', '2013-09-27 10:35:11', '', 0, 'Laurent');
INSERT INTO `wp_users` VALUES (56, 'group1', '$P$B6TU.k6lOlzupkfv3SuJ2avW1Ci3kr0', 'group1', 'a.louhidi+g1@hotmail.fr', '', '2013-09-27 10:51:54', '', 0, 'group1');
INSERT INTO `wp_users` VALUES (57, 'group2', '$P$BLQjCWPB0DHUM4oNwRFTNo3sW4J4ia0', 'group2', 'a.louhidi+g2@hotmail.fr', '', '2013-09-27 10:53:44', '', 0, 'group2');
INSERT INTO `wp_users` VALUES (58, 'group3', '$P$BQ9PfEZPeCJFOmja3wMfuyV975oJS/0', 'group3', 'a.louhidi+g3@hotmail.fr', '', '2013-09-27 10:55:30', '', 0, 'group3');
INSERT INTO `wp_users` VALUES (59, 'group4', '$P$BckrkJhqZ1JGznFGomqkkhjEvK2QQO0', 'group4', 'a.louhidi+g4@hotmail.fr', '', '2013-09-27 11:01:13', '', 0, 'group4');
INSERT INTO `wp_users` VALUES (60, 'group5', '$P$BvBX/FBkFkZhQWNN9uglBrxsF1OzIQ0', 'group5', 'a.louhidi+g5@hotmail.fr', '', '2013-09-27 11:02:23', '', 0, 'group5');
INSERT INTO `wp_users` VALUES (61, 'SecondLoic', '$P$B9DXwIr2lLheS2PhYyi3d1yV/BCK0K1', 'SecondLoic', 'loclamor@gmail.com', '', '2013-09-27 11:42:28', '', 0, 'SecondLoic');
INSERT INTO `wp_users` VALUES (63, 'vincent1', '$P$Bl1JpD0xpJlFiIVHoBh.Kr8yrCx2O50', 'vincent1', 'vincent.tertre@gmail.com', 'http://www.gdnlteamtest.netsoro.net', '2013-09-27 12:23:22', '', 0, 'vincent');
INSERT INTO `wp_users` VALUES (64, 'kevinS', '$P$BPxUj/CbeD.mgAVGP45C.syNR9c8CU.', 'kevins', 'kevin.serin@hotlook.fr', 'http://www.gdnlteamtest.netsoro.net', '2013-10-02 14:17:08', '', 0, 'kevinS');
INSERT INTO `wp_users` VALUES (65, 'nouveau', '$P$BRoAnwJe04TmL8HAcN4JyYRtg1Jp7i1', 'nouveau', 'toulouse70fr@yahoo.fr', '', '2013-10-02 14:28:10', '', 0, 'nouveau');
INSERT INTO `wp_users` VALUES (66, 'frank', '$P$BFXYraPzkS/lec9q7XYzV/G.DxmGED0', 'frank', 'knarf_@hotmail.fr', '', '2013-10-03 12:14:54', '', 0, 'frank');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_wpfb_cats`
-- 

CREATE TABLE `wp_wpfb_cats` (
  `cat_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) NOT NULL DEFAULT '',
  `cat_description` text,
  `cat_folder` varchar(300) NOT NULL DEFAULT '',
  `cat_path` varchar(2000) NOT NULL DEFAULT '',
  `cat_parent` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_num_files` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_num_files_total` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_user_roles` varchar(2000) NOT NULL DEFAULT '',
  `cat_owner` bigint(20) unsigned DEFAULT NULL,
  `cat_icon` varchar(255) DEFAULT NULL,
  `cat_exclude_browser` enum('0','1') NOT NULL DEFAULT '0',
  `cat_order` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `UNIQUE_FOLDER` (`cat_folder`,`cat_parent`),
  FULLTEXT KEY `USER_ROLES` (`cat_user_roles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_wpfb_cats`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_wpfb_files`
-- 

CREATE TABLE `wp_wpfb_files` (
  `file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(300) NOT NULL DEFAULT '',
  `file_path` varchar(2000) NOT NULL DEFAULT '',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_mtime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_hash` char(32) NOT NULL,
  `file_remote_uri` varchar(255) NOT NULL DEFAULT '',
  `file_thumbnail` varchar(255) DEFAULT NULL,
  `file_display_name` varchar(255) NOT NULL DEFAULT '',
  `file_description` text,
  `file_tags` varchar(255) NOT NULL DEFAULT '',
  `file_requirement` varchar(255) DEFAULT NULL,
  `file_version` varchar(64) DEFAULT NULL,
  `file_author` varchar(255) DEFAULT NULL,
  `file_language` varchar(255) DEFAULT NULL,
  `file_platform` varchar(255) DEFAULT NULL,
  `file_license` varchar(255) NOT NULL DEFAULT '',
  `file_user_roles` varchar(2000) NOT NULL DEFAULT '',
  `file_offline` enum('0','1') NOT NULL DEFAULT '0',
  `file_direct_linking` enum('0','1','3') NOT NULL DEFAULT '0',
  `file_force_download` enum('0','1') NOT NULL DEFAULT '0',
  `file_category` int(8) unsigned NOT NULL DEFAULT '0',
  `file_category_name` varchar(127) NOT NULL DEFAULT '',
  `file_update_of` bigint(20) unsigned DEFAULT NULL,
  `file_post_id` bigint(20) unsigned DEFAULT NULL,
  `file_attach_order` int(8) NOT NULL DEFAULT '0',
  `file_wpattach_id` bigint(20) NOT NULL DEFAULT '0',
  `file_added_by` bigint(20) unsigned DEFAULT NULL,
  `file_hits` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_ratings` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_rating_sum` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_last_dl_ip` varchar(100) NOT NULL DEFAULT '',
  `file_last_dl_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_custom_cf1` text NOT NULL,
  `file_custom_cf2` text NOT NULL,
  PRIMARY KEY (`file_id`),
  UNIQUE KEY `UNIQUE_FILE` (`file_name`,`file_category`),
  FULLTEXT KEY `DESCRIPTION` (`file_description`),
  FULLTEXT KEY `USER_ROLES` (`file_user_roles`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- Contenu de la table `wp_wpfb_files`
-- 

INSERT INTO `wp_wpfb_files` VALUES (1, 'EXIGENCES QUALITE Ue Projet 2012 2013.pdf', 'EXIGENCES QUALITE Ue Projet 2012 2013.pdf', 191915, '2013-04-29 23:02:16', 1367276536, 'e678d4fe1f4ecabf51c058b62d19d52e', '', '', 'EXIGENCES QUALITE Ue Projet 2012 2013', '', ',,', '', '', 'test', '', '', '', '', '0', '1', '0', 0, '', 0, 0, 0, 0, 1, 4, 0, 0, '130.120.210.134', '2013-10-03 13:43:03', '', '');
INSERT INTO `wp_wpfb_files` VALUES (2, '2.jpg', '2.jpg', 111473, '2013-04-29 23:19:25', 1367277565, '78535292d2029aa307f952058ff04ee8', '', '2-120x48.jpg', 'img', '', ',,', '', '', '', '', '', '', '', '0', '1', '0', 0, '', 0, 0, 0, 0, 24, 2, 0, 0, '130.120.244.19', '2013-09-27 13:19:02', '', '');
INSERT INTO `wp_wpfb_files` VALUES (3, 're.zip', 're.zip', 2175, '2013-04-29 23:20:11', 1367277611, '91a07076aa44f7443fb452b9fd7440f8', '', '', 'zip test', '', ',,', '', '', '', '', '', '', '', '0', '1', '0', 0, '', 0, 0, 0, 0, 24, 3, 0, 0, '130.120.244.15', '2013-10-02 15:48:56', '', '');
INSERT INTO `wp_wpfb_files` VALUES (6, 'mpi.odt', 'mpi.odt', 8415, '2013-05-20 08:43:59', 1369039439, '53f81c6d3aa531a8795ed67945fde636', '', '', 'Mpi', '', ',,', '', '', 'Mr Cherbonneau', '', '', '', '', '0', '1', '0', 0, '', 0, 0, 0, 0, 1, 4, 0, 0, '130.120.209.3', '2013-10-02 15:52:33', '', '');
INSERT INTO `wp_wpfb_files` VALUES (7, 'DossierSpecification.pdf', 'DossierSpecification.pdf', 1293514, '2013-10-02 12:33:19', 1380717199, '74afa8aa0c26da8edfcba01d818d5f01', '', '', 'DossierSpecification', '', '', '', '', '', '', '', '', '', '0', '1', '0', 0, '', 0, 0, 0, 0, 24, 6, 0, 0, '130.120.210.134', '2013-10-03 13:43:10', '', '');
INSERT INTO `wp_wpfb_files` VALUES (8, 'Spec Technique.pdf', 'Spec Technique.pdf', 462039, '2013-10-02 12:35:43', 1380717343, 'bd52f01c505a70662b46e72326601863', '', '', 'Spec Technique', '', '', '', '', '', '', '', '', '', '0', '1', '0', 0, '', 0, 0, 0, 0, 24, 0, 0, 0, '', '0000-00-00 00:00:00', '', '');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_wpfb_files_id3`
-- 

CREATE TABLE `wp_wpfb_files_id3` (
  `file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `analyzetime` int(11) NOT NULL DEFAULT '0',
  `value` longtext,
  `keywords` text NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `KEYWORDS` (`keywords`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- Contenu de la table `wp_wpfb_files_id3`
-- 

INSERT INTO `wp_wpfb_files_id3` VALUES (1, 1367276536, 'YTozOntzOjk6ImF2ZGF0YWVuZCI7aToxOTE5MTU7czoxMDoiZmlsZWZvcm1hdCI7czozOiJwZGYiO3M6OToibWltZV90eXBlIjtzOjE1OiJhcHBsaWNhdGlvbi9wZGYiO30=', 'pdf application');
INSERT INTO `wp_wpfb_files_id3` VALUES (2, 1367277565, 'YTo3OntzOjk6ImF2ZGF0YWVuZCI7aToxMTE0NzM7czoxMDoiZmlsZWZvcm1hdCI7czozOiJqcGciO3M6NToidmlkZW8iO2E6Njp7czoxMDoiZGF0YWZvcm1hdCI7czozOiJqcGciO3M6MTU6ImJpdHNfcGVyX3NhbXBsZSI7aToyNDtzOjE4OiJwaXhlbF9hc3BlY3RfcmF0aW8iO2Q6MTtzOjEyOiJyZXNvbHV0aW9uX3giO2k6OTQwO3M6MTI6InJlc29sdXRpb25feSI7aTozNzg7czoxNzoiY29tcHJlc3Npb25fcmF0aW8iO2Q6MC4xMDQ1NzUyMTg1ODIzMTA3ODA0OTA3Mjk0ODQ4ODE3NDAwNjM0Mjg4Nzg3ODQxNzk2ODc1O31zOjk6Im1pbWVfdHlwZSI7czoxMDoiaW1hZ2UvanBlZyI7czo0OiJpcHRjIjthOjI6e3M6MTI6IklQVENFbnZlbG9wZSI7YToyOntzOjE3OiJDb2RlZENoYXJhY3RlclNldCI7YTowOnt9czoyMToiRW52ZWxvcGVSZWNvcmRWZXJzaW9uIjthOjA6e319czoxNToiSVBUQ0FwcGxpY2F0aW9uIjthOjc6e3M6MjQ6IkFwcGxpY2F0aW9uUmVjb3JkVmVyc2lvbiI7YTowOnt9czo2OiJDcmVkaXQiO2E6MTp7aTowO3M6MjY6Ikp1bGllbiBFaWNoaW5nZXIgLSBGb3RvbGlhIjt9czo2OiJTb3VyY2UiO2E6MTp7aTowO3M6ODoiMjcwMTI2MDIiO31zOjEwOiJPYmplY3ROYW1lIjthOjE6e2k6MDtzOjg6ImludGVybmV0Ijt9czoyNzoiQ291bnRyeS1QcmltYXJ5TG9jYXRpb25OYW1lIjthOjE6e2k6MDtzOjY6IkZyYW5jZSI7fXM6ODoiS2V5d29yZHMiO2E6MTc6e2k6MDtzOjM6IndlYiI7aToxO3M6MTI6ImluZm9ybWF0aXF1ZSI7aToyO3M6NDoiaHRtbCI7aTozO3M6NDoiamF2YSI7aTo0O3M6Mzoib3JnIjtpOjU7czoxMDoiamF2YXNjcmlwdCI7aTo2O3M6NDoicGVybCI7aTo3O3M6MzoibmV0IjtpOjg7czozOiJ3d3ciO2k6OTtzOjM6ImNvbSI7aToxMDtzOjg6ImludGVybmV0IjtpOjExO3M6NDoiY29kZSI7aToxMjtzOjEyOiJpbGx1c3RyYXRpb24iO2k6MTM7czo4OiJidXNpbmVzcyI7aToxNDtzOjE6ImMiO2k6MTU7czozOiJwaHAiO2k6MTY7czo2OiJzY3JpcHQiO31zOjE1OiJDb3B5cmlnaHROb3RpY2UiO2E6MTp7aTowO3M6MjY6Ikp1bGllbiBFaWNoaW5nZXIgLSBGb3RvbGlhIjt9fX1zOjM6ImpwZyI7YToxOntzOjQ6ImV4aWYiO2E6NTp7czo0OiJGSUxFIjthOjQ6e3M6MTI6IkZpbGVEYXRlVGltZSI7aToxMzY3Mjc3NTY1O3M6ODoiRmlsZVR5cGUiO2k6MjtzOjg6Ik1pbWVUeXBlIjtzOjEwOiJpbWFnZS9qcGVnIjtzOjEzOiJTZWN0aW9uc0ZvdW5kIjtzOjMwOiJBTllfVEFHLCBJRkQwLCBUSFVNQk5BSUwsIEVYSUYiO31zOjg6IkNPTVBVVEVEIjthOjg6e3M6NDoiaHRtbCI7czoyNDoid2lkdGg9Ijk0MCIgaGVpZ2h0PSIzNzgiIjtzOjY6IkhlaWdodCI7aTozNzg7czo1OiJXaWR0aCI7aTo5NDA7czo3OiJJc0NvbG9yIjtpOjE7czoxNzoiQnl0ZU9yZGVyTW90b3JvbGEiO2k6MTtzOjk6IkNvcHlyaWdodCI7czoyNjoiSnVsaWVuIEVpY2hpbmdlciAtIEZvdG9saWEiO3M6MTg6IlRodW1ibmFpbC5GaWxlVHlwZSI7aToyO3M6MTg6IlRodW1ibmFpbC5NaW1lVHlwZSI7czoxMDoiaW1hZ2UvanBlZyI7fXM6NDoiSUZEMCI7YToxNDp7czoxMDoiSW1hZ2VXaWR0aCI7aTozMTE0O3M6MTE6IkltYWdlTGVuZ3RoIjtpOjIyMzE7czoxMzoiQml0c1BlclNhbXBsZSI7YTozOntpOjA7aTo4O2k6MTtpOjg7aToyO2k6ODt9czoyNToiUGhvdG9tZXRyaWNJbnRlcnByZXRhdGlvbiI7aToyO3M6MTE6Ik9yaWVudGF0aW9uIjtpOjE7czoxNToiU2FtcGxlc1BlclBpeGVsIjtpOjM7czoxMToiWFJlc29sdXRpb24iO2k6MzAwO3M6MTE6IllSZXNvbHV0aW9uIjtpOjMwMDtzOjE0OiJSZXNvbHV0aW9uVW5pdCI7aToyO3M6ODoiU29mdHdhcmUiO3M6Mjc6IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyI7czo4OiJEYXRlVGltZSI7czoxOToiMjAxMjowOTozMCAyMzoxMjowMyI7czoxNjoiWUNiQ3JQb3NpdGlvbmluZyI7aToxO3M6OToiQ29weXJpZ2h0IjtzOjI2OiJKdWxpZW4gRWljaGluZ2VyIC0gRm90b2xpYSI7czoxNjoiRXhpZl9JRkRfUG9pbnRlciI7aToyODA7fXM6OToiVEhVTUJOQUlMIjthOjY6e3M6MTE6IkNvbXByZXNzaW9uIjtpOjY7czoxMToiWFJlc29sdXRpb24iO2k6NzI7czoxMToiWVJlc29sdXRpb24iO2k6NzI7czoxNDoiUmVzb2x1dGlvblVuaXQiO2k6MjtzOjIxOiJKUEVHSW50ZXJjaGFuZ2VGb3JtYXQiO2k6NDMwO3M6Mjc6IkpQRUdJbnRlcmNoYW5nZUZvcm1hdExlbmd0aCI7aTo1NTcxO31zOjQ6IkVYSUYiO2E6NDp7czoxMToiRXhpZlZlcnNpb24iO2k6MjIxO3M6MTA6IkNvbG9yU3BhY2UiO2k6NjU1MzU7czoxNDoiRXhpZkltYWdlV2lkdGgiO2k6OTQwO3M6MTU6IkV4aWZJbWFnZUxlbmd0aCI7aTozNzg7fX19czozOiJ4bXAiO2E6NDp7czo5OiJwaG90b3Nob3AiO2E6Mzp7czo3OiJDb3VudHJ5IjtzOjY6IkZyYW5jZSI7czo2OiJDcmVkaXQiO3M6MjY6Ikp1bGllbiBFaWNoaW5nZXIgLSBGb3RvbGlhIjtzOjY6IlNvdXJjZSI7aToyNzAxMjYwMjt9czoyOiJkYyI7YTo0OntzOjY6ImZvcm1hdCI7czoxMDoiaW1hZ2UvanBlZyI7czo1OiJ0aXRsZSI7YToxOntpOjA7czo4OiJpbnRlcm5ldCI7fXM6Nzoic3ViamVjdCI7YToxNzp7aTowO3M6Mzoid2ViIjtpOjE7czoxMjoiaW5mb3JtYXRpcXVlIjtpOjI7czo0OiJodG1sIjtpOjM7czo0OiJqYXZhIjtpOjQ7czozOiJvcmciO2k6NTtzOjEwOiJqYXZhc2NyaXB0IjtpOjY7czo0OiJwZXJsIjtpOjc7czozOiJuZXQiO2k6ODtzOjM6Ind3dyI7aTo5O3M6MzoiY29tIjtpOjEwO3M6ODoiaW50ZXJuZXQiO2k6MTE7czo0OiJjb2RlIjtpOjEyO3M6MTI6ImlsbHVzdHJhdGlvbiI7aToxMztzOjg6ImJ1c2luZXNzIjtpOjE0O3M6MToiYyI7aToxNTtzOjM6InBocCI7aToxNjtzOjY6InNjcmlwdCI7fXM6NjoicmlnaHRzIjthOjE6e2k6MDtzOjI2OiJKdWxpZW4gRWljaGluZ2VyIC0gRm90b2xpYSI7fX1zOjM6InhtcCI7YTozOntzOjEwOiJDcmVhdGVEYXRlIjtzOjI1OiIyMDEyLTA5LTMwVDIyOjQ1OjE1KzAyOjAwIjtzOjEwOiJNb2RpZnlEYXRlIjtzOjI1OiIyMDEyLTA5LTMwVDIzOjEyOjAzKzAyOjAwIjtzOjEyOiJNZXRhZGF0YURhdGUiO3M6MjU6IjIwMTItMDktMzBUMjM6MTI6MDMrMDI6MDAiO31zOjk6InhtcFJpZ2h0cyI7YToxOntzOjY6Ik1hcmtlZCI7czo1OiJGYWxzZSI7fX19', 'jpg dataformat bits_per_sample pixel_aspect_ratio resolution_x resolution_y compression_ratio image jpeg codedcharacterset enveloperecordversion julien eichinger fotolia 27012602 internet france web informatique html java org javascript perl net www com code illustration business c php script applicationrecordversion credit source objectname country primarylocationname keywords copyrightnotice iptcenvelope iptcapplication any_tag ifd0 thumbnail exif filedatetime filetype mimetype sectionsfound width 940 height 378 iscolor byteordermotorola copyright adobe photoshop cs5 windows 2012 09 30 23 12 03 imagewidth imagelength bitspersample photometricinterpretation orientation samplesperpixel xresolution yresolution resolutionunit software datetime ycbcrpositioning exif_ifd_pointer compression jpeginterchangeformat jpeginterchangeformatlength exifversion colorspace exifimagewidth exifimagelength file computed format title subject rights 30t22 45 15 02 00 30t23 createdate modifydate metadatadate false marked dc xmp xmprights');
INSERT INTO `wp_wpfb_files_id3` VALUES (3, 1367277611, 'YTo0OntzOjk6ImF2ZGF0YWVuZCI7aToyMTc1O3M6MTA6ImZpbGVmb3JtYXQiO3M6MzoiemlwIjtzOjk6Im1pbWVfdHlwZSI7czoxNToiYXBwbGljYXRpb24vemlwIjtzOjM6InppcCI7YTo3OntzOjU6ImZpbGVzIjthOjM6e3M6MjM6IndwX2lkX2dyb3VwX21lbWJyZXMuc3FsIjtpOjEwMTk7czoxMjoid3BfZ3JvdXAuc3FsIjtpOjEwOTc7czoyMToid3BfdGFiX3N1amV0cyAoMikuc3FsIjtpOjM3MDE7fXM6MTU6ImNvbXByZXNzZWRfc2l6ZSI7aToxNzY1O3M6MTc6InVuY29tcHJlc3NlZF9zaXplIjtpOjU4MTc7czoxMzoiZW50cmllc19jb3VudCI7aTozO3M6MjE6ImVuZF9jZW50cmFsX2RpcmVjdG9yeSI7YTo2OntzOjY6Im9mZnNldCI7aToyMTUzO3M6OToic2lnbmF0dXJlIjtpOjEwMTAxMDI1NjtzOjI3OiJkaXJlY3RvcnlfZW50cmllc190aGlzX2Rpc2siO2k6MztzOjIzOiJkaXJlY3RvcnlfZW50cmllc190b3RhbCI7aTozO3M6MTQ6ImRpcmVjdG9yeV9zaXplIjtpOjE5NDtzOjE2OiJkaXJlY3Rvcnlfb2Zmc2V0IjtpOjE5NTk7fXM6MTg6ImNvbXByZXNzaW9uX21ldGhvZCI7czo3OiJkZWZsYXRlIjtzOjE3OiJjb21wcmVzc2lvbl9zcGVlZCI7czo2OiJub3JtYWwiO319', 'zip application wp_id_group_membres sql wp_group wp_tab_sujets 2 offset signature directory_entries_this_disk directory_entries_total directory_size directory_offset deflate normal files compressed_size uncompressed_size entries_count end_central_directory compression_method compression_speed');
INSERT INTO `wp_wpfb_files_id3` VALUES (6, 1369039441, 'YTo0OntzOjk6ImF2ZGF0YWVuZCI7aTo4NDE1O3M6MTA6ImZpbGVmb3JtYXQiO3M6MzoiemlwIjtzOjk6Im1pbWVfdHlwZSI7czoxNToiYXBwbGljYXRpb24vemlwIjtzOjM6InppcCI7YTo3OntzOjU6ImZpbGVzIjthOjg6e3M6ODoibWltZXR5cGUiO2k6Mzk7czo4OiJtZXRhLnhtbCI7aTo4Njk7czoxMjoic2V0dGluZ3MueG1sIjtpOjkwMDU7czoxMToiY29udGVudC54bWwiO2k6MzA3MjtzOjEwOiJUaHVtYm5haWxzIjthOjE6e3M6MTM6InRodW1ibmFpbC5wbmciO2k6NjY0O31zOjEyOiJtYW5pZmVzdC5yZGYiO2k6ODk5O3M6MTA6InN0eWxlcy54bWwiO2k6MTEwMzM7czo4OiJNRVRBLUlORiI7YToxOntzOjEyOiJtYW5pZmVzdC54bWwiO2k6MTA4Njt9fXM6MTU6ImNvbXByZXNzZWRfc2l6ZSI7aTo2Mjk3O3M6MTc6InVuY29tcHJlc3NlZF9zaXplIjtpOjI2NjY3O3M6MTM6ImVudHJpZXNfY291bnQiO2k6MTc7czoyMToiZW5kX2NlbnRyYWxfZGlyZWN0b3J5IjthOjY6e3M6Njoib2Zmc2V0IjtpOjgzOTM7czo5OiJzaWduYXR1cmUiO2k6MTAxMDEwMjU2O3M6Mjc6ImRpcmVjdG9yeV9lbnRyaWVzX3RoaXNfZGlzayI7aToxNztzOjIzOiJkaXJlY3RvcnlfZW50cmllc190b3RhbCI7aToxNztzOjE0OiJkaXJlY3Rvcnlfc2l6ZSI7aToxMTM2O3M6MTY6ImRpcmVjdG9yeV9vZmZzZXQiO2k6NzI1Nzt9czoxODoiY29tcHJlc3Npb25fbWV0aG9kIjtzOjU6InN0b3JlIjtzOjE3OiJjb21wcmVzc2lvbl9zcGVlZCI7czo1OiJzdG9yZSI7fX0=', 'zip application thumbnail png manifest xml mimetype meta settings content thumbnails rdf styles inf offset signature directory_entries_this_disk directory_entries_total directory_size directory_offset store files compressed_size uncompressed_size entries_count end_central_directory compression_method compression_speed');
INSERT INTO `wp_wpfb_files_id3` VALUES (7, 1380717199, 'YTozOntzOjk6ImF2ZGF0YWVuZCI7aToxMjkzNTE0O3M6MTA6ImZpbGVmb3JtYXQiO3M6MzoicGRmIjtzOjk6Im1pbWVfdHlwZSI7czoxNToiYXBwbGljYXRpb24vcGRmIjt9', 'pdf application');
INSERT INTO `wp_wpfb_files_id3` VALUES (8, 1380717343, 'YTozOntzOjk6ImF2ZGF0YWVuZCI7aTo0NjIwMzk7czoxMDoiZmlsZWZvcm1hdCI7czozOiJwZGYiO3M6OToibWltZV90eXBlIjtzOjE1OiJhcHBsaWNhdGlvbi9wZGYiO30=', 'pdf application');

-- --------------------------------------------------------

-- 
-- Structure de la table `wp_wpuf_customfields`
-- 

CREATE TABLE `wp_wpuf_customfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` varchar(30) NOT NULL,
  `type` varchar(20) NOT NULL,
  `values` text NOT NULL,
  `label` varchar(200) NOT NULL,
  `desc` varchar(200) NOT NULL,
  `required` varchar(5) NOT NULL,
  `region` varchar(20) NOT NULL DEFAULT 'top',
  `order` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_wpuf_customfields`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_wpuf_subscription`
-- 

CREATE TABLE `wp_wpuf_subscription` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `count` int(5) DEFAULT '0',
  `duration` int(5) NOT NULL DEFAULT '0',
  `cost` float NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_wpuf_subscription`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `wp_wpuf_transaction`
-- 

CREATE TABLE `wp_wpuf_transaction` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending_payment',
  `cost` varchar(255) DEFAULT '',
  `post_id` bigint(20) DEFAULT NULL,
  `pack_id` bigint(20) DEFAULT NULL,
  `payer_first_name` longtext,
  `payer_last_name` longtext,
  `payer_email` longtext,
  `payment_type` longtext,
  `payer_address` longtext,
  `transaction_id` longtext,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `wp_wpuf_transaction`
-- 

