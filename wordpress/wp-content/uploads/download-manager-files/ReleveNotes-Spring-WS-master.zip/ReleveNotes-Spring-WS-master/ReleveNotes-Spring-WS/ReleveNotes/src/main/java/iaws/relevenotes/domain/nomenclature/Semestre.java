package iaws.relevenotes.domain.nomenclature;

/**
 * @author franck Silvestre
 */
public class Semestre {

    private Integer id;

    public Semestre(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
