-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Mer 10 Avril 2013 à 13:32
-- Version du serveur: 5.5.20
-- Version de PHP: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `wp11`
--

-- --------------------------------------------------------

--
-- Structure de la table `wp_tab_sujets`
--

CREATE TABLE IF NOT EXISTS `wp_tab_sujets` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `titre` varchar(150) NOT NULL,
  `tailleEq` varchar(20) NOT NULL,
  `specialite` varchar(10) NOT NULL,
  `langage` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `loginEncadrant` varchar(30) NOT NULL,
  `choisiPar` varchar(50) DEFAULT NULL,
  `affecteAuGroupe` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Contenu de la table `wp_tab_sujets`
--

INSERT INTO `wp_tab_sujets` (`numero`, `titre`, `tailleEq`, `specialite`, `langage`, `description`, `loginEncadrant`, `choisiPar`, `affecteAuGroupe`) VALUES
(1, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(2, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(3, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(4, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(5, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(6, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(7, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(8, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(9, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(10, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(11, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(12, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(13, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(14, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(15, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(16, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(17, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(18, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL),
(19, 'Developpement', '5', 'DL', 'C++,JAVA', 'Developpmeent de logiciel informatique', 'EncadrantLog', NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
